// ==UserScript==
// @author         jaiperdu
// @name           COMM Filter Tab
// @category       COMM
// @version        0.4.12
// @description    Show virus in the regular Comm and add a new tab with portal/player name filter and event type filter.
// @id             comm-filter-tab@jaiperdu
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://raw.githubusercontent.com/IITC-CE/Community-plugins/master/dist/jaiperdu/comm-filter-tab.meta.js
// @downloadURL    https://raw.githubusercontent.com/IITC-CE/Community-plugins/master/dist/jaiperdu/comm-filter-tab.user.js
// @match          https://intel.ingress.com/*
// @grant          none
// ==/UserScript==
