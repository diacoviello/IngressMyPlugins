// ==UserScript==
// @author         Alfonso_M
// @name           Pogo Tools
// @id             s2check@Alfonso_M
// @category       Layer
// @namespace      https://github.com/AlfonsoML-s/pogo-s2/
// @downloadURL    https://raw.githubusercontent.com/IITC-CE/Community-plugins/master/dist/Alfonso_M/s2check.user.js
// @updateURL      https://raw.githubusercontent.com/IITC-CE/Community-plugins/master/dist/Alfonso_M/s2check.meta.js
// @homepageURL    https://alfonsoml-s.github.io/pogo-s2/
// @version        0.102
// @description    Pokemon Go tools over IITC.
// @match          https://intel.ingress.com/*
// @grant          none
// ==/UserScript==
