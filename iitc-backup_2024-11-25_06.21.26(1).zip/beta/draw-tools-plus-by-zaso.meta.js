// ==UserScript==
// @id             iitc-plugin-draw-tools-plus@Zaso
// @name           IITC plugin: draw tools plus
// @category       Layer
// @version        0.1.8.20180217.123738
// @namespace      http://www.giacintogarcea.com/ingress/items/
// @updateURL      http://www.giacintogarcea.com/ingress/iitc/draw-tools-plus-by-zaso.meta.js
// @downloadURL    http://www.giacintogarcea.com/ingress/iitc/draw-tools-plus-by-zaso.user.js
// @description    Edit and improve Draw tools.
// @include        https://*.ingress.com/intel*
// @include        http://*.ingress.com/intel*
// @match          https://*.ingress.com/intel*
// @match          http://*.ingress.com/intel*
// @include        https://*.ingress.com/mission/*
// @include        http://*.ingress.com/mission/*
// @match          https://*.ingress.com/mission/*
// @match          http://*.ingress.com/mission/*
// @grant          none
// ==/UserScript==