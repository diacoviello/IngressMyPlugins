// ==UserScript==
// @name         IITC Custom Keyboard Shortcuts
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Set keyboard shortcuts for Intel Ingress website
// @author       DiabloEnMusica
// @match        https://intel.ingress.com/*
// @match       https://*.ingress.com/intel*
// @match       http://*.ingress.com/intel*
// @match       https://*.ingress.com/mission/*
// @match       http://*.ingress.com/mission/*
// @id          iitc-plugin-route-planner@odrick
// @category    Layer
// @license     MIT
// @include     https://*.ingress.com/intel*
// @include     http://*.ingress.com/intel*
// @include     https://*.ingress.com/mission/*
// @include     http://*.ingress.com/mission/*
// @grant        none
// ==/UserScript==



( function() {
    'use strict';

    // Check if the script runs on the Ingress Intel website
    if ( window.location.href.startsWith( 'https://intel.ingress.com/' ) ) {
        console.log( "Hey Dave, Script is running on the Ingress Intel website." );

        document.addEventListener( 'keydown', function( event ) {
            if ( event.altKey&&event.key==='b' ) {
                // Prevent the default behavior of Alt+B
                event.preventDefault();

                // Create a new KeyboardEvent with Ctrl key added
                var ctrlAltBEvent=new KeyboardEvent( 'keydown', {
                    key: 'b',
                    code: 'KeyB',
                    ctrlKey: true,
                    altKey: true
                } );

                // Dispatch the new KeyboardEvent
                document.dispatchEvent( ctrlAltBEvent );
            }
        } );
    } else {
        console.log( "Script is not running on the Ingress Intel website." );
    }
} )();
