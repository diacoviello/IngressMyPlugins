// ==UserScript==
// @name         Diablo Tools
// @category     Layer
// @version      0.666
// @description  Pokemon Go tools over IITC.
// @author       Diablo
// @match        https://intel.ingress.com/*
// @grant        none
// ==/UserScript==

/* eslint-env es6 */
/* eslint no-var: "error" */
/* globals L, map */
/* globals GM_info, $, dialog */
/* globals renderPortalDetails, findPortalGuidByPositionE6, chat */


; ( function() { // eslint-disable-line no-extra-semi

	/** S2 Geometry functions

	 S2 extracted from Regions Plugin
	 https:static.iitc.me/build/release/plugins/regions.user.js

	 the regional scoreboard is based on a level 6 S2 Cell
	 - https:docs.google.com/presentation/d/1Hl4KapfAENAOf4gv-pSngKwvS_jwNVHRPZTTDzXXn6Q/view?pli=1#slide=id.i22
	 at the time of writing there's no actual API for the intel map to retrieve scoreboard data,
	 but it's still useful to plot the score cells on the intel map


	 the S2 geometry is based on projecting the earth sphere onto a cube, with some scaling of face coordinates to
	 keep things close to approximate equal area for adjacent cells
	 to convert a lat,lng into a cell id:
	 - convert lat,lng to x,y,z
	 - convert x,y,z into face,u,v
	 - u,v scaled to s,t with quadratic formula
	 - s,t converted to integer i,j offsets
	 - i,j converted to a position along a Hubbert space-filling curve
	 - combine face,position to get the cell id

	 NOTE: compared to the google S2 geometry library, we vary from their code in the following ways
	 - cell IDs: they combine face and the hilbert curve position into a single 64 bit number. this gives efficient space
							 and speed. javascript doesn't have appropriate data types, and speed is not cricical, so we use
							 as [face,[bitpair,bitpair,...]] instead
	 - i,j: they always use 30 bits, adjusting as needed. we use 0 to (1<<level)-1 instead
					(so GetSizeIJ for a cell is always 1)
	*/

	function wrapper( plugin_info ) {
		'use strict';

		const d2r=Math.PI/180.0;
		const r2d=180.0/Math.PI;

		const S2={};

		function LatLngToXYZ( latLng ) {
			const phi=latLng.lat*d2r;
			const theta=latLng.lng*d2r;
			const cosphi=Math.cos( phi );

			return [ Math.cos( theta )*cosphi, Math.sin( theta )*cosphi, Math.sin( phi ) ];
		}

		function XYZToLatLng( xyz ) {
			const lat=Math.atan2( xyz[ 2 ], Math.sqrt( xyz[ 0 ]*xyz[ 0 ]+xyz[ 1 ]*xyz[ 1 ] ) );
			const lng=Math.atan2( xyz[ 1 ], xyz[ 0 ] );

			return { lat: lat*r2d, lng: lng*r2d };
		}

		function largestAbsComponent( xyz ) {
			const temp=[ Math.abs( xyz[ 0 ] ), Math.abs( xyz[ 1 ] ), Math.abs( xyz[ 2 ] ) ];

			if ( temp[ 0 ]>temp[ 1 ] ) {
				if ( temp[ 0 ]>temp[ 2 ] ) {
					return 0;
				}
				return 2;
			}

			if ( temp[ 1 ]>temp[ 2 ] ) {
				return 1;
			}

			return 2;
		}

		function faceXYZToUV( face, xyz ) {
			let u, v;

			switch ( face ) {
				case 0: u=xyz[ 1 ]/xyz[ 0 ]; v=xyz[ 2 ]/xyz[ 0 ]; break;
				case 1: u=-xyz[ 0 ]/xyz[ 1 ]; v=xyz[ 2 ]/xyz[ 1 ]; break;
				case 2: u=-xyz[ 0 ]/xyz[ 2 ]; v=-xyz[ 1 ]/xyz[ 2 ]; break;
				case 3: u=xyz[ 2 ]/xyz[ 0 ]; v=xyz[ 1 ]/xyz[ 0 ]; break;
				case 4: u=xyz[ 2 ]/xyz[ 1 ]; v=-xyz[ 0 ]/xyz[ 1 ]; break;
				case 5: u=-xyz[ 1 ]/xyz[ 2 ]; v=-xyz[ 0 ]/xyz[ 2 ]; break;
				default: throw { error: 'Invalid face' };
			}

			return [ u, v ];
		}

		function XYZToFaceUV( xyz ) {
			let face=largestAbsComponent( xyz );

			if ( xyz[ face ]<0 ) {
				face+=3;
			}

			const uv=faceXYZToUV( face, xyz );

			return [ face, uv ];
		}

		function FaceUVToXYZ( face, uv ) {
			const u=uv[ 0 ];
			const v=uv[ 1 ];

			switch ( face ) {
				case 0: return [ 1, u, v ];
				case 1: return [ -u, 1, v ];
				case 2: return [ -u, -v, 1 ];
				case 3: return [ -1, -v, -u ];
				case 4: return [ v, -1, -u ];
				case 5: return [ v, u, -1 ];
				default: throw { error: 'Invalid face' };
			}
		}

		function STToUV( st ) {
			const singleSTtoUV=function( st ) {
				if ( st>=0.5 ) {
					return ( 1/3.0 )*( 4*st*st-1 );
				}
				return ( 1/3.0 )*( 1-( 4*( 1-st )*( 1-st ) ) );

			};

			return [ singleSTtoUV( st[ 0 ] ), singleSTtoUV( st[ 1 ] ) ];
		}

		function UVToST( uv ) {
			const singleUVtoST=function( uv ) {
				if ( uv>=0 ) {
					return 0.5*Math.sqrt( 1+3*uv );
				}
				return 1-0.5*Math.sqrt( 1-3*uv );

			};

			return [ singleUVtoST( uv[ 0 ] ), singleUVtoST( uv[ 1 ] ) ];
		}

		function STToIJ( st, order ) {
			const maxSize=1<<order;

			const singleSTtoIJ=function( st ) {
				const ij=Math.floor( st*maxSize );
				return Math.max( 0, Math.min( maxSize-1, ij ) );
			};

			return [ singleSTtoIJ( st[ 0 ] ), singleSTtoIJ( st[ 1 ] ) ];
		}

		function IJToST( ij, order, offsets ) {
			const maxSize=1<<order;

			return [
				( ij[ 0 ]+offsets[ 0 ] )/maxSize,
				( ij[ 1 ]+offsets[ 1 ] )/maxSize
			];
		}

		// S2Cell class
		S2.S2Cell=function() { };

		//static method to construct
		S2.S2Cell.FromLatLng=function( latLng, level ) {
			const xyz=LatLngToXYZ( latLng );
			const faceuv=XYZToFaceUV( xyz );
			const st=UVToST( faceuv[ 1 ] );
			const ij=STToIJ( st, level );

			return S2.S2Cell.FromFaceIJ( faceuv[ 0 ], ij, level );
		};

		S2.S2Cell.FromFaceIJ=function( face, ij, level ) {
			const cell=new S2.S2Cell();
			cell.face=face;
			cell.ij=ij;
			cell.level=level;

			return cell;
		};

		S2.S2Cell.prototype.toString=function() {
			return 'F'+this.face+'ij['+this.ij[ 0 ]+','+this.ij[ 1 ]+']@'+this.level;
		};

		S2.S2Cell.prototype.getLatLng=function() {
			const st=IJToST( this.ij, this.level, [ 0.5, 0.5 ] );
			const uv=STToUV( st );
			const xyz=FaceUVToXYZ( this.face, uv );

			return XYZToLatLng( xyz );
		};

		S2.S2Cell.prototype.getCornerLatLngs=function() {
			const offsets=[
				[ 0.0, 0.0 ],
				[ 0.0, 1.0 ],
				[ 1.0, 1.0 ],
				[ 1.0, 0.0 ]
			];

			return offsets.map( offset => {
				const st=IJToST( this.ij, this.level, offset );
				const uv=STToUV( st );
				const xyz=FaceUVToXYZ( this.face, uv );

				return XYZToLatLng( xyz );
			} );
		};

		S2.S2Cell.prototype.getNeighbors=function( deltas ) {

			const fromFaceIJWrap=function( face, ij, level ) {
				const maxSize=1<<level;
				if ( ij[ 0 ]>=0&&ij[ 1 ]>=0&&ij[ 0 ]<maxSize&&ij[ 1 ]<maxSize ) {
					// no wrapping out of bounds
					return S2.S2Cell.FromFaceIJ( face, ij, level );
				}

				// the new i,j are out of range.
				// with the assumption that they're only a little past the borders we can just take the points as
				// just beyond the cube face, project to XYZ, then re-create FaceUV from the XYZ vector
				let st=IJToST( ij, level, [ 0.5, 0.5 ] );
				let uv=STToUV( st );
				let xyz=FaceUVToXYZ( face, uv );
				const faceuv=XYZToFaceUV( xyz );
				face=faceuv[ 0 ];
				uv=faceuv[ 1 ];
				st=UVToST( uv );
				ij=STToIJ( st, level );
				return S2.S2Cell.FromFaceIJ( face, ij, level );
			};

			const face=this.face;
			const i=this.ij[ 0 ];
			const j=this.ij[ 1 ];
			const level=this.level;

			if ( !deltas ) {
				deltas=[
					{ a: -1, b: 0 },
					{ a: 0, b: -1 },
					{ a: 1, b: 0 },
					{ a: 0, b: 1 }
				];
			}
			return deltas.map( function( values ) {
				return fromFaceIJWrap( face, [ i+values.a, j+values.b ], level );
			} );
		};

		/** Our code
		* For safety, S2 must be initialized before our code
		*/

		// based on https://github.com/iatkin/leaflet-svgicon
		function initSvgIcon() {
			L.DivIcon.SVGIcon=L.DivIcon.extend( {
				options: {
					'className': 'svg-icon',
					'iconAnchor': null, //defaults to [iconSize.x/2, iconSize.y] (point tip)
					'iconSize': L.point( 48, 48 )
				},
				initialize: function( options ) {
					options=L.Util.setOptions( this, options );

					//iconSize needs to be converted to a Point object if it is not passed as one
					options.iconSize=L.point( options.iconSize );

					if ( !options.iconAnchor ) {
						options.iconAnchor=L.point( Number( options.iconSize.x )/2, Number( options.iconSize.y ) );
					} else {
						options.iconAnchor=L.point( options.iconAnchor );
					}
				},

				// https://github.com/tonekk/Leaflet-Extended-Div-Icon/blob/master/extended.divicon.js#L13
				createIcon: function( oldIcon ) {
					let div=L.DivIcon.prototype.createIcon.call( this, oldIcon );

					if ( this.options.id ) {
						div.id=this.options.id;
					}

					if ( this.options.style ) {
						for ( let key in this.options.style ) {
							div.style[ key ]=this.options.style[ key ];
						}
					}
					return div;
				}
			} );

			L.divIcon.svgIcon=function( options ) {
				return new L.DivIcon.SVGIcon( options );
			};

			L.Marker.SVGMarker=L.Marker.extend( {
				options: {
					'iconFactory': L.divIcon.svgIcon,
					'iconOptions': {}
				},
				initialize: function( latlng, options ) {
					options=L.Util.setOptions( this, options );
					options.icon=options.iconFactory( options.iconOptions );
					this._latlng=latlng;
				},
				onAdd: function( map ) {
					L.Marker.prototype.onAdd.call( this, map );
				}
			} );

			L.marker.svgMarker=function( latlng, options ) {
				return new L.Marker.SVGMarker( latlng, options );
			};
		}

		/**
		 * Saves a file to disk with the provided text
		 * @param {string} text - The text to save
		 * @param {string} filename - Proposed filename
		 */
		function saveToFile( text, filename ) {
			if ( typeof text!='string' ) {
				text=JSON.stringify( text );
			}

			if ( typeof window.saveFile!='undefined' ) {
				window.saveFile( text, filename, 'application/json' );
				return;
			}

			alert( 'You are using an old version of IITC.\r\nIn the future this plugin will no longer be compatible with it.\r\nPlease, upgrade ASAP to IITC-CE https://iitc.modos189.ru/' );


			if ( typeof window.android!=='undefined'&&window.android.saveFile ) {
				window.android.saveFile( filename, 'application/json', text );
				return;
			}

			if ( isIITCm() ) {
				promptForCopy( text );
				return;
			}

			const element=document.createElement( 'a' );

			// http://stackoverflow.com/questions/13405129/javascript-create-and-save-file
			const file=new Blob( [ text ], { type: 'text/plain' } );
			const objectURL=URL.createObjectURL( file );
			element.setAttribute( 'href', objectURL );

			element.setAttribute( 'download', filename );

			element.style.display='none';
			document.body.appendChild( element );

			element.click();

			setTimeout( function() {
				document.body.removeChild( element );
				URL.revokeObjectURL( objectURL );
			}, 0 );
		}

		/**
		 * Prompts the user to select a file and then reads its contents and calls the callback function with those contents
		 * @param {Function} callback - Function that will be called when the file is read.
		 * Callback signature: function( {string} contents ) {}
		 */
		function readFromFile( callback ) {

			if ( typeof L.FileListLoader!='undefined' ) {
				L.FileListLoader.loadFiles( { accept: 'application/json' } )
					.on( 'load', function( e ) {
						callback( e.reader.result );
					} );
				return;
			}

			alert( 'You are using an old version of IITC.\r\nIn the future this plugin will no longer be compatible with it.\r\nPlease, upgrade ASAP to IITC-CE https://iitc.modos189.ru/' );


			// special hook from iitcm
			if ( typeof window.requestFile!='undefined' ) {
				window.requestFile( function( filename, content ) {
					callback( content );
				} );
				return;
			}

			if ( isIITCm() ) {
				promptForPaste( callback );
				return;
			}

			const input=document.createElement( 'input' );
			input.type='file';
			document.body.appendChild( input );

			input.addEventListener( 'change', function() {
				const reader=new FileReader();
				reader.onload=function() {
					callback( reader.result );
				};
				reader.readAsText( input.files[ 0 ] );
				document.body.removeChild( input );
			}, false );

			input.click();
		}

		function promptForPaste( callback ) {
			const div=document.createElement( 'div' );

			const textarea=document.createElement( 'textarea' );
			textarea.style.width='100%';
			textarea.style.minHeight='8em';
			div.appendChild( textarea );
			const width=Math.min( screen.availWidth, 360 );

			const container=dialog( {
				id: 'promptForPaste',
				html: div,
				width: width+'px',
				title: 'Paste here the data',
				buttons: {
					OK: function() {
						container.dialog( 'close' );
						callback( textarea.value );
					}
				}
			} );
		}

		function promptForCopy( text ) {
			const div=document.createElement( 'div' );

			const textarea=document.createElement( 'textarea' );
			textarea.style.width='100%';
			textarea.style.minHeight='8em';
			textarea.value=text;
			div.appendChild( textarea );
			const width=Math.min( screen.availWidth, 360 );

			const container=dialog( {
				id: 'promptForCopy',
				html: div,
				width: width+'px',
				title: 'Copy this data',
				buttons: {
					OK: function() {
						container.dialog( 'close' );
					}
				}
			} );
		}

		const TIMERS={};
		function createThrottledTimer( name, callback, ms ) {
			if ( TIMERS[ name ] )
				clearTimeout( TIMERS[ name ] );

			// throttle if there are several calls to the functions
			TIMERS[ name ]=setTimeout( function() {
				delete TIMERS[ name ];
				if ( typeof window.requestIdleCallback=='undefined' )
					callback();
				else
					// and even now, wait for iddle
					requestIdleCallback( function() {
						callback();
					}, { timeout: 2000 } );

			}, ms||100 );
		}

		/**
		 * Try to identify if the browser is IITCm due to special bugs like file picker not working
		 */
		function isIITCm() {
			const ua=navigator.userAgent;
			if ( !ua.match( /Android.*Mobile/ ) )
				return false;

			if ( ua.match( /; wb\)/ ) )
				return true;

			return ua.match( / Version\// );
		}

		function is_iOS() {
			const ua=navigator.userAgent;
			return ua.includes( 'iPhone' )||ua.includes( 'iPad' );
		}

		let pokestops={};
		let gyms={};
		// Portals that aren't marked as PoGo items
		let notpogo={};

		let allPortals={};
		let newPortals={};
		let checkNewPortalsTimer;
		let relayoutTimer; // timer for relayout when portal is added

		// Portals that the user hasn't classified as Pokestops (2 or more in the same Lvl17 cell)
		let skippedPortals={};
		let newPokestops={};
		let notClassifiedPokestops=[];

		// Portals that we know, but that have been moved from our stored location.
		let movedPortals=[];
		// Pogo items that are no longer available.
		let missingPortals={};

		// Cells currently detected with extra gyms
		let cellsExtraGyms={};
		// Cells that the user has marked to ignore extra gyms
		let ignoredCellsExtraGyms={};
		// Cells with missing Gyms
		let ignoredCellsMissingGyms={};

		// Leaflet layers
		let regionLayer; // parent layer
		let stopLayerGroup; // pokestops
		let gymLayerGroup; // gyms
		let nearbyLayerGroup; // circles to mark the too near limit
		let gridLayerGroup; // s2 grid
		let cellLayerGroup; // cell shading and borders
		let gymCenterLayerGroup; // gym centers

		let countLayer; // layer with count of portals in each cell

		// Group of items added to the layer
		let stopLayers={};
		let gymLayers={};
		let nearbyCircles={};

		// grouping of the portals in the second level of the grid
		let cellsPortals={};

		const highlighterTitle='PoGo Tools';
		const gymCellLevel=14; // the cell level which is considered when counting POIs to determine # of gyms
		const poiCellLevel=17; // the cell level where there can only be 1 POI translated to pogo

		const defaultSettings={
			highlightGymCandidateCells: true,
			highlightGymCenter: false,
			thisIsPogo: false,
			analyzeForMissingData: true,
			centerMapOnClick: true,
			grids: [
				{
					level: gymCellLevel,
					width: 5,
					color: '#004D40',
					opacity: 0.5
				},
				{
					level: poiCellLevel,
					width: 2,
					color: '#388E3C',
					opacity: 0.5
				}
			],
			colors: {
				cellsExtraGyms: {
					color: '#ff0000',
					opacity: 0.5
				},
				cellsMissingGyms: {
					color: '#ffa500',
					opacity: 0.5
				},
				cell17Filled: {
					color: '#000000',
					opacity: 0.6
				},
				cell14Filled: {
					color: '#000000',
					opacity: 0.5
				},
				nearbyCircleBorder: {
					color: '#000000',
					opacity: 0.6
				},
				nearbyCircleFill: {
					color: '#000000',
					opacity: 0.4
				},
				missingStops1: {
					color: '#BF360C',
					opacity: 1
				},
				missingStops2: {
					color: '#E64A19',
					opacity: 1
				},
				missingStops3: {
					color: '#FF5722',
					opacity: 1
				}
			},
			saveDataType: 'Gyms',
			saveDataFormat: 'CSV'
		};

		let settings=defaultSettings;

		function saveSettings() {
			createThrottledTimer( 'saveSettings', function() {
				localStorage[ KEY_SETTINGS ]=JSON.stringify( settings );
			} );
		}

		function loadSettings() {
			const tmp=localStorage[ KEY_SETTINGS ];
			if ( !tmp ) {
				loadOldSettings();
				return;
			}
			try {
				settings=JSON.parse( tmp );
			} catch ( e ) { // eslint-disable-line no-empty
			}

			setThisIsPogo();
		}

		/**
		* Migrate from old key to new one in order to avoid conflict with other plugin that reused this code.
		*/
		function loadOldSettings() {
			const tmp=localStorage[ 's2check_settings' ];
			if ( !tmp )
				return;
			try {
				settings=JSON.parse( tmp );
			} catch ( e ) { // eslint-disable-line no-empty
			}
			if ( typeof settings.analyzeForMissingData=='undefined' ) {
				settings.analyzeForMissingData=true;
			}
			if ( typeof settings.promptForMissingData!='undefined' ) {
				delete settings.promptForMissingData;
			}
			if ( !settings.colors ) {
				resetColors();
			}
			if ( typeof settings.saveDataType=='undefined' ) {
				settings.saveDataType='Gyms';
			}
			if ( typeof settings.saveDataFormat=='undefined' ) {
				settings.saveDataFormat='CSV';
			}
			if ( typeof settings.centerMapOnClick=='undefined' ) {
				settings.centerMapOnClick=true;
			}

			setThisIsPogo();

			// migrate key
			localStorage.removeItem( 's2check_settings' );
			saveStorage();
		}

		function resetColors() {
			settings.grids[ 0 ].color=defaultSettings.grids[ 0 ].color;
			settings.grids[ 0 ].opacity=defaultSettings.grids[ 0 ].opacity;
			settings.grids[ 1 ].color=defaultSettings.grids[ 1 ].color;
			settings.grids[ 1 ].opacity=defaultSettings.grids[ 1 ].opacity;
			settings.colors=defaultSettings.colors;
		}

		let originalHighlightPortal;
		let originalChatRequestPublic;
		let originalChatRequestFaction;
		let originalChatRequestAlerts;
		let originalRANGE_INDICATOR_COLOR;
		let originalHACK_RANGE;

		function markPortalsAsNeutral( data ) {
			const hidePortalOwnershipStyles=window.getMarkerStyleOptions( { team: window.TEAM_NONE, level: 0 } );
			data.portal.setStyle( hidePortalOwnershipStyles );
		}

		function setThisIsPogo() {
			document.body.classList[ settings.thisIsPogo? 'add':'remove' ](
				'thisIsPogo'
			)

			try {
				if ( settings.thisIsPogo ) {
					removeIngressLayers()
					// changeLocationCircle()
					if ( chat&&chat.requestPublic ) {
						originalChatRequestPublic=chat&&chat.requestPublic
						chat.requestPublic=function() { } // no requests for chat
					}
					if ( chat&&chat.requestFaction ) {
						originalChatRequestFaction=chat&&chat.requestFaction
						chat.requestFaction=function() { } // no requests for chat
					}
					if ( chat&&chat.requestAlerts ) {
						originalChatRequestAlerts=chat&&chat.requestAlerts
						chat.requestAlerts=function() { } // no requests for chat
					}

					// Hide the link range indicator around the selected portal
					originalRANGE_INDICATOR_COLOR=window.RANGE_INDICATOR_COLOR // eslint-disable-line camelcase
					window.RANGE_INDICATOR_COLOR='transparent'

					// Use 80 m. interaction radius
					originalHACK_RANGE=window.HACK_RANGE // eslint-disable-line camelcase
					window.HACK_RANGE=80

					if (
						window._current_highlighter===window._no_highlighter
					) {
						window.changePortalHighlights( highlighterTitle )
					}
				} else {
					restoreIngressLayers()
					// changeLocationCircle()
					if ( originalChatRequestPublic ) {
						chat.requestPublic=originalChatRequestPublic
						originalChatRequestPublic=null
					}
					if ( originalChatRequestFaction ) {
						chat.requestFaction=originalChatRequestFaction
						originalChatRequestFaction=null
					}
					if ( originalChatRequestAlerts ) {
						chat.requestAlerts=originalChatRequestAlerts
						originalChatRequestAlerts=null
					}
					// eslint-disable-next-line camelcase
					if ( originalRANGE_INDICATOR_COLOR!=null ) {
						window.RANGE_INDICATOR_COLOR=
							originalRANGE_INDICATOR_COLOR // eslint-disable-line camelcase
					}
					// eslint-disable-next-line camelcase
					if ( originalHACK_RANGE!=null ) {
						window.HACK_RANGE=originalHACK_RANGE // eslint-disable-line camelcase
					}

					if ( window._current_highlighter===highlighterTitle ) {
						window.changePortalHighlights( window._no_highlighter )
					}

					if ( originalHighlightPortal!=null ) {
						window.highlightPortal=originalHighlightPortal
						originalHighlightPortal=null
						window.resetHighlightedPortals()
					}
				}
			} catch ( e ) {
				alert( 'Error initializing ThisIsPogo: '+e )
				console.log( e ) // eslint-disable-line no-console
			}
		}

		function sortByName( a, b ) {
			if ( !a.name )
				return -1;

			return a.name.localeCompare( b.name );
		}

		function isCellOnScreen( mapBounds, cell ) {
			const corners=cell.getCornerLatLngs();
			const cellBounds=L.latLngBounds( [ corners[ 0 ], corners[ 1 ] ] ).extend( corners[ 2 ] ).extend( corners[ 3 ] );
			return cellBounds.intersects( mapBounds );
		}

		// return only the cells that are visible by the map bounds to ignore far away data that might not be complete
		function filterWithinScreen( cells ) {
			const bounds=map.getBounds();
			const filtered={};
			Object.keys( cells ).forEach( cellId => {
				const cellData=cells[ cellId ];
				const cell=cellData.cell;

				if ( isCellInsideScreen( bounds, cell ) ) {
					filtered[ cellId ]=cellData;
				}
			} );
			return filtered;
		}

		function isCellInsideScreen( mapBounds, cell ) {
			const corners=cell.getCornerLatLngs();
			const cellBounds=L.latLngBounds( [ corners[ 0 ], corners[ 1 ] ] ).extend( corners[ 2 ] ).extend( corners[ 3 ] );
			return mapBounds.contains( cellBounds );
		}

		/**
		* Filter a group of items (gyms/stops) excluding those out of the screen
		*/
		function filterItemsByMapBounds( items ) {
			const bounds=map.getBounds();
			const filtered={};
			Object.keys( items ).forEach( id => {
				const item=items[ id ];

				if ( isPointOnScreen( bounds, item ) ) {
					filtered[ id ]=item;
				}
			} );
			return filtered;
		}

		function isPointOnScreen( mapBounds, point ) {
			if ( point._latlng )
				return mapBounds.contains( point._latlng );

			return mapBounds.contains( L.latLng( point ) );
		}

		function groupByCell( level ) {
			const cells={};
			classifyGroup( cells, gyms, level, ( cell, item ) => cell.gyms.push( item ) );
			classifyGroup( cells, pokestops, level, ( cell, item ) => cell.stops.push( item ) );
			classifyGroup( cells, newPortals, level, ( cell, item ) => cell.notClassified.push( item ) );
			classifyGroup( cells, notpogo, level, ( cell, item ) => {/* */ } );

			return cells;
		}

		function classifyGroup( cells, items, level, callback ) {
			Object.keys( items ).forEach( id => {
				const item=items[ id ];
				if ( !item.cells ) {
					item.cells={};
				}
				let cell;
				// Compute the cell only once for each level
				if ( !item.cells[ level ] ) {
					cell=S2.S2Cell.FromLatLng( item, level );
					item.cells[ level ]=cell.toString();
				}
				const cellId=item.cells[ level ];

				// Add it to the array of gyms of that cell
				if ( !cells[ cellId ] ) {
					if ( !cell ) {
						cell=S2.S2Cell.FromLatLng( item, level );
					}
					cells[ cellId ]={
						cell: cell,
						gyms: [],
						stops: [],
						notClassified: [],
						portals: {}
					};
				}
				callback( cells[ cellId ], item );
			} );
		}

		/**
		 * Returns the items that belong to the specified cell
		 */
		function findCellItems( cellId, level, items ) {
			return Object.values( items ).filter( item => item.cells[ level ]==cellId );
		}

		/**
			Tries to add the portal photo when exporting from Ingress.com/intel
		*/
		function findPhotos( items ) {
			if ( !window.portals ) {
				return items;
			}
			Object.keys( items ).forEach( id => {
				const item=items[ id ];
				if ( item.image )
					return;

				const portal=window.portals[ id ];
				if ( portal&&portal.options&&portal.options.data ) {
					item.image=portal.options.data.image;
				}
			} );
			return items;
		}

		function configureGridLevelSelect( select, i ) {
			select.value=settings.grids[ i ].level;
			select.addEventListener( 'change', e => {
				settings.grids[ i ].level=parseInt( select.value, 10 );
				if ( i==1 )
					resetGrouping();

				saveSettings();
				updateMapGrid();
			} );
		}

		function resetGrouping() {
			cellsPortals={};
			const level=settings.grids[ 1 ].level;
			if ( level<4 )
				return;

			classifyGroup( cellsPortals, allPortals, level, ( cell, item ) => cell.portals[ item.guid ]=true );
		}

		function groupPortal( item ) {
			const level=settings.grids[ 1 ].level;
			if ( level<4 )
				return;

			let cells=cellsPortals;
			let cell;

			// Compute the cell only once for each level
			if ( !item.cells[ level ] ) {
				cell=S2.S2Cell.FromLatLng( item, level );
				item.cells[ level ]=cell.toString();
			}
			const cellId=item.cells[ level ];

			// Add it to the array of gyms of that cell
			if ( !cells[ cellId ] ) {
				if ( !cell ) {
					cell=S2.S2Cell.FromLatLng( item, level );
				}
				cells[ cellId ]={
					cell: cell,
					portals: {}
				};
			}
			cells[ cellId ].portals[ item.guid ]=true;
		}

		function showS2Dialog() {
			const selectRow=`
				<p>{{level}} level of grid to display: <select>
				<option value=0>None</option>
				<option value=6>6</option>
				<option value=7>7</option>
				<option value=8>8</option>
				<option value=9>9</option>
				<option value=10>10</option>
				<option value=11>11</option>
				<option value=12>12</option>
				<option value=13>13</option>
				<option value=14>14</option>
				<option value=15>15</option>
				<option value=16>16</option>
				<option value=17>17</option>
				<option value=18>18</option>
				<option value=19>19</option>
				<option value=20>20</option>
				</select></p>`;

			const html=
				selectRow.replace( '{{level}}', '1st' )+
				selectRow.replace( '{{level}}', '2nd' )+
				`<p><input type="checkbox" id="chkHighlightCandidates" /><label for="chkHighlightCandidates">Highlight Cells that might get a Gym</label></p>
				 <p><input type="checkbox" id="chkHighlightCenters" /><label for="chkHighlightCenters">Put an X in the center of Cells with a Gym<br />(for determining EX-eligibility)</label></p>
				 <p><input type="checkbox" id="chkThisIsPogo" /><label for="chkThisIsPogo" title='Hide Ingress panes, info and whatever that clutters the map and it is useless for Pokemon Go'>This is PoGo!</label></p>
				 <p><input type="checkbox" id="chkanalyzeForMissingData" /><label for="chkanalyzeForMissingData" title="Analyze the portal data to show the pane that suggests new Pokestops and Gyms">Analyze portal data</label></p>
				 <p><input type="checkbox" id="chkcenterMapOnClick" /><label for="chkcenterMapOnClick" title="Center map on portal when clicked in a dialog box.">Center map on click.</label></p>
				 <p><a id='PogoEditColors'>Colors</a></p>
				`;

			const container=dialog( {
				id: 's2Settings',
				width: 'auto',
				html: html,
				title: 'S2 & Pokemon Settings'
			} );

			const div=container[ 0 ];

			const selects=div.querySelectorAll( 'select' );
			for ( let i=0;i<2;i++ ) {
				configureGridLevelSelect( selects[ i ], i );
			}

			const chkHighlight=div.querySelector( '#chkHighlightCandidates' );
			chkHighlight.checked=settings.highlightGymCandidateCells;

			chkHighlight.addEventListener( 'change', e => {
				settings.highlightGymCandidateCells=chkHighlight.checked;
				saveSettings();
				updateMapGrid();
			} );

			const chkHighlightCenters=div.querySelector( '#chkHighlightCenters' );
			chkHighlightCenters.checked=settings.highlightGymCenter;
			chkHighlightCenters.addEventListener( 'change', e => {
				settings.highlightGymCenter=chkHighlightCenters.checked;
				saveSettings();
				updateMapGrid();
			} );

			const chkThisIsPogo=div.querySelector( '#chkThisIsPogo' );
			chkThisIsPogo.checked=!!settings.thisIsPogo;
			chkThisIsPogo.addEventListener( 'change', e => {
				settings.thisIsPogo=chkThisIsPogo.checked;
				saveSettings();
				setThisIsPogo();
			} );

			const chkanalyzeForMissingData=div.querySelector( '#chkanalyzeForMissingData' );
			chkanalyzeForMissingData.checked=!!settings.analyzeForMissingData;
			chkanalyzeForMissingData.addEventListener( 'change', e => {
				settings.analyzeForMissingData=chkanalyzeForMissingData.checked;
				saveSettings();
				if ( newPortals.length>0 ) {
					checkNewPortals();
				}
			} );

			const chkcenterMapOnClick=div.querySelector( '#chkcenterMapOnClick' );
			chkcenterMapOnClick.checked=settings.centerMapOnClick;
			chkcenterMapOnClick.addEventListener( 'change', e => {
				settings.centerMapOnClick=chkcenterMapOnClick.checked;
				saveSettings();
			} );

			const PogoEditColors=div.querySelector( '#PogoEditColors' );
			PogoEditColors.addEventListener( 'click', function( e ) {
				editColors();
				e.preventDefault();
				return false;
			} );
		}

		function editColors() {
			const selectRow=`<p class='pogo-colors'>{{title}}<br>
				Color: <input type='color' id='{{id}}Color'> Opacity: <select id='{{id}}Opacity'>
				<option value=0>0</option>
				<option value=0.1>0.1</option>
				<option value=0.2>0.2</option>
				<option value=0.3>0.3</option>
				<option value=0.4>0.4</option>
				<option value=0.5>0.5</option>
				<option value=0.6>0.6</option>
				<option value=0.7>0.7</option>
				<option value=0.8>0.8</option>
				<option value=0.9>0.9</option>
				<option value=1>1</option>
				</select>{{width}}</p>`;

			const html=
				selectRow.replace( '{{title}}', '1st Grid' ).replace( '{{width}}', ` Width: <input type='number' min='1' max='8' id='{{id}}Width' size='2'> ` ).replace( /{{id}}/g, 'grid0' )+
				selectRow.replace( '{{title}}', '2nd Grid' ).replace( '{{width}}', ` Width: <input type='number' min='1' max='8' id='{{id}}Width' size='2'> ` ).replace( /{{id}}/g, 'grid1' )+
				selectRow.replace( '{{title}}', 'Cells with extra gyms' ).replace( /{{id}}/g, 'cellsExtraGyms' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', 'Cells with missing gyms' ).replace( /{{id}}/g, 'cellsMissingGyms' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', `Cell ${poiCellLevel} with a gym or stop` ).replace( /{{id}}/g, 'cell17Filled' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', `Cell ${gymCellLevel} with 3 gyms` ).replace( /{{id}}/g, 'cell14Filled' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', '20m submit radius border' ).replace( /{{id}}/g, 'nearbyCircleBorder' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', '20m submit radius fill' ).replace( /{{id}}/g, 'nearbyCircleFill' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', '1 more stop to get a gym' ).replace( /{{id}}/g, 'missingStops1' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', '2 more stops to get a gym' ).replace( /{{id}}/g, 'missingStops2' ).replace( '{{width}}', '' )+
				selectRow.replace( '{{title}}', '3 more stops to get a gym' ).replace( /{{id}}/g, 'missingStops3' ).replace( '{{width}}', '' )+
				'<a id="resetColorsLink">Reset all colors</a>'
				;

			const container=dialog( {
				id: 's2Colors',
				width: 'auto',
				html: html,
				title: 'PoGo Grid Colors'
			} );

			const div=container[ 0 ];

			const updatedSetting=function( id ) {
				saveSettings();
				if ( id=='nearbyCircleBorder'||id=='nearbyCircleFill' ) {
					redrawNearbyCircles();
				} else {
					updateMapGrid();
				}
			};

			const configureItems=function( key, item, id ) {
				if ( !id )
					id=item;

				const entry=settings[ key ][ item ];
				const select=div.querySelector( '#'+id+'Opacity' );
				select.value=entry.opacity;
				select.addEventListener( 'change', function( event ) {
					settings[ key ][ item ].opacity=select.value;
					updatedSetting( id );
				} );

				const input=div.querySelector( '#'+id+'Color' );
				input.value=entry.color;
				input.addEventListener( 'change', function( event ) {
					settings[ key ][ item ].color=input.value;
					updatedSetting( id );
				} );

				if ( entry.width!=null ) {
					const widthInput=div.querySelector( '#'+id+'Width' );
					widthInput.value=entry.width;
					widthInput.addEventListener( 'change', function( event ) {
						settings[ key ][ item ].width=widthInput.value;
						updatedSetting( id );
					} );
				}
			};

			configureItems( 'grids', 0, 'grid0' );
			configureItems( 'grids', 1, 'grid1' );
			configureItems( 'colors', 'cellsExtraGyms' );
			configureItems( 'colors', 'cellsMissingGyms' );
			configureItems( 'colors', 'cell17Filled' );
			configureItems( 'colors', 'cell14Filled' );
			configureItems( 'colors', 'nearbyCircleBorder' );
			configureItems( 'colors', 'nearbyCircleFill' );
			configureItems( 'colors', 'missingStops1' );
			configureItems( 'colors', 'missingStops2' );
			configureItems( 'colors', 'missingStops3' );

			const resetColorsLink=div.querySelector( '#resetColorsLink' );
			resetColorsLink.addEventListener( 'click', function() {
				container.dialog( 'close' );
				resetColors();
				updatedSetting( 'nearbyCircleBorder' );
				updatedSetting();
				editColors();
			} );
		}

		/**
		 * Refresh the S2 grid over the map
		 */
		function updateMapGrid() {
			// preconditions
			if ( !map.hasLayer( regionLayer ) ) {
				return;
			}
			const zoom=map.getZoom();

			// first draw nearby circles at the bottom
			if ( zoom>16 ) {
				if ( !regionLayer.hasLayer( nearbyLayerGroup ) ) {
					regionLayer.addLayer( nearbyLayerGroup );
				}
				nearbyLayerGroup.bringToBack();
			} else if ( regionLayer.hasLayer( nearbyLayerGroup ) ) {
				regionLayer.removeLayer( nearbyLayerGroup );
			}

			// shade level 14 and level 17 cells
			let cellsCloseToThreshold;
			if ( settings.highlightGymCandidateCells&&zoom>14 ) {
				cellsCloseToThreshold=updateCandidateCells( zoom );
				if ( !regionLayer.hasLayer( cellLayerGroup ) ) {
					regionLayer.addLayer( cellLayerGroup );
				}
				cellLayerGroup.bringToBack();
			} else if ( regionLayer.hasLayer( cellLayerGroup ) ) {
				regionLayer.removeLayer( cellLayerGroup );
			}

			// then draw the cell grid
			if ( zoom>4 ) {
				drawCellGrid( zoom );

				// update cell grid with cells close to a threshold for a gym
				if ( cellsCloseToThreshold ) {
					// draw missing cells in reverse order
					for ( let missingStops=3;missingStops>=1;missingStops-- ) {
						const color=settings.colors[ 'missingStops'+missingStops ].color;
						const opacity=settings.colors[ 'missingStops'+missingStops ].opacity;
						cellsCloseToThreshold[ missingStops ].forEach( cell => gridLayerGroup.addLayer( drawCell( cell, color, 3, opacity ) ) );
					}
				}

				if ( !regionLayer.hasLayer( gridLayerGroup ) ) {
					regionLayer.addLayer( gridLayerGroup );
				}
			} else if ( regionLayer.hasLayer( gridLayerGroup ) ) {
				regionLayer.removeLayer( gridLayerGroup );
			}

			// update gym centers
			if ( settings.highlightGymCenter&&zoom>16 ) {
				updateGymCenters();
				if ( !regionLayer.hasLayer( gymCenterLayerGroup ) ) {
					regionLayer.addLayer( gymCenterLayerGroup );
				}
			} else if ( regionLayer.hasLayer( gymCenterLayerGroup ) ) {
				regionLayer.removeLayer( gymCenterLayerGroup );
			}
		}

		function getLatLngPoint( data ) {
			const result={
				lat: typeof data.lat=='function'? data.lat():data.lat,
				lng: typeof data.lng=='function'? data.lng():data.lng
			};

			return result;
		}

		/**
		 * Highlight cells that are missing a few stops to get another gym. Also fills level 17 cells with a stop/gym.
		 * based on data from https://www.reddit.com/r/TheSilphRoad/comments/7ppb3z/gyms_pok%C3%A9stops_and_s2_cells_followup_research/
		 * Cut offs: 2, 6, 20
		 */
		function updateCandidateCells( zoom ) {
			cellLayerGroup.clearLayers();

			// All cells with items
			const allCells=groupByCell( gymCellLevel );

			const bounds=map.getBounds();
			const seenCells={};
			const cellsCloseToThreshold={
				1: [],
				2: [],
				3: []
			};

			const drawCellAndNeighbors=function( cell ) {
				const cellStr=cell.toString();

				if ( !seenCells[ cellStr ] ) {
					// cell not visited - flag it as visited now
					seenCells[ cellStr ]=true;

					if ( isCellOnScreen( bounds, cell ) ) {
						// on screen - draw it
						const cellData=allCells[ cellStr ];
						if ( cellData ) {
							// check for errors
							const missingGyms=computeMissingGyms( cellData );
							if ( missingGyms>0&&!ignoredCellsMissingGyms[ cellStr ] ) {
								cellLayerGroup.addLayer( fillCell( cell, settings.colors.cellsMissingGyms.color, settings.colors.cellsMissingGyms.opacity ) );
							} else if ( missingGyms<0&&!ignoredCellsExtraGyms[ cellStr ] ) {
								cellLayerGroup.addLayer( fillCell( cell, settings.colors.cellsExtraGyms.color, settings.colors.cellsExtraGyms.opacity ) );
								if ( !cellsExtraGyms[ cellStr ] ) {
									cellsExtraGyms[ cellStr ]=true;
									updateCounter( 'extraGyms', Object.keys( cellsExtraGyms ) );
								}
							}

							// shade filled level 17 cells
							if ( zoom>15 ) {
								const subCells={};

								const coverLevel17Cell=function( point ) {
									const cell=S2.S2Cell.FromLatLng( point, poiCellLevel );
									const cellId=cell.toString();
									if ( subCells[ cellId ] )
										return;
									subCells[ cellId ]=true;
									cellLayerGroup.addLayer( fillCell( cell, settings.colors.cell17Filled.color, settings.colors.cell17Filled.opacity ) );
								};

								cellData.gyms.forEach( coverLevel17Cell );
								cellData.stops.forEach( coverLevel17Cell );
							}

							// number of stops to next gym
							const missingStops=computeMissingStops( cellData );
							switch ( missingStops ) {
								case 0:
									if ( missingGyms<=0 ) {
										cellLayerGroup.addLayer( fillCell( cell, settings.colors.cell14Filled.color, settings.colors.cell14Filled.opacity ) );
									}
									break;
								case 1:
								case 2:
								case 3:
									cellsCloseToThreshold[ missingStops ].push( cell );
									break;
								default:
									break;
							}
							cellLayerGroup.addLayer( writeInCell( cell, missingStops ) );
						}

						// and recurse to our neighbors
						const neighbors=cell.getNeighbors();
						for ( let i=0;i<neighbors.length;i++ ) {
							drawCellAndNeighbors( neighbors[ i ] );
						}
					}
				}
			};

			const cell=S2.S2Cell.FromLatLng( getLatLngPoint( map.getCenter() ), gymCellLevel );
			drawCellAndNeighbors( cell );

			return cellsCloseToThreshold;
		}

		function drawCellGrid( zoom ) {
			// clear, to redraw
			gridLayerGroup.clearLayers();
			countLayer.clearLayers();

			const bounds=map.getBounds();
			const seenCells={};
			const drawCellAndNeighbors=function( cell, color, width, opacity ) {
				const cellStr=cell.toString();

				if ( !seenCells[ cellStr ] ) {
					// cell not visited - flag it as visited now
					seenCells[ cellStr ]=true;

					if ( isCellOnScreen( bounds, cell ) ) {
						// on screen - draw it
						gridLayerGroup.addLayer( drawCell( cell, color, width, opacity ) );

						// show number of PoI in the cell
						var cellGroup=cellsPortals[ cellStr ];
						if ( cellGroup )
							countLayer.addLayer( writeInCell( cell, Object.keys( cellGroup.portals ).length ) );

						// and recurse to our neighbors
						const neighbors=cell.getNeighbors();
						for ( let i=0;i<neighbors.length;i++ ) {
							drawCellAndNeighbors( neighbors[ i ], color, width, opacity );
						}
					}
				}
			};

			for ( let i=settings.grids.length-1;i>=0;--i ) {
				const grid=settings.grids[ i ];
				const gridLevel=grid.level;
				if ( gridLevel>=6&&gridLevel<( zoom+2 ) ) {
					const cell=S2.S2Cell.FromLatLng( getLatLngPoint( map.getCenter() ), gridLevel );
					drawCellAndNeighbors( cell, grid.color, grid.width, grid.opacity );
				}
			}
		}

		/**
		 * Draw a cross to the center of level 20 cells that have a Gym to check better EX locations
		 */
		function updateGymCenters() {
			// clear
			gymCenterLayerGroup.clearLayers();

			const visibleGyms=filterItemsByMapBounds( gyms );
			const level=20;

			Object.keys( visibleGyms ).forEach( id => {
				const gym=gyms[ id ];
				const cell=S2.S2Cell.FromLatLng( gym, level );
				const corners=cell.getCornerLatLngs();
				// center point
				const center=cell.getLatLng();

				const style={ fill: false, color: 'red', opacity: 0.8, weight: 1, clickable: false, interactive: false };
				const line1=L.polyline( [ corners[ 0 ], corners[ 2 ] ], style );
				gymCenterLayerGroup.addLayer( line1 );

				const line2=L.polyline( [ corners[ 1 ], corners[ 3 ] ], style );
				gymCenterLayerGroup.addLayer( line2 );

				const circle=L.circle( center, 1, style );
				gymCenterLayerGroup.addLayer( circle );
			} );
		}

		// Computes how many new stops must be added to the L14 Cell to get a new Gym
		function computeMissingStops( cellData ) {
			const gyms=cellData.gyms.length;
			// exclude from the count those pokestops that have been marked as missing photos
			const validStops=cellData.stops.filter( p => typeof p.photos=='undefined'||p.photos>0 );
			const sum=gyms+validStops.length;
			if ( sum<2&&gyms==0 )
				return 2-sum;

			if ( sum<6&&gyms<2 )
				return 6-sum;

			if ( sum<20&&gyms<3 )
				return 20-sum;

			// No options to more gyms ATM.
			return 0;
		}

		// Checks if the L14 cell has enough Gyms and Stops and one of the stops should be marked as a Gym
		// If the result is negative then it has extra gyms
		function computeMissingGyms( cellData ) {
			const totalGyms=cellData.gyms.length;
			// exclude from the count those pokestops that have been marked as missing photos
			const validStops=cellData.stops.filter( p => typeof p.photos=='undefined'||p.photos>0 );
			const sum=totalGyms+validStops.length;
			if ( sum<2 )
				return 0-totalGyms;

			if ( sum<6 )
				return 1-totalGyms;

			if ( sum<20 )
				return 2-totalGyms;

			return 3-totalGyms;
		}

		function drawCell( cell, color, weight, opacity ) {
			// corner points
			const corners=cell.getCornerLatLngs();

			// the level 6 cells have noticible errors with non-geodesic lines - and the larger level 4 cells are worse
			// NOTE: we only draw two of the edges. as we draw all cells on screen, the other two edges will either be drawn
			// from the other cell, or be off screen so we don't care
			const region=L.polyline( [ corners[ 0 ], corners[ 1 ], corners[ 2 ], corners[ 3 ], corners[ 0 ] ], { fill: false, color: color, opacity: opacity, weight: weight, clickable: false, interactive: false } );

			return region;
		}

		function fillCell( cell, color, opacity ) {
			// corner points
			const corners=cell.getCornerLatLngs();

			const region=L.polygon( corners, { color: color, fillOpacity: opacity, weight: 0, clickable: false, interactive: false } );

			return region;
		}

		/**
		*	Writes a text in the center of a cell
		*/
		function writeInCell( cell, text ) {
			// center point
			let center=cell.getLatLng();

			let marker=L.marker( center, {
				icon: L.divIcon( {
					className: 'pogo-text',
					iconAnchor: [ 25, 5 ],
					iconSize: [ 50, 10 ],
					html: text
				} )
			} );
			// fixme, maybe add some click handler
			marker.on( 'click', function() {
				displayCellSummary( cell );
			} );
			return marker;
		}

		/**
		Show a summary with the pokestops and gyms of a L14 Cell
		*/
		function displayCellSummary( cell ) {
			const cellStr=cell.toString();

			const allCells=groupByCell( gymCellLevel );
			const cellData=allCells[ cellStr ];
			if ( !cellData )
				return;

			function updateScore( portal, wrapper ) {
				const photos=typeof portal.photos=='undefined'? 1:portal.photos;
				const votes=photos==0||typeof portal.votes=='undefined'? 0:portal.votes;
				const score=photos+votes;
				wrapper.querySelector( '.Pogo_Score' ).textContent=score;
			}

			function dumpGroup( data, title, useHeader ) {
				const div=document.createElement( 'div' );
				const header=document.createElement( 'h3' );
				if ( useHeader ) {
					header.className='header';
					header.innerHTML='<span>'+title+' ('+data.length+')</span><span>Photos</span><span>Votes</span><span>Score</span>';
				} else {
					header.textContent=title+' ('+data.length+')';
				}
				div.appendChild( header );

				data.sort( sortByName ).forEach( portal => {
					const wrapper=document.createElement( 'div' );
					wrapper.setAttribute( 'data-guid', portal.guid );
					wrapper.className='PortalSummary';
					const img=getPortalImage( portal );
					let scoreData='';

					if ( title=='Pokestops'||title=='Portals' ) {
						const photos=typeof portal.photos=='undefined'? 1:portal.photos;
						const votes=typeof portal.votes=='undefined'? 0:portal.votes;
						scoreData='<span><input type="number" min=0 value='+photos+' title="Total number of photos of this portal" class="Pogo_Photos"></span>'+
							'<span><input type="number" min=0 value='+votes+' title="Total sum of votes in the portal" class="Pogo_Votes"></span>'+
							'<span class="Pogo_Score" title="Gym score: The pokestops with highest score will become the next gym">'+( photos+votes )+'</span>';
					}
					wrapper.innerHTML='<span class="PogoName">'+img+'</span>'+
						'<span>'+getPortalName( portal )+'</span>'+
						scoreData
						;

					if ( scoreData!='' ) {
						wrapper.querySelector( '.Pogo_Photos' ).addEventListener( 'input', function() {
							const update=portal.photos!==this.valueAsNumber&&( portal.photos===0||this.valueAsNumber===0 );
							portal.photos=this.valueAsNumber;
							updateScore( portal, wrapper );
							saveStorage();
							if ( update ) {
								refreshPokestopMissingPhotoStatus( portal );
								updateMapGrid();
							}
						} );
						wrapper.querySelector( '.Pogo_Votes' ).addEventListener( 'input', function() {
							portal.votes=this.valueAsNumber;
							updateScore( portal, wrapper );
							saveStorage();
						} );
					}

					div.appendChild( wrapper );
				} );
				return div;
			}

			const div=document.createElement( 'div' );
			div.appendChild( dumpGroup( cellData.gyms, 'Gyms' ) );
			div.appendChild( dumpGroup( cellData.stops, 'Pokestops', true ) );
			//div.appendChild(dumpGroup(cellData.notClassified, 'Other portals')); They don't matter, they have been removed from Pokemon
			//div.appendChild(dumpGroup(cellData.portals, 'Portals', true)); FIXME: portals from Ingress that are hidden in Pokemon
			div.className='PogoListing';
			const width=Math.min( screen.availWidth, 420 );
			const container=dialog( {
				id: 'PokemonList',
				html: div,
				width: width+'px',
				title: 'List of Pokestops and Gyms'
			} );

			configureHoverMarker( container );
		}

		// ***************************
		// IITC code
		// ***************************

		// ensure plugin framework is there, even if iitc is not yet loaded
		if ( typeof window.plugin!=='function' ) {
			window.plugin=function() { };
		}

		// PLUGIN START

		// use own namespace for plugin
		window.plugin.pogo=function() { };

		const thisPlugin=window.plugin.pogo;
		const KEY_STORAGE='plugin-pogo';
		const KEY_SETTINGS='plugin-pogo-settings';

		// Update the localStorage
		function saveStorage() {
			createThrottledTimer( 'saveStorage', function() {
				localStorage[ KEY_STORAGE ]=JSON.stringify( {
					gyms: cleanUpExtraData( gyms ),
					pokestops: cleanUpExtraData( pokestops ),
					notpogo: cleanUpExtraData( notpogo ),
					ignoredCellsExtraGyms: ignoredCellsExtraGyms,
					ignoredCellsMissingGyms: ignoredCellsMissingGyms
				} );
			} );
		}

		/**
		 * Create a new object where the extra properties of each pokestop/gym have been removed. Store only the minimum.
		 */
		function cleanUpExtraData( group ) {
			let newGroup={};
			Object.keys( group ).forEach( id => {
				const data=group[ id ];
				const newData={
					guid: data.guid,
					lat: data.lat,
					lng: data.lng,
					name: data.name
				};

				if ( data.isEx )
					newData.isEx=data.isEx;

				if ( data.medal )
					newData.medal=data.medal;

				if ( typeof data.photos!='undefined' )
					newData.photos=data.photos;

				if ( data.votes )
					newData.votes=data.votes;

				newGroup[ id ]=newData;
			} );
			return newGroup;
		}

		// Load the localStorage
		thisPlugin.loadStorage=function() {
			const tmp=JSON.parse( localStorage[ KEY_STORAGE ]||'{}' );
			gyms=tmp.gyms||{};
			pokestops=tmp.pokestops||{};
			notpogo=tmp.notpogo||{};
			ignoredCellsExtraGyms=tmp.ignoredCellsExtraGyms||{};
			ignoredCellsMissingGyms=tmp.ignoredCellsMissingGyms||{};
		};

		thisPlugin.createEmptyStorage=function() {
			gyms={};
			pokestops={};
			notpogo={};
			ignoredCellsExtraGyms={};
			ignoredCellsMissingGyms={};
			saveStorage();

			allPortals={};
			newPortals={};

			movedPortals=[];
			missingPortals={};
		};

		/*************************************************************************/

		thisPlugin.findByGuid=function( guid ) {
			if ( gyms[ guid ] ) {
				return { 'type': 'gyms', 'store': gyms };
			}
			if ( pokestops[ guid ] ) {
				return { 'type': 'pokestops', 'store': pokestops };
			}
			if ( notpogo[ guid ] ) {
				return { 'type': 'notpogo', 'store': notpogo };
			}
			return null;
		};

		// Append a 'star' flag in sidebar.
		thisPlugin.onPortalSelectedPending=false;
		thisPlugin.onPortalSelected=function() {
			$( '.pogoStop' ).remove();
			$( '.pogoGym' ).remove();
			$( '.notPogo' ).remove();
			const portalDetails=document.getElementById( 'portaldetails' );
			portalDetails.classList.remove( 'isGym' );

			if ( window.selectedPortal==null ) {
				return;
			}

			if ( !thisPlugin.onPortalSelectedPending ) {
				thisPlugin.onPortalSelectedPending=true;

				setTimeout( function() { // the sidebar is constructed after firing the hook
					thisPlugin.onPortalSelectedPending=false;

					$( '.pogoStop' ).remove();
					$( '.pogoGym' ).remove();
					$( '.notPogo' ).remove();

					// Show PoGo icons in the mobile status-bar
					if ( thisPlugin.isSmart ) {
						document.querySelector( '.PogoStatus' ).innerHTML=thisPlugin.htmlStar;
						$( '.PogoStatus > a' ).attr( 'title', '' );
					}

					$( portalDetails ).append( '<div class="PogoButtons">Pokemon Go: '+thisPlugin.htmlStar+'</div>'+
						`<div id="PogoGymInfo">
						<label for='PogoGymMedal'>Medal:</label> <select id='PogoGymMedal'>
								<option value='None'>None</option>
								<option value='Bronze'>Bronze</option>
								<option value='Silver'>Silver</option>
								<option value='Gold'>Gold</option>
								</select><br>
						<label>Is this an EX gym? <input type='checkbox' id='PogoGymEx'> Yes</label><br>
					</div>`);

					document.getElementById( 'PogoGymMedal' ).addEventListener( 'change', ev => {
						const guid=window.selectedPortal;
						const icon=document.getElementById( 'gym'+guid.replace( '.', '' ) );
						// remove styling of gym marker
						if ( icon ) {
							icon.classList.remove( gyms[ guid ].medal+'Medal' );
						}
						gyms[ guid ].medal=ev.target.value;
						saveStorage();
						// update gym marker
						if ( icon ) {
							icon.classList.add( gyms[ guid ].medal+'Medal' );
						}
					} );

					document.getElementById( 'PogoGymEx' ).addEventListener( 'change', ev => {
						const guid=window.selectedPortal;
						const icon=document.getElementById( 'gym'+guid.replace( '.', '' ) );
						gyms[ guid ].isEx=ev.target.checked;
						saveStorage();
						// update gym marker
						if ( icon ) {
							icon.classList[ gyms[ guid ].isEx? 'add':'remove' ]( 'exGym' );
						}
					} );

					thisPlugin.updateStarPortal();
				}, 0 );
			}
		};

		// Update the status of the star (when a portal is selected from the map/pogo-list)
		thisPlugin.updateStarPortal=function() {
			$( '.pogoStop' ).removeClass( 'favorite' );
			$( '.pogoGym' ).removeClass( 'favorite' );
			$( '.notPogo' ).removeClass( 'favorite' );
			document.getElementById( 'portaldetails' ).classList.remove( 'isGym' );

			const guid=window.selectedPortal;
			// If current portal is into pogo: select pogo portal from portals list and select the star
			const pogoData=thisPlugin.findByGuid( guid );
			if ( pogoData ) {
				if ( pogoData.type==='pokestops' ) {
					$( '.pogoStop' ).addClass( 'favorite' );
				}
				if ( pogoData.type==='gyms' ) {
					$( '.pogoGym' ).addClass( 'favorite' );
					document.getElementById( 'portaldetails' ).classList.add( 'isGym' );
					const gym=gyms[ guid ];
					if ( gym.medal ) {
						document.getElementById( 'PogoGymMedal' ).value=gym.medal;
					}
					document.getElementById( 'PogoGymEx' ).checked=gym.isEx;

				}
				if ( pogoData.type==='notpogo' ) {
					$( '.notPogo' ).addClass( 'favorite' );
				}
			}
		};

		function removePogoObject( type, guid ) {
			if ( type==='pokestops' ) {
				delete pokestops[ guid ];
				const starInLayer=stopLayers[ guid ];
				stopLayerGroup.removeLayer( starInLayer );
				delete stopLayers[ guid ];
			}
			if ( type==='gyms' ) {
				delete gyms[ guid ];
				const gymInLayer=gymLayers[ guid ];
				gymLayerGroup.removeLayer( gymInLayer );
				delete gymLayers[ guid ];
			}
			if ( type==='notpogo' ) {
				delete notpogo[ guid ];
			}
		}

		// Switch the status of the star
		thisPlugin.switchStarPortal=function( type ) {
			const guid=window.selectedPortal;

			// It has been manually classified, remove from the detection
			if ( newPortals[ guid ] )
				delete newPortals[ guid ];

			// If portal is saved in pogo: Remove this pogo
			const pogoData=thisPlugin.findByGuid( guid );
			if ( pogoData ) {
				const existingType=pogoData.type;
				removePogoObject( existingType, guid );

				saveStorage();
				thisPlugin.updateStarPortal();

				// Get portal name and coordinates
				const p=window.portals[ guid ];
				const ll=p.getLatLng();
				if ( existingType!==type ) {
					thisPlugin.addPortalpogo( guid, ll.lat, ll.lng, p.options.data.title, type );
				}
				// we've changed one item from pogo, if the cell was marked as ignored, reset it.
				if ( ( type=='gyms'||existingType=='gyms' )&&updateExtraGymsCells( ll.lat, ll.lng ) )
					saveStorage();
			} else {
				// If portal isn't saved in pogo: Add this pogo

				// Get portal name and coordinates
				const portal=window.portals[ guid ];
				const latlng=portal.getLatLng();
				thisPlugin.addPortalpogo( guid, latlng.lat, latlng.lng, portal.options.data.title, type );
			}

			if ( settings.highlightGymCandidateCells ) {
				updateMapGrid();
			}
		};

		// Add portal
		thisPlugin.addPortalpogo=function( guid, lat, lng, name, type ) {
			// Add pogo in the localStorage
			const obj={ 'guid': guid, 'lat': lat, 'lng': lng, 'name': name };

			// prevent that it would trigger the missing portal detection if it's in our data
			if ( window.portals[ guid ] ) {
				obj.exists=true;
			}

			if ( type=='gyms' ) {
				updateExtraGymsCells( lat, lng );
				gyms[ guid ]=obj;
			}
			if ( type=='pokestops' ) {
				pokestops[ guid ]=obj;
			}
			if ( type=='notpogo' ) {
				notpogo[ guid ]=obj;
			}

			saveStorage();
			thisPlugin.updateStarPortal();

			thisPlugin.addStar( guid, lat, lng, name, type );
		};

		/**
		 * An item has been changed in a cell, check if the cell should no longer be ignored
		 */
		function updateExtraGymsCells( lat, lng ) {
			if ( Object.keys( ignoredCellsExtraGyms ).length==0&&Object.keys( ignoredCellsMissingGyms ).length==0 )
				return false;

			const cell=S2.S2Cell.FromLatLng( new L.LatLng( lat, lng ), gymCellLevel );
			const cellId=cell.toString();
			if ( ignoredCellsExtraGyms[ cellId ] ) {
				delete ignoredCellsExtraGyms[ cellId ];
				return true;
			}
			if ( ignoredCellsMissingGyms[ cellId ] ) {
				delete ignoredCellsMissingGyms[ cellId ];
				return true;
			}
			return false;
		}

		/*
			OPTIONS
		*/
		// Manual import, export and reset data
		thisPlugin.pogoActionsDialog=function() {
			const content=`<div id="pogoSetbox">
				<a id="save-dialog" title="Select the data to save from the info on screen">Save...</a>
				<a onclick="window.plugin.pogo.optReset();return false;" title="Deletes all Pokemon Go markers">Reset PoGo portals</a>
				<a onclick="window.plugin.pogo.optImport();return false;" title="Import a JSON file with all the PoGo data">Import Gyms & Pokestops</a>
				<a onclick="window.plugin.pogo.optExport();return false;" title="Exports a JSON file with all the PoGo data">Export Gyms & Pokestops</a>
				</div>`;

			const container=dialog( {
				html: content,
				title: 'S2 & Pokemon Actions'
			} );

			const div=container[ 0 ];
			div.querySelector( '#save-dialog' ).addEventListener( 'click', e => saveDialog() );
		};

		function saveDialog() {
			const content=`<div>
				<p>Select the data to save from the info on screen</p>
				<fieldset><legend>Which data?</legend>
				<input type='radio' name='PogoSaveDataType' value='Gyms' id='PogoSaveDataTypeGyms'><label for='PogoSaveDataTypeGyms'>Gyms</label><br>
				<input type='radio' name='PogoSaveDataType' value='PokeStopsGyms' id='PogoSaveDataTypePokeStopsGyms'><label for='PogoSaveDataTypePokeStopsGyms'>Pokestops + Gyms</label>
				</fieldset>
				<fieldset><legend>Format</legend>
				<input type='radio' name='PogoSaveDataFormat' value='CSV' id='PogoSaveDataFormatCSV'><label for='PogoSaveDataFormatCSV'>CSV</label><br>
				<input type='radio' name='PogoSaveDataFormat' value='JSON' id='PogoSaveDataFormatJSON'><label for='PogoSaveDataFormatJSON'>JSON</label>
				</fieldset>
				</div>`;

			const container=dialog( {
				html: content,
				title: 'Save visible data',
				buttons: {
					'Save': function() {
						const SaveDataType=document.querySelector( 'input[name="PogoSaveDataType"]:checked' ).value;
						const SaveDataFormat=document.querySelector( 'input[name="PogoSaveDataFormat"]:checked' ).value;

						settings.saveDataType=SaveDataType;
						settings.saveDataFormat=SaveDataFormat;
						saveSettings();

						container.dialog( 'close' );

						let filename=( SaveDataType=='Gyms'? 'gyms_':'gyms+stops_' )+new Date().toISOString().substr( 0, 19 ).replace( /[\D]/g, '_' );
						if ( SaveDataFormat=='CSV' ) {
							filename+='.csv';
							const allData=SaveDataType=='Gyms'? gyms:Object.assign( {}, gyms, pokestops );
							const data=filterItemsByMapBounds( allData );
							const keys=Object.keys( data );
							const contents=keys.map( id => {
								const gym=data[ id ];
								return ( gym.name? gym.name.replace( /,/g, ' ' )+',':'' )+gym.lat+','+gym.lng;
							} );

							saveToFile( contents.join( '\n' ), filename );
						} else {
							filename+='.json';
							const data={
								gyms: findPhotos( cleanUpExtraData( filterItemsByMapBounds( gyms ) ) )
							};
							if ( SaveDataType!='Gyms' )
								data.pokestops=findPhotos( cleanUpExtraData( filterItemsByMapBounds( pokestops ) ) );

							saveToFile( JSON.stringify( data ), filename );
						}
					}
				}

			} );

			// Remove ok button
			const outer=container.parent();
			outer.find( '.ui-dialog-buttonset button:first' ).remove();

			const div=container[ 0 ];
			div.querySelector( '#PogoSaveDataType'+settings.saveDataType ).checked=true;
			div.querySelector( '#PogoSaveDataFormat'+settings.saveDataFormat ).checked=true;
		}

		thisPlugin.optAlert=function( message ) {
			$( '.ui-dialog .ui-dialog-buttonset' ).prepend( '<p class="pogo-alert" style="float:left;margin-top:4px;">'+message+'</p>' );
			$( '.pogo-alert' ).delay( 2500 ).fadeOut();
		};

		thisPlugin.optExport=function() {
			saveToFile( localStorage[ KEY_STORAGE ], 'IITC-pogo.json' );
		};

		thisPlugin.optImport=function() {
			readFromFile( function( content ) {
				try {
					const list=JSON.parse( content ); // try to parse JSON first
					let importExStatus=true;
					let importGymMedal=true;
					Object.keys( list ).forEach( type => {
						for ( let idpogo in list[ type ] ) {
							const item=list[ type ][ idpogo ];
							const lat=item.lat;
							const lng=item.lng;
							const name=item.name;
							let guid=item.guid;
							if ( !guid ) {
								guid=findPortalGuidByPositionE6( lat*1E6, lng*1E6 );
								if ( !guid ) {
									console.log( 'portal guid not found', name, lat, lng ); // eslint-disable-line no-console
									guid=idpogo;
								}
							}

							if ( typeof lat!=='undefined'&&typeof lng!=='undefined'&&name&&!thisPlugin.findByGuid( guid ) ) {
								thisPlugin.addPortalpogo( guid, lat, lng, name, type );
								if ( type=='gyms' ) {
									if ( importExStatus&&item.isEx ) {
										gyms[ guid ].isEx=true;
									}
									// don't overwrite existing medals
									if ( importGymMedal&&!gyms[ guid ].medal ) {
										gyms[ guid ].medal=item.medal;
									}
								}
							}
						}
					} );

					thisPlugin.updateStarPortal();
					thisPlugin.resetAllMarkers();
					thisPlugin.optAlert( 'Successful.' );
				} catch ( e ) {
					console.warn( 'pogo: failed to import data: '+e ); // eslint-disable-line no-console
					thisPlugin.optAlert( '<span style="color: #f88">Import failed</span>' );
				}
			} );
		};

		thisPlugin.optReset=function() {
			if ( confirm( 'All pogo will be deleted. Are you sure?', '' ) ) {
				delete localStorage[ KEY_STORAGE ];
				thisPlugin.createEmptyStorage();
				thisPlugin.updateStarPortal();
				thisPlugin.resetAllMarkers();
				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}
				thisPlugin.optAlert( 'Successful.' );
			}
		};

		/* POKEMON GO PORTALS LAYER */
		thisPlugin.addAllMarkers=function() {
			function iterateStore( store, type ) {
				for ( let idpogo in store ) {
					const item=store[ idpogo ];
					const lat=item.lat;
					const lng=item.lng;
					const guid=item.guid;
					const name=item.name;
					if ( guid!=null )
						thisPlugin.addStar( guid, lat, lng, name, type );
				}
			}

			iterateStore( gyms, 'gyms' );
			iterateStore( pokestops, 'pokestops' );
		};

		thisPlugin.resetAllMarkers=function() {
			for ( let guid in stopLayers ) {
				const starInLayer=stopLayers[ guid ];
				stopLayerGroup.removeLayer( starInLayer );
				delete stopLayers[ guid ];
			}
			for ( let gymGuid in gymLayers ) {
				const gymInLayer=gymLayers[ gymGuid ];
				gymLayerGroup.removeLayer( gymInLayer );
				delete gymLayers[ gymGuid ];
			}
			thisPlugin.addAllMarkers();
		};

		/**
		* Update the disk color and title if the portal has no photo or switches to have at least one
		*/
		function refreshPokestopMissingPhotoStatus( portal ) {
			const hasPhoto=typeof portal.photos=='undefined'||portal.photos>0;
			const guid=portal.guid;
			const icon=document.getElementById( 'pokestop'+guid.replace( '.', '' ) );
			if ( icon ) {
				icon.classList.toggle( 'missingPhoto', !hasPhoto );
				icon.title=portal.name+( !hasPhoto? '\r\n<br>Missing Photo, add one to make it count for Gym creation.':'' );
			}
		}

		thisPlugin.addStar=function( guid, lat, lng, name, type ) {
			let star;
			if ( type==='pokestops' ) {
				const pokestop=pokestops[ guid ];
				const hasPhoto=typeof pokestop.photos=='undefined'||pokestop.photos>0;

				star=new L.Marker.SVGMarker( [ lat, lng ], {
					title: name+( !hasPhoto? '\r\n<br>Missing Photo, add one to make it count for Gym creation.':'' ),
					iconOptions: {
						className: 'pokestop'+( !hasPhoto? ' missingPhoto':'' ),
						html: `<svg
											width="42.630802"
											height="78.489388"
											viewBox="0 0 42.630805 78.489391"
											id="svg2"
											version="1.1"
											inkscape:version="1.3 (0e150ed, 2023-07-21)"
											sodipodi:docname="pokestop.svg"
											inkscape:export-filename="pokestop.svg"
											inkscape:export-xdpi="96"
											inkscape:export-ydpi="96"
											xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
											xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
											xmlns:xlink="http://www.w3.org/1999/xlink"
											xmlns="http://www.w3.org/2000/svg"
											xmlns:svg="http://www.w3.org/2000/svg"
											xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
											xmlns:cc="http://creativecommons.org/ns#"
											xmlns:dc="http://purl.org/dc/elements/1.1/">
											<title
												id="title12">Pokestop</title>
											<defs
												id="defs4">
												<color-profile
													name="Color-LCD-Calibrated"
													xlink:href="../../../Library/ColorSync/Profiles/Color%20LCD%20Calibrated.icc"
													id="color-profile2" />
												<inkscape:perspective
													sodipodi:type="inkscape:persp3d"
													inkscape:vp_x="-19.480379 : 38.912155 : 1"
													inkscape:vp_y="0 : 2249.4649 : 0"
													inkscape:vp_z="62.881102 : 38.912155 : 1"
													inkscape:persp3d-origin="21.700363 : 25.790278 : 1"
													id="perspective3" />
											</defs>
											<sodipodi:namedview
												id="base"
												pagecolor="#ffffff"
												bordercolor="#666666"
												borderopacity="1.0"
												inkscape:pageopacity="0.0"
												inkscape:pageshadow="2"
												inkscape:zoom="4.2430478"
												inkscape:cx="50.788963"
												inkscape:cy="41.950976"
												inkscape:document-units="px"
												inkscape:current-layer="layer1"
												showgrid="true"
												units="px"
												inkscape:window-width="1280"
												inkscape:window-height="747"
												inkscape:window-x="0"
												inkscape:window-y="25"
												inkscape:window-maximized="1"
												inkscape:snap-bbox="true"
												inkscape:bbox-nodes="false"
												inkscape:snap-bbox-edge-midpoints="true"
												inkscape:snap-bbox-midpoints="false"
												showguides="true"
												inkscape:guide-bbox="true"
												inkscape:showpageshadow="2"
												inkscape:pagecheckerboard="0"
												inkscape:deskcolor="#d1d1d1"
												inkscape:export-bgcolor="#fcfcfc00">
												<inkscape:grid
													type="xygrid"
													id="grid4152"
													units="px"
													spacingx="1"
													spacingy="1"
													originx="-0.31364591"
													originy="-0.20338756"
													visible="true" />
											</sodipodi:namedview>
											<metadata
												id="metadata7">
												<rdf:RDF>
													<cc:Work
														rdf:about="">
														<dc:format>image/svg+xml</dc:format>
														<dc:type
															rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
														<dc:title>Pokestop</dc:title>
													</cc:Work>
												</rdf:RDF>
											</metadata>
											<g
												inkscape:label="Layer 1"
												inkscape:groupmode="layer"
												id="layer1"
												transform="translate(-0.31364591,-1035.5655)"
												style="display:inline">
												<g
													id="g12"
													transform="matrix(2.3531852,0,0,2.2494648,-23.091826,-1320.5616)"
													style="display:inline"
													inkscape:export-filename="pokestop-2.svg"
													inkscape:export-xdpi="96"
													inkscape:export-ydpi="96">
													<rect
														style="display:inline;fill:#20b3ff;fill-opacity:1;stroke:#000000;stroke-width:0.011;stroke-dasharray:none;stroke-opacity:0.928287"
														id="rect1"
														width="1.0428497"
														height="14.130614"
														x="18.637442"
														y="32.810997"
														transform="translate(0,1035.3621)" />
													<g
														sodipodi:type="inkscape:box3d"
														id="g3"
														style="fill:#20b3ff;fill-opacity:1"
														inkscape:perspectiveID="#perspective3"
														inkscape:corner0="0.46200372 : 0.0032488569 : 0 : 1"
														inkscape:corner7="-0.0086824183 : 0.0019277906 : 0.46087668 : 1"
														transform="translate(0,1035.3621)">
														<path
															sodipodi:type="inkscape:box3dside"
															id="path8"
															style="display:none;fill:#e9e9ff;fill-rule:evenodd;stroke:none;stroke-linejoin:round"
															inkscape:box3dsidetype="11"
															d="m 19.157734,30.992772 5.668786,0.435639 v 0.909703 l -5.668786,-0.658318 z"
															points="24.82652,31.428411 24.82652,32.338114 19.157734,31.679796 19.157734,30.992772 " />
														<path
															sodipodi:type="inkscape:box3dside"
															id="path3"
															style="fill:#353564;fill-rule:evenodd;stroke:none;stroke-linejoin:round"
															inkscape:box3dsidetype="6"
															d="m 13.637865,31.41647 v 0.9036 l 5.519869,-0.640274 v -0.687024 z"
															points="13.637865,32.32007 19.157734,31.679796 19.157734,30.992772 13.637865,31.41647 " />
														<path
															sodipodi:type="inkscape:box3dside"
															id="path4"
															style="display:inline;fill:#20b3ff;fill-opacity:1;fill-rule:evenodd;stroke:#000000;stroke-width:0.0415748;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1"
															inkscape:box3dsidetype="5"
															d="m 13.637865,31.41647 5.683399,0.839349 5.505256,-0.827408 -5.668786,-0.435639 z"
															points="19.321264,32.255819 24.82652,31.428411 19.157734,30.992772 13.637865,31.41647 " />
														<path
															sodipodi:type="inkscape:box3dside"
															id="path6"
															style="display:inline;fill:#20b3ff;fill-opacity:1;fill-rule:evenodd;stroke:#000000;stroke-width:0.0415748;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1"
															inkscape:box3dsidetype="14"
															d="m 19.321264,32.255819 v 1.332637 l 5.505256,-1.250342 v -0.909703 z"
															points="19.321264,33.588456 24.82652,32.338114 24.82652,31.428411 19.321264,32.255819 " />
														<path
															sodipodi:type="inkscape:box3dside"
															id="path5"
															style="display:inline;fill:#20b3ff;fill-opacity:1;fill-rule:evenodd;stroke:#000000;stroke-width:0.0415748;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1"
															inkscape:box3dsidetype="3"
															d="m 13.637865,31.41647 5.683399,0.839349 v 1.332637 L 13.637865,32.32007 Z"
															points="19.321264,32.255819 19.321264,33.588456 13.637865,32.32007 13.637865,31.41647 " />
													</g>
													<ellipse
														style="fill:none;fill-opacity:1;stroke:#20b3ff;stroke-width:2.341;stroke-dasharray:none;stroke-opacity:1"
														id="path9"
														cx="19.02766"
														cy="21.129696"
														rx="7.8192964"
														ry="7.8185353"
														inkscape:label="path9"
														transform="translate(0,1035.3621)" />
													<ellipse
														style="fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.1;stroke-dasharray:none;stroke-opacity:0.36858"
														id="path11"
														cx="19.0044"
														cy="21.112745"
														rx="9.0081062"
														ry="9.0081053"
														transform="translate(0,1035.3621)" />
													<ellipse
														style="fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.1;stroke-dasharray:none;stroke-opacity:0.326284"
														id="path11-1"
														cx="19.049351"
														cy="21.128414"
														rx="6.6682439"
														ry="6.6389604"
														transform="translate(0,1035.3621)" />
													<g
														id="g4739"
														transform="translate(10.555356,12.659072)"
														style="display:inline">
														<path
															style="opacity:1;fill:#20b3ff;fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:1.148;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
															d="M 8.5,6.75 C 8.0137895,6.75 7.575713,6.9438156 7.2597656,7.2597656 6.9438182,7.5757156 6.75,8.0138 6.75,8.5 6.75,8.9862 6.9438182,9.4223313 7.2597656,9.7382812 7.575713,10.054231 8.0137895,10.25 8.5,10.25 8.9862105,10.25 9.424287,10.054231 9.7402344,9.7382812 10.056182,9.4223313 10.25,8.9862 10.25,8.5 10.25,8.0138 10.056182,7.5757156 9.7402344,7.2597656 9.424287,6.9438156 8.9862105,6.75 8.5,6.75 Z"
															id="path1"
															transform="translate(0,1035.3621)" />
														<path
															style="opacity:1;fill:#20b3ff;fill-opacity:1;fill-rule:nonzero;stroke:#000000;stroke-width:0.0415748;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
															d="M 8.5,6.75 C 8.0137895,6.75 7.575713,6.9438156 7.2597656,7.2597656 6.9438182,7.5757156 6.75,8.0138 6.75,8.5 6.75,8.9862 6.9438182,9.4223313 7.2597656,9.7382812 7.575713,10.054231 8.0137895,10.25 8.5,10.25 8.9862105,10.25 9.424287,10.054231 9.7402344,9.7382812 10.056182,9.4223313 10.25,8.9862 10.25,8.5 10.25,8.0138 10.056182,7.5757156 9.7402344,7.2597656 9.424287,6.9438156 8.9862105,6.75 8.5,6.75 Z"
															id="path4146"
															transform="translate(0,1035.3621)" />
														<path
															inkscape:connector-curvature="0"
															id="path5545"
															d="m 8.5,1038.1121 a 5.7500008,5.7500008 0 0 0 -5.7246094,5.25 H 5.546875 A 3,3 0 0 1 8.5,1040.8622 a 3,3 0 0 1 2.958984,2.4999 h 2.765625 A 5.7500008,5.7500008 0 0 0 8.5,1038.1121 Z"
															style="opacity:1;fill:#20b3ff;fill-opacity:1;fill-rule:nonzero;stroke:#000000;stroke-width:0.0415748;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1" />
														<path
															inkscape:connector-curvature="0"
															id="path5538"
															d="M 11.453125,1044.3621 A 3,3 0 0 1 8.5,1046.8622 3,3 0 0 1 5.5410156,1044.3621 H 2.7753906 A 5.7500008,5.7500008 0 0 0 8.5,1049.6122 a 5.7500008,5.7500008 0 0 0 5.724609,-5.2501 z"
															style="opacity:1;fill:#20b3ff;fill-opacity:1;fill-rule:nonzero;stroke:#000000;stroke-width:0.0415748;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1" />
													</g>
												</g>
											</g>
										</svg>`,
						iconSize: L.point( 36, 36 ),
						id: 'gym'+guid.replace( '.', '' )
					}
				} );
			}

			if ( type==='gyms' ) {
				const gym=gym[ guid ];
				const hasPhoto=typeof gym.photos=='undefined'||gym.photos>0;

				star=new L.Marker.SVGMarker( [ lat, lng ], {
					title: name+( !hasPhoto? '\r\n<br>Missing Photo, add one to make it count for Gym creation.':'' ),
					iconOptions: {
						className: 'gym'+( !hasPhoto? ' missingPhoto':'' ),
						html: `<svg
									version="1.1"
									id="svg1"
									width="533.33331"
									height="533.33331"
									viewBox="0 0 533.33331 533.33331"
									sodipodi:docname="Pokemon Go Gym Logo Vector.png"
									xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
									xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
									xmlns:xlink="http://www.w3.org/1999/xlink"
									xmlns="http://www.w3.org/2000/svg"
									xmlns:svg="http://www.w3.org/2000/svg">
									<defs
										id="defs1" />
									<sodipodi:namedview
										id="namedview1"
										pagecolor="#ffffff"
										bordercolor="#000000"
										borderopacity="0.25"
										inkscape:showpageshadow="2"
										inkscape:pageopacity="0.0"
										inkscape:pagecheckerboard="0"
										inkscape:deskcolor="#d1d1d1"
										inkscape:export-bgcolor="transparent" />
									<g
										inkscape:groupmode="layer"
										inkscape:label="Image"
										id="g1">
										<image
											width="533.33331"
											height="533.33331"
											preserveAspectRatio="none"
											style="image-rendering:optimizeQuality"
											xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAH0CAYAAADL1t+KAAABhWlDQ1BJQ0MgcHJvZmlsZQAAKJF9&#10;kT1Iw1AUhU9TpSotDi0o4pChOlkQFXHUKhShQqgVWnUweekfNGlIUlwcBdeCgz+LVQcXZ10dXAVB&#10;8AfE1cVJ0UVKvC8ttIjxwuN9nHfP4b37AKFeZprVNQ5oum2mEnExk10VA6/oRRgD8CEkM8uYk6Qk&#10;POvrnvqo7mI8y7vvzwqpOYsBPpF4lhmmTbxBPL1pG5z3iSOsKKvE58RjJl2Q+JHrSpPfOBdcFnhm&#10;xEyn5okjxGKhg5UOZkVTI54ijqqaTvlCpskq5y3OWrnKWvfkLwzm9JVlrtMaRgKLWIIEEQqqKKEM&#10;GzHadVIspOg87uEfcv0SuRRylcDIsYAKNMiuH/wPfs/Wyk9ONJOCcaD7xXE+RoDALtCoOc73seM0&#10;TgD/M3Clt/2VOjDzSXqtrUWPgP5t4OK6rSl7wOUOMPhkyKbsSn5aQj4PvJ/RN2WB8C3Qt9acW+sc&#10;pw9AmmaVvAEODoHRAmWve7y7p3Nu//a05vcDFIlygaxUe4AAAAAGYktHRAAAAAAAAPlDu38AAAAJ&#10;cEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfnCRMXFxiHr7KvAAAgAElEQVR42uxdd5wU5f1+3ndm&#10;d2/3eoGTJiBqIIAoRVFEjViIsUajUSGWaNTYYmIswYJYQGM0JoafXWOXaIxRMfZKRGyJigLGQhOF&#10;a1zdMvO+vz/ed3bemduFu9295e72fT6fvZ3bNrsz77zP+3wroKGhoaGhoaGhoaGhoaGhoaGhoaGh&#10;oaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGh&#10;oaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGh&#10;oaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhsXUQfQg0&#10;+is45ynHNyGE66OjoaGhCV1DI68YbQArhgAYXltbOyCRSNRYljXAsqwqxli1bdvVnPNqznmEc14q&#10;iTwMoEhulwEw5IfFCSFtctsmhDQTQloIIW2EkHZKaT2ltM40zTrDMOoDgcDGTZs2rQewFsA3ABL6&#10;fGhoaGhC19BIjyIA36+pqfl+LBYbmUgkhpumOTIWi42wLGsY5zzQC74jM03z22AwuMa27c+DweD/&#10;WlpaVgH4HMBKAK36NGpoaGhC1ygkjAAwvqysbJdYLLYLOB8fTyR24pybffg38UAg8CUh5KNgMPhx&#10;a2vrRwCWAlivT7eGhoYmdI3+ABPAhIqKiunt7e172ba9n23bAwrmx5vmBkLI+4lE4i0AS4DRy4AV&#10;cT0sNDQ0NKFr9HZEAOxXXFy8H+d8WkdHxyTOeUgfFgFKaathGO8kEoklguDxJoAOfWQ0NDQ0NHoD&#10;dgDwi2AwuIhS2gKA61vXboSQ9kAg8CKA8wFsr4eShoaGhkY+YQI4GMDCQCDwpSbm3N0CgcCHAK4F&#10;sJeI7tfQ0NDQ0MgpRhsADigqKrrDMIw6Tb49fzMMYxOAewHMAOZSPQY1NDQ0NDLEXApgPwALDcP4&#10;TpPsNiR3StcCWABgrB6XGhoaGhpdxSAAF1NKv9Bk2iuV+3IAFwPYTg9VDQ0NDQ0fRhsADgXwFCEk&#10;oYmzTwTUJQA8A+AwbZLX0NDQ0BgI4EoqTLqaKPvubRWAcwGU6iGtoaGhUVjYEcAthJB2TYb950Yp&#10;bQZwO4Dv6SGuoVF40IVlCgv7AfgNgB/113M/ZvRoPqCmhgFAdXU1C4VCyc5qmzZtMhKJBFavWUNX&#10;r1nTn8e+DeApALcAeEMPew0NTega/eccHwXgdwAm9bUvP2niRDZhwoTEiO23t7arrbUqq6pYSXEx&#10;Ky4pYcXhMA9HInYkHOZFRUXcNE3mGdMkzfDmguMTiQSxbRu2bZP2jg7S2tpqNDc305aWFtrY2Gg0&#10;NjUZm+rq6Lfffmt89tlngaXLlvVFX/VSAFcAeFFfChoamtA1+i4OBXAVgIm9+UtWVlTgkJkz4+PG&#10;jYuPGDHCGjJ4cKKystIuLyvj4XCYy3FKwTnhYlsdty5tkwyHsyR4LkzXchOimTohTP7PWlpaSH19&#10;vfndxo3m+m++Mb5evTrw0ccfB59dvLgvNJZ5A8DlWrFraGSFEvTizoqa0PsnDgRwNYA9eiN5H3P0&#10;0bFJu+0WGzlyZHzQoEFWTU0NC5gmSRI3QMA5BeAQuDNWSZoxSwjAUxI68T3IubNA4Cqhcx/F+7ZT&#10;RZlzAAwAj8ViqKuro6vXrAmsWLUquOTf/y7659NP91aSf1Eq9qX6MtHQ6DLCAM4GMBTArzSha+QD&#10;ewO4DsD03vKFdp88mR100EHRsd//fnyHkSPjQ4cOtYKBgEPcFJxT3pmsiaK3iY+YiY9sCQhBKpWe&#10;bnDz1OpcJXvxkJfoue+eKf8z4pC9UPSsuaUFa9euDXzxxReBjz/5JPTkP/8ZWr16dW+63p6VxP6B&#10;vmw0NNLCBHAygCshanSMBbBSE7pGT2I4gBsAHLvNl7HhME6aPTs2bc89O74/Zkx86NChFqWUAjDA&#10;OQHgJ3CXvOVfh8CJOk7lf2mJW/1fvJWnGePJxznnqVW6b9v/V1X4ymcwn6Jnioq3LctiX3/9deCj&#10;Tz4JvfTyy5G/PfFEoBeMGw7gMQC/BbBOX0YaGp5p5ccQvRWcrJGHAMzq7V9ao++iGMClAH4NYRLa&#10;Zir8mKOPbt91woToTjvtlCgpLoYkcModE7q4BwBKfIo7uSm2ePKRzn/hUeP+/0lyRcCVhYGPwjxU&#10;TaCysoffpVoX5M49RO8lfK6oe/Uxv5neIXgbAKuvryefrVgRXPbuu+GHH320aBtH3bcBuAYYfZPu&#10;166hgRkA5gOYojxmAxgHYIUmdI2eOG+z5aAbvC2+wG677spO+OlP26fusUd0x1Gj4qZpUs65AceU&#10;7qpv6hHbLlknidp5mhDims+998SnwJNK2ffZ3RrUPhWuqm2Xn10S95C+Q/iCut3nuGqq5+6L5Ttd&#10;HzzAQIgNgMXjcfbFF18Elrz9dvjev/61eNXnn2+r63IVRCvXf+lLTKMAMRnCZXlgiuceBnBiXyAG&#10;jb6FcQDuALBnvnc8ZvRofvLPfta259SpHTvuuGMiYJqGQuJEJXLiYWnnEYWkieclyefl/5wQQtMo&#10;cK5wuE/se5W7f5DzziodnQjc404HSUPkkEQu2Jlz7lHvqf5338sVA34ygt4h+Gg0yj9Zvjz4ymuv&#10;RW5duDDc0dGxLcbYUwAuAPCVvtw0CgA7A7gGwDFpONEGMB7AZ5rQNXKFEEQu+SUAgvnc8ek//3ns&#10;8EMPbdt1woRYUVERAZCKyB3uJipBe8hcPA7SmdC9ytyr4dGJtInqbPeo987Unt7krpJ8WonuI3Mo&#10;r/OQPRdIqvTkto/gFUUviN1rnmcQpnkGwNrc3IwPP/yw6Nnnniu+7/77g3kebx0QcRkLAET15afR&#10;DzEEItjtFIjgt3R4BMAJfeEHaULvG5gG4E4AY/K1w9123ZWdesopbftMm9Y+ePBgBsDkIpUsefOr&#10;8CQxq4Tt+z8FeXuVuvt5aiCcs829XL2V4ZvuBTyFRE/3lAjkU03pfqkORYATyeweJe8hdT/5+1+o&#10;KHep2i0AbMOGDeTlV18tvnXhwpIvvvwyn9ftcgAnAXhfX4Ya/QRVEB0Lz8XWY4+YVOefakLXyBal&#10;EH7ys+AGlfUojj/uuMSJxx/fvNuuu8aCwaABJbiNOIo8ycxQSTupwpMETqVwp9Sxw7umda96J4oi&#10;5ym52DW9ky0q8G6Ul/Go8xTqHd7o9s6ELwrdcMV37iV5h9wBcMbEU4wlCT0NuSeVu0Puir/dbmtr&#10;w9tLlxb99cEHS/71/PP5ynVPQPgWr5XbGhp9ERGIGJGLAFR08T2PAfhpX/mBmtB7L6YCeBDAqHzs&#10;7OyzzooddcQRLePHjYtTSg1wbnLAkARJQAh1AtQ8StshckqdbU4IoX6iT267eeMEIupbVebicR81&#10;k1TjdOu0TUhXiTw1jauv5yke92W9cT/Jc+4j+FQqnXMOzhhPoeS54nN3zPIOuVu2bbOVq1aZTz71&#10;VOkf//SnojyNyY+lWv9QX54afQgBCLP6leheEDEDsKsc95rQNTKCKQfepRCE2mOorKjAxb/9bevB&#10;Bx7YNnToUKaQuFDjrnImih/cVeIuiXuIHS7pK+wvCDxVwHtK4vbRcRfVefZIp9LTPMLdILfUJO8n&#10;eL96T0/u3E/wnVQ7YIOQxJp16+izzz5besVVVxXnYXzGxPgcfSOwwtaXq0Yv57fjIKpm7pjB+xfJ&#10;9/epH6zRe7CjVOU9WrI1HA5j7uWXtx526KEtA2pqCOfchNc3nmRlxXyuErlK4kQSu0eFyxd4FLhK&#10;4CRFnrivMlzvPEN+Mu/8ePqoeEfBc5fSk2pcmOLV7XQk73wekwqCAbAJIdb6b74hjz/xRNk18+dH&#10;8nAk3gbwMwD/05etRi/EwRBuokz7WDAAu0DEkGhC1+g2fgbgLxDF/3sMcy69tP2nP/lJ83a1teCA&#10;Cc4NCAKnngwzlbSlEqeqIpfbUIndp8K7QOBdJu/MDewZK3OHtLv1/lQkz9VUNTViXiV3SdqqcmcO&#10;kftVu/hfJXanYI1NCLHWrV9P/vbEE2XXLVjQ08TeAuDnAP6mL1+NXoLdIeKO9s/yc/qcOteE3jsQ&#10;gcgr79GiBVdedln7j486qnnwoEGccx5QidwV44r6ppRQ3/8+03rXSLybBN6NELeeHLu8K4TPMyB4&#10;1UTvy2kn3AtVsXPOGJiX0JP38qM6EfvXq1fThx99tPzmW24p6uFjdRNEOqWlL2eNbYQxEEGbR+Zg&#10;buhzvnNN6L0DowD8XZp2egSnnHxy/MzTT2/aYeRIW5rWDXnbEpF7VblqbhcBbylJPK1PPA0pk/TE&#10;3dvHZdrIeN5VgvdVk/NlrxHOOYOPwJljinfIPT2xi3x24WO3Pv/f/4zb7rij4v4HH+zJXPY3IaKB&#10;v9GXtUYesT2AuRAWzlzFHD0O4Cd98WBoQt92OATCX17ZEx++z9572+efe+7maXvtFTModYLdukTk&#10;1FHf0jeeVONKpbYUleC2SuJpCLw/jcFO0fC86+TuUe5qQJ1jYpfkLVhbVe1bIHYnKp4xZr+zbFlw&#10;wQ03VP576dKeSoHcBFGA4yV9eWv0MKog0s/OQ277WHCpzj/ShK7R1WN+EUTARs4n1iGDB/M5l17a&#10;cughh7SGw2FDUeVOsFt3iZwSR40rZvQ0hV/SD7D+SeDdIvjuknsq1a6Qt0rsnKU2xTP5IUm1Ho1G&#10;7edffLH4d5dfXrZx48aeOBc2gGuAufOAuUxf7ho5RjGAcyBcPBU98PlPQJSA7bPkopE/lEKUEfxR&#10;T3z4eWefHT3zF79oHDBgAAHnAQ4YMv3MjVrvApFTN/rNo8a3FuSWRoXrMaYSfFfJXVXrrmx3iF0y&#10;eZeIXc1lZ0QUqEls2LABC2+/vfK2O+4I9dBvfRzCDNqhT7tG9hgdBFb8AsBlAGp7cAHeZ9W5nmzz&#10;i8EAnkbmaRRpMWH8eHbFZZc1TZ8+vYMAQXBucMBQFDkhCmlvichV/7hSpnWLalyTeM+QezrV7hA7&#10;BJGzLpriHWJ38tdtxnn8rbfeCl925ZWVn61Y0RPn7B0AhwPYqE+3RhYcdQyERXPHHt7X3wEc3dcP&#10;lkbPYzyAZyACOHKKSy66qOPUk09uqqyooHDM60oamuoDdwLcMiByb09y/+AhRI+jniJ3t/c6T0fs&#10;W1TsbiCdWmOeKcSeaNq8md9z770V82+4IdwDv+1LiHiRlfo0a3QTB0A0CNotL9eg2M9/NaFrbAkz&#10;IXIaS3P5oXtNncrmzZ1bP2GXXRIARBqaJHNJyDSZdqaocSr/7wqRb6H4i1bi+SZ3nzm+K8Qu89iT&#10;qt0xyYNzh92Tap1znlj27ruhK+fNq3z/gw9yHduxCcAREMVoNDS2hmkQueTT87jPfwA4qq8fOEOP&#10;nR7FzwE8hNxGYeJX550Xve6aa+pGDB8OiFaqJggxQIhBqJDglFJQwyCGYRD13nmcUmoQodghSZ74&#10;ARkI5zB3svm4LAmrT28PLbKVwAXPAsqtpe9deHnjHaha0Q/eEryuRcX5eEIIOKcEoEOHDrUOP/TQ&#10;VtM0A28vXZrLxi/FAGZBVJX7RJ9ijTQYA2AhgBsBDM/rIlrEe3zT9ycPjZ7CFQCuyuUHDt9+e37j&#10;9dc37rvvvklfuaLKKXEVucPr3lxyX9R6SkWuzeq9ULMrvdl9qn0rip1xxfTO3Hx2p1iN81rm8a0z&#10;lnj+xRcj519wQUVjU1MufwkD8BsAf9QnVUPBCADzIIpr0W2w/6cgCtL0eWiF3jO4HiIaM2eYfeKJ&#10;8Vv/9Ke68ePG2YTzkF+VU0oJNQzqqHGpyJ3H3e2tKXKFyD39UDW24bJbaY7jfbyzYgdUxa4U5fXW&#10;44daS8AxwDhqnRC60447xg8/7LD2b7/7LrRy1apcTbIEwgUVAvCyPrEFj4EQwW5/hQgW3hbzDIeo&#10;nfCtJnSNVBPWrQAuyOWH/v7661svOP/8xorycgOcBxwyF+JbqnG/aV2a1w1B5FSp+OZjcaQnco3e&#10;N76UCj8OqSvWFYf03aI/4n+qFAVKmuE79aZ3PSsEAK2oqGAHH3hgS0VFBX3t9ddzWWVuOkTJY12A&#10;pjBRCmAOAR6VY2Fb8tDTAG7uLwdWE3rOMNoA6u4EcEauPrF24EB+/z33NB5x2GHthmEEOecB4qhy&#10;QoSvXKpyhcyp4i9P+skdW7v0q7pErvrINZH3KdVOPOV6pDElNbFz+PzrKpnD67JP3jhAA4EApkye&#10;3DF1990TL770UjgajebqF0wDUA7geX0yC2aODAJ1P6fAk1zU4gj2gi81G/2oXLEm9NwgANQ9KAdH&#10;TnDwgQfa99x5Z90uu+xicc6DAExJ5pR4VTmkiR2S3EEdE7zPvK6YaP3BbprI+yapb43YUwXOqQ11&#10;VLXufKLncznnhAB0+PDhiZkHH9y+cuXKojVr1+bKBL8nROljTer9X+ycRFH3BAdm8R7uKNlNdf6H&#10;/nSkNaHnZrDeD9GYIic4+6yzYlfPm1dXO3AglWRuEMfELu3s1DCIQSkxBIlT6lflalvTFH5yX9S6&#10;Po39g9jhI3bSKQXRfc6j1pFioacodUIAWl1dbR980EGt0Wg0+MGHH+YqCn4qgEEAntUnsl/iABN1&#10;TzDgDN4zpVq1OteEnrupFKi7O5fK/A833NB6zi9/2RQuKgpwzgNEIXPiBr6J1DPTdFPROqtyt99p&#10;Cj+5Dnbrl8TuiXRLkrdjhpevkS/jhBAqiZ4TSomyOOgcMCdN8OGiIuwzfXprZVUVfeXVV3NlMp0E&#10;ESC1WJ/EfoN9A8AjDPgdA7brhd/vGYj0uH4FTehZkTn+DOAXufrAh++/v+nHRx7ZRgkJciBAnJS0&#10;FIFvhpFMOSfCad5JlYOoflJoP3khEbs/cI6kKhgEuL51sU18qh1+QzwHqEEpmTRxYsf3dt6Z//OZ&#10;Z3JVC34KgAGa1Ps8dg0C99rANQwY1ou/5yz0w1a/mtAzx3wAv87FBw0ZPJg/9tBDDdP33jsuTeyC&#10;zGkSRDGxE5+JnVJKuc9Xnsq8rom8EInd71/3qnXXty6a+HjJ3Pdu+YdwGQU/evTo6PRp0xIvv/pq&#10;UVtbWy7G1hSIXPU39MnrcxhuADdw4DYb2LmXf9dn+6M614SeOa5EjvLMd588md13111148aNY8ng&#10;N4Am67IqhK6mozlET5KN0XzJaJ5ZWPvJC5jUga6odTVgTklv8y4H5BOcE/k/HTZsWOKA/fdvf/+D&#10;D8LfffddLgbZDwDUAXhXn7w+gRoTuIIDDzFgD2ybwjDdxWwA6zWhawAiLS0nq7tDZs60Ft5663dD&#10;hw4lXOSXu+lofn+5t3Srm47mi2DXqlyjm2o9XcAch7dcrN+vDhksR2pqauwD9t+/7dNPPw2vXrMm&#10;FxP6QQD+A2CVPnG9FuWSyB9lYhFm5mOnewYC/7Y4L2oV5YQzwXMQDV/6JTShdw8zATyYi1Xoj488&#10;MnHjDTdsrK6qMj1krvrMpYnd8OWWJ03sMrU8VQS7VuUaXVTrak0CN2BOGeN+j3yne0JIaWmpfcCM&#10;Ga1fr14dXvX559leHxSiFOdrANbqE9ebMDoYRN1pHPi7LebDvOSSTw8GV/2mtvbaMcXF7z7R0nKc&#10;Vuea0LPFOIiAnUi2H/STo49OXH/ddRsrKipMuGRukBQBcEl/uRvG7inpmSKCXatyja6odQ/RpzTB&#10;u351d0w5FefccZa8FUcifPr06a3r160rWrFyZbZzSwCiQ9vTECZ4jW2KubQIr/2Eo+4fFjCbZ66Q&#10;u4VpgcDG32y33cPnDB36wM7h8Iab1q797de2PUirc03o2WAwgFchUmuywkmzZ8evnTdvY1lZWQCc&#10;B7hL5l4id7alv9wfxZ7SxK5VuUZ3SN2v1rfiV0eKRaS/ZGwkHOY/2Hfflvr6+qKPPv442/klIkn9&#10;cQDN+qRtGxQDBzK89mQCOJuLQkA9jsmm2XZ+be1bpw4a9NzIoqLvCID3W1t3/GNDQzb1Pk7p7xYf&#10;Uw/XraJUKvOsUzDOOO206JxLL60Lh8MBcB4AISYBhConpBORE+Ev97TDVEt7Kqpcd0PTyJzYuWzn&#10;RggI54QLde6mtlEKKszgjEPlcRGSDsacxwwAKC0txbVXX72RUjrw/gcfzNYkOxTA3yFqfkf1Ccsr&#10;ZpjA/DaRfZAXjDWM+LE1Nf/bo6zsixClbRyotgADnOOJjRuzIfPnASzp7ydMK/QtYi4FXnMmk6xw&#10;ykknxa647DIPmSMdmRsGIdLcrrZETRPFrk3sGtmTuqrU3Rx0b71/tVSs8pySsp68hYJBTNtrr5Zv&#10;v/226JPly7OdZwYDGALR5lIjDwI5CPzVBuYycdx7HCMptc+sqdkwa+DAL7YPhzsIEILI+qEA+KqO&#10;jkHX19X9IItd/AzAOk3oBY3XrgJwWrafcvxxx8Wvnjt3UyQS6UzmriL3p6UZhBBQlchTR7Hr06SR&#10;W1KH05MVHuL2PK7kqzvk7zG/E0JDwSDZZ++9W7/ZsKFo+aefZjvX7AZgE3Q6W09iRAS4IQEstIFR&#10;+dhhDSH81KqqhpNra78ZUVQUJ4QUcaCIi2A7CuHqsR789tvpnyYS5Rnu5gWIuiH9HprQ0+NQAAuR&#10;ZY/eIw4/PLHguus2lZaWpibzFDnmRIlkT+u31P5yjR4mdaQhdbh+daTzpctnaKioiO89bVrLl19+&#10;GclB9PtBAF4HsFqfrJxiiAHcyIF7E8K83uMTiwnglPLyzafX1m7cORJJGIQUMSAkidyECMjkIMRa&#10;H4uVXLdp0y5Z7O4UAGsK4URqH3pq7AjgAWSZnnbIzJnW7xcs2FheVmZukcyVexnOzrcU/KZN7B7w&#10;1I/ydKS1RUrTpE5AOHcPqhPVzrlD6hwAAaWiXJw81kwcPPEcYwDnlAOEcM4rKir4H2688buOaLT2&#10;5VdeyWbOCUD00J4EYIMe+lmjygQutoFzbSCcr53OKi1t3beioqkyEADjvMgGDM45JW5EhyXnvQTj&#10;PPCv+vpsrAUvAnizYC5fPaY7oRjA2wDGZ/Mhe02dyu6+445va2pqDE80uybz7Ik7BVnzXF8APq1a&#10;UMdZJXRxvMUR55xzzuUdJ4wxxhnjjDHIe85sG4wxcM4BzhkHGCEkQQiJrv/mm8RPTzxx6PLly7NV&#10;6v8GRv8AWBHX01VGiASA8y3gonx2QDuquLj9wKqqxoGBAGdAkAMBzrnBASqLFHECcEpIggIxk5DW&#10;TYlE/PQ1a8Zmsdu9UQDBcJrQ0+NhAMdn8wHDt9+eP/7YYxtHDB8OruaZqwFwmsy3Tt4+4ua94QLp&#10;XGClnx15yd1bJ3RwzsEY45wxMMYYt23CJLFzQeqci0naIpTGCaVtn372Gf/RoYcOb9q8Odvj938A&#10;fqmnq+5ZOILAaRZwGROBhnnBQUVF0UOqqxuGhUIWB0KM8wADApLIKXemN845IcSmgEUJ6TAJaVm0&#10;cePAR1paMl10vAzggEI6wZrQvfg5gLuy/ZDnnn66fvKkSRb3Fo1JFwDXFTIvBH85Vwm8S+TNefr/&#10;un4BkC0o861fNEpTsn5K5uCuaucKqRPOGHPUeJLYbZs7j3HGHEK3CSFxQmkHNYymJUuWBA457LBc&#10;NPA4HsIEr7GVIVsE/CQBXGMDO+Vrp3sGAvHDqqsbvheJRLn0jzOpypkkc3BOePJSIowAtgHEDULa&#10;6xOJxBlr147I4ivsiwJr9KOD4lyMAvAkgKzaQT78wANN06dNc7qmJcu5ajJPTyBbJHAvyfOtkHrq&#10;16SZ5MjWH4E/+KsLBE/66rng6R5zVLlD7N6bfEaY4Z3nnfMiDwYnhAjTO6WxESNGfDts6NDos4sX&#10;12T5rQ8A8AiAzXr6Sn+MTGBRHDiPA9X52OF4w7DOGjCg7ogBAxoGBAKUA2EOhBgQZJybXPrMOWBw&#10;t4sfCCGcAowIhR57rqGh6pN4PNP5+GUAVxfaydaELk1REC31dsjmQ276/e9bjzriiLZk1zS1Nrts&#10;f5oqmr2gyDyVCkxB0DyNz5yr5njf41I6oou3JBV59qN8JkmjvLdE8n2O3LumylXiJsxR6UxuCZO7&#10;SvBEOa4cgE0otSmlcUJIlBDSusMOO3z17nvvDV+9enU2hWeKIEoyP6insE7YIwA8yIAr8mVeH0Up&#10;O6umpu64gQPrBgWDgEg/C3HFXw6XzJOmdgCEykUfBWxKSLwhkeDzN20akMXXORkFEtmuQke5C1wJ&#10;YPdsPuBX550XPeGnP22G0gLV32ilgMm8c6BVFwic+83w3G9j514udQgolYL3HUu1vKn6HkKIZ//J&#10;zC3Ok+VRuciNVVVo8lypOyfOF+yNZvmk9k5L5O6iRxI555xxzpmHvFV/uTDDO+eMO2QOYUpNAIjH&#10;43Hr+RdeGPb7G2+c/t+PPgrk4JccCOA8ALfoaQwAMCYEXBcDjkjkacwNJITPqqpqmFJW1hKi1OCc&#10;RzhgctdP7iVxIlIlkKxPCC57BzDpQ0+80dSUTbDeqyigyPa0gqJAsTdEV6eMrRUzDz7YWvjnP28s&#10;LSkJcM4DBDCQ7KXimtoNwwBROqb1ezJPp8b9JJ6CwFXyTm66/jbuIW83ZgtbIPyUgpkoudW+Y+/8&#10;5f73ErdRCVLkY5M0C4jeodq3ROTOdmci5x4iV5S5+lrumtsdMmcgxCKEJCzLii57993gH//0p+qX&#10;Xn451x26YhD50x8X8Dw21AAut4FT8yXUwgBOKC/fvG9l5eYSwyBShQfk/h2TOnVSGDlAmLgXQ0Qs&#10;ijlEZLtNgYRBSLQ+kYifuXZtNhXq9oOoV1BwKHSFXibNdRmT+ZDBg/m18+bVl5aUmJxzU3aoIlRW&#10;eVNJnTiNVpymF/2VzFP7YzuROPeSMU9B3t5gLPVznLWC+zmuQhZPkrTWArcJCRRi5smca7UHuMvg&#10;yXPFFZJPqngxQTlNTADOUyt3zvk2yVhIT+TucVMGbkoAACAASURBVPT6yYkkbttP5E6amsd/7h53&#10;QeSSzBlj9rvvvWfeunDhkMXPPddT800IwP3A6D0KMJWt2gB+x4Bf2sIFkRecVFbWsm9lZWOFaUIG&#10;u5ngXBSEEfMplaWIKFe68hHFYsbh+s4JYFPAIkD8zaamTCvCIQC8nihQMteEDiwAMDybD1h4660N&#10;2w8bhqQyF2Z2KuuvgxoGkuVcZW12pwJcvyLzVISRSv2lI3FJ4Mm8KFctui9VyFsR/1xypJ/cU0a9&#10;e1S3qsydgilJ+k6SefI53+PJcrxcLNDED/GTu7tfL7nni9i7TuTJwDbJ2rYavd6JyJW0NJ8iZwSw&#10;OZD47LPPAv93223VDz/6aCAPI3BXYMU8AJcUyNxVHADOtURhmPzlkkci7QdVVzfWBoNM+sZdIaPc&#10;iEPi4rp21DkoIWCuq4rL8cIoITYBEo2WhcdaWkoy/X4J4T4tWBQyoe8N4IxsPuDG669v3WvqVCei&#10;ncL1mUPeCFVM706jlTTlXPsmmW+NyH0m9E4k7mo8pkRQe6KpATAZQe0SvVetMwiXdSo/vJfMJUkr&#10;x5zBVeGOL89P3FxOUiBKQxIiSlM69c3FC/3kLvfjLGrySuydgw5cK4ln3aSYzJlgbB+Ri23GwNwX&#10;O+9nEL5PBkIscG598umngbvvvbcmB53WuvVr5eLcBGD132lrdDCIFWdYwJwEUJuvvf6wqCj6w5qa&#10;hqGhkMU5D3DOQ07lS0oIBec0eR3IWv7KwpbISoKwnctCWZBLMrcoEH+9sbE805NX6Oq8kAk9BOBO&#10;ZFHa9WezZsVPOP54JwjOSU9zctTU+uyQ6WkgLhGkKhrTF8l8y4TROVJa9clyGWSVsmCJ89nK8zxJ&#10;2j6FCUGYzGd29/O5ONSqqV2axwkU7leaj8hNJqcpRnwkn+xPL+MhACRb3KrkrrQjTap21deec2Lv&#10;6nlRc8o5ZzLAjTNpXk8qcpfIncWWLAUnFLkkUGvVqlXmXx94oPr2O+8M5XkkPgPgcgD/6b9T1lwa&#10;wtwTLKy4Kp5lNk53MD0YjB9eU1O/Q7g4Dm4HOedhACYIcczqlACEKotaqsSWSHXuWWATgDM3aJJJ&#10;MrfqLQsPtrSUZqHOrypwi3PBEvplAEZn+uYhgwfz31xwQUPANB1zk+FEtHui2p22p0Kd82QL1L5e&#10;AS4FYXQKVlNTnSQR86Tc85A4JLETxSfrV+pcJSTfV/CHwZNOj3u/q2NbT/rSuVfEc6UpibPNFWVO&#10;FGUuboxxuZYT28IKA7XfrfS1c190HYjk8ZwQe+ZEzrhL4k4aGk+a3KWJ3RHziiq3ACTWrVtHH1m0&#10;qPKGG28M53kkLgEwB/1flR1gYu4NMdFxLi/YxTStI6uqGscXF7cbhAQ4tyMpiVySubS1E6o2eCaE&#10;MM7BRB+A5BhU6v4zCHVuEyD2ZhaR7QFgSUJEt2tCLzCMB3BRNh9wy803Nw0eNMjxm1PHhJ6qcxoV&#10;Ez33maP6Jpn708JS+GJVE66ixm0lzcklcXcbilpXfboqiXOfed9P6Oo9V9VwGvus4+NLnorkvfT7&#10;qc51OCpbmuTV3uDyxpILN8acPvbcjX0kFKpJXj3tDrErpnjiBPZ1ZXikCULsJpH7zetCqXuqx8hg&#10;N1H5zfrmm2/IY48/XnHdggWRPI/EdwBcC+Dpfj5XTQ0ACxLAvvnyIYyilB1dVdUwqbS0NUBIQBaF&#10;MSHigwwn0M0hcQMghtiWRTfk9QEIMieE2HKEMmdhLEq8OuPJpkC80bLwSHNzNur8CmgUGqHPpcDc&#10;OyFa9GWEiy68sGOfvffuAOchKH5zKckhc8wdf7lBvOlpfZPMt5az3NkX6yUMbyESNUKaKDlPRI2y&#10;hhvZ7ifq5M0JqlEfsywLHdEotS0Ltm2TRCKRPMamaXLTNHkgEEBRUREzDMM5FVRyqKf9J5dBPXBz&#10;3GkyDF4SvCRncY4Zg7TEsOT/rquFyW3HM9OZ2OH62J1FixIVTDqtSVLl9m+dyJMBbz4feZLUfelo&#10;XiIHrO82bsTf//GPsiuuuirfRP5faVrv70Q+LgTMjwGHJvK0wyGEsJ9WVzdOLilpCVFqOkTO1Zoa&#10;grQpFSTukDkM8TgMYWqnzkqaAYLMxQUmLE8i3oWr44kA8Teamiqz8J2/lQBe0XReeIT+MwB7ZPru&#10;vffayz7j9NMbCSEBzrnfb66mqaVOT+ujZJ5ClacjDKhmde4123pSnXiq4CovgTPZfYnBJW7W3t6O&#10;7zZtMjdt3GhuqqujGzduNNauW2euW7fO/PKrr+h/P/qoy3ERE3bZhe2www5sh5Ejre1qa60BAwbY&#10;29XW2gMHDLBramrscDicbAMqSZ8mSd5xJcigHyVgjivETghjYpEnzPEOwdty0ecndq+PXXEHEL81&#10;fctE7ikK4wQUsnREnnqx5RaGEefAamho4P985pmSK+fNK+no6MjnKFwJ4Epg7t+AuawfT1AjwsC8&#10;DuDEWJatm7uKUkL47IqKzXuWlW2OGAaFS+SGdCUS6ipyQomIhDMIISYR9nfZrALOKFYHDhfpmx6r&#10;GhHmd0edJ+otizycnTqfq6lcNTEWBkoArAIwKNMPeOX55zeNHz+ecc6DsuGKE8ZODNXU7tZpR9K3&#10;2tci2tOZ131yvFNQleqL9ZG6j/y5T4U7ATJOoBWLxWJ8/fr15pdffRX4dMWK4Pvvvx9c/K9/5W0R&#10;evRRR1l7Tp0a/d7OO8eHDx+eqB040KaUUsiWj46yl4RO1G0lYM6x1sBp0ONkOyj3VA2yg+qFdP9u&#10;+Tylr+7GmbvA8hC5Z7HlXWkxRZVbzc3NfPG//lV87fz5pd9t3JjPUbgaItDpAfTryHUMNIA5DDiT&#10;Z2E97Kaqxazy8uZ9ysubykyTSKulMK1LyyOVfnKpXGAAgsQJgQlQkxBuUEoMgBi+xabNORKckwTn&#10;PME5j4t72LK2IJfKnBDS/tSmTeV/bW4uy/B3LEmIjCWNAiP06wBcmrG2v+KKtrPPPHMzF6Z2kxBi&#10;UEqpE8luGAZNNl8Rf9IFwfVVMuf+KmJpidyJivaShRqtrirAJIkzxuy169cbn336aXDJ22+HH1u0&#10;KNTY1NRrDsuEXXZhMw86KDZhwoTY+HHjYtvV1jIAhlTxhp/cVXKW5C4SdOW4UN0z0qJDCKVO5H3S&#10;stOJ2LcS7NYNIlcj153FleMjt1tbW9kLL70UueHGG0u/+PLLfA7aDeJ6HX1HPy8UU2oCv7GBX3Og&#10;NF87Pa6kpG1GVVVjjWlyLrg9oBI5ARyzuvCTS/ViKkRuUkpMaXJ3zFdQV4GC0BFnjMfEPbNEMA2T&#10;YyxBCIk2JBLxM9es2T6L1dqBAF7SVF5YhD4SwKfIsJLSpIkT2aJHHvmurLTU5JwHZG/zZAc1qc6p&#10;LB7jKetK+prfPE0hGIeFJTMQmXPGkgFUbiCV64NVCF1R4wyypSYIYZZl2V98+aW57N13w4sefzyy&#10;9J13aF8ZVD855pjEITNntk+YMCE2dPBgm4jcW1P62ilSqXan4JAkdupmQTimear43TsVH9rCIssl&#10;cve8bFGR+xZYTJ4Tq6Ojg73y2muRG2+6qeyT5cvzOV7rAdwA4FYA7f14PgoFRGW3SxkwIF87/VE4&#10;3PHD6uqGwcGgzV1FbvqJnApTuvCPu0ROTOd/SmG6/nNn8SnInHNYUo3HOUeMMRZnDHHOuZWs/A9b&#10;qvO2pzZtqshCnf87AUzTNF54hP44gKMzffPTTz5ZP3WPPSzF1G4Qn5ndEOrcCYxT/eakT5B5d1S5&#10;6IOtdtrykIYaVAWxIk+61aQat9auW2e89dZbkUf/9rfIv99+m/b1AfajQw6xDv/Rj9qn7bVXR61Q&#10;7qZimpeuSC+xK26Z5LZC8EocJfHWh1dS91ISudda0lUit2PxuP3mm2+Gb77llrJl772Xz3PSDOBm&#10;ADfJ7X6K0UYIK2ZbwFw7ywqV3cF+oVDssOrqhpFFRXFJ5I4iN+AEu0k/uRLgRkxCEJDEbRJCAj4i&#10;N0TNBRBHmQuTOhKcO6qcx4RC55ZL6DYAC4REGxOJxJlr1gzLQp0fDOAFTeOFRej7IIs81fPPPTc6&#10;55JLGohoA+iY2oUid9W54zenafPN+wqZb0GVM7X4iJurrBYg8RQf4Updb0KIHY1G7fc//LDoH089&#10;VXzf/fcH++uA+/WvfhU99JBDWr8/ZkzCMAzDaRvpIXbHh+4jc8UMT6WSp0r5WeWUpW+c4l9spSJy&#10;iCBEG4TYCcuyli5dWnTrwoXlr7z2Wj5bKrcD+ItU5XX9eRIKA0fGgWtsYGy+9jnFNBNH1tTUfy8S&#10;iVHR+cxpnNKJyKmqyCEmOlMSuaPIpUIXfaGlPkkGwXEOC0CCMZ7gHFHGeJwxHuWcJxjjcRGYwTjn&#10;FgiJE6Djn5s2ld+XuTp/OwHspSm88Aj9LWRolhm+/fb8uWee+XZATY0JzgOQgXAeVS6IHf4Oaj5T&#10;e+/1m6cjc38XLaHKOxUfYb7a3j4itwlgN23ezF97443IwttuK/nwP/+hhXJxzTz4YOtnJ57YOnXq&#10;1GhpSQn1E3syQd3xq3cm9WQQXbJBDLy93/011j3nyBfs5idymzHrvffeCy287bbyfAYbAohDVGq8&#10;FsJf3p+xbwCYnwD2zNcOxxiGfUx1db1TFAZeIjfSELlD2iqRO+QOx9yu+sw9Ee0KoUelib3Dtnlc&#10;BMQxm3Nui8B3iwBJdZ5FWt5MAM9rCi8sQp8J4LlM33z3HXdsPvzQQzvAeRAiS0NEvCnKPI2pnfSJ&#10;FLXOZO4JXkv6yh0Tu6P4/D7zztHRNgHsuvp6PLN4ccl1CxYU96bgtnxj+PDh/OILL2ydedBBbaWl&#10;pYSLrlSGzwzv+NTh860T1Z8Od8Hl6UmehsiTeb+qaZ1xnvjvf/8buuOuu8of//vfA3k8FDZExPpV&#10;AL7u56d91yAwPy7moLxgGKXsp1VVjZNKSloClJoQ5nVDkrknl1xNN5NmdGFi9xG5o8gNQty0DrEt&#10;KsNIk48lTOyIc86jnPOYbfOYML3zhCR0LjIV4gRof7quruLezZszUucmsNTK4wJJE3rv+W3vQPRJ&#10;7jZm7L+/fd9dd20sCoWCjqldBsLBME1q+FPUhF+Ukr7gN1crvDn/q+HnghRcX7kgcr9Cd4gjSRiS&#10;yK3Gpib+zOLFJVdfe21JIRO5H+PGjuUX/vrXzfvvt197OBym4NwtpelV69QXEe/kuJNOhO5LEWQq&#10;kfui1jlgLV++PHDPffeVP/DQQ/lunPI3iE5YK/r5aR4VBq7uAI5DnnLJKwnhJ1ZWNk0tLW0Oi1xy&#10;NQXNIK553UlBI6kUecDd7kTk8t4zmUkzHLdEIFwyoj3q+M6FqV1EtwM2OLcARJssK1t1/kMA/9Iz&#10;SmER+uEAnsr0zYv/+c/6KZMn22rOeTKq3TS7GtXe+0ztvuA3jyJ3K7rBCbBits1TqnLGHPMt45Iw&#10;otGo/errr0euue66slWff0705ZUakydOZOede27LjB/8oD0YDCYnXofYlfx1olSXI2qRek8WQWfz&#10;upMaJCtvIvHV118b991/f/nC224ryvPPfQnAxQA+6OentcYELrSBX3HR/KnHEQBwfFlZy74VFY0V&#10;KXLJJZEnc8kNWQjGIWpJ4K4yl0RuAMSktBORe7oLOaY4QdaIM4YY5zzGGDoYY/5gOA5Y4DxOCOl4&#10;pq6u/J7M1fn7lhBpXM8khUPoRE4gu2by5tNOPTV27bx59ZSQIoiGBA6ZU19ke98ytXeVzFVlLgld&#10;UeVJ0oA04XLOrXffey/0h5tvzndQVZ/GITNnWhddeGHT2LFjLUgzvKOoPJ1dPHSebCcPN4BBCXrz&#10;Nk6xvvr6a/rQI4+U3/LnP+ebyF+BaIL0dj8/jeUm8FtJ5MX52ukJpaWt+1dWNlaZJlLlknuKwsCt&#10;7JZU4wBMSokhlDkcH5BBqTMIRbMVJPMuPV2PmKjNDlv4yIXvXKrzqCBzFmeMW8J0ZzPOEwSI5UCd&#10;H4Is3Kia0PsmfgJgUaZvXrpkycZRI0YQjuQi1pOeZrimdiNVAZleT+apgt+UKHZm20lSZ4xxbttJ&#10;xS6uZTdnua6ujt9+110Vf/zTn4r05ZQZrrriivbZs2ZtLi0tNSAC55xAYjcUXrlW/emEzjmBr3HK&#10;oscfL7t2wYJ8d0ArkMYpo4NBrDjFAuYxYGDezI6RSPvBVVWNgzLJJZcR7AFKXXJHMnWnM5FLczt8&#10;ZM5FBzXYAE8IMkeMcx5lDFHGWFRR57IynAUgQYD2Z+rrtTrXhN5tfIAMWw1edcUVbb8888xmWREu&#10;kIxqp5QYpqmmqVFKvUKq15rau0jmzLYd0zqTpA7J6sJX7pAGIZZt29Yrr70WvnTOnPLVa9Zo83qW&#10;2GvPPdnlc+Y0Tpk0Ka6mFxE3oFi9Xr3pZ5LIASS+27gRf3/ySd04pedghoCTE8CVDBiar53OCIVi&#10;h9bUNAwPhRI+RZ4ylzxVUZhkLrlaj30LRO6xNkLpgCTzzS3OeQJAXATAoUP6zaNCncPinHl857Yd&#10;P3P16u0zVecR4NB24Fk9WxQWoc9AhqUAw+Ewli1Z8m1tba0pyTyZpmYYBqhhUOk/T0Yh095eQKYr&#10;ZK6ocY/P3Lb9JnYLhFgNDQ38lltvrVx4222hXjXTmmY9pbTONM0GwzCaDcNo8R4Kbti2XcYYi1iW&#10;VWPbdq1t22W96TdcctFFHaedeurmivJyCiWwSU6oyaA4H5FbDQ0N/Kmnn8574xRKyErGeSE0TiFh&#10;4OgEcLUFjM7XTqcGAokjamrqdw6HY2QrueT+ojAOkQcIgemocrg+dKdAjHyvh8hJCnJw2qTZjIna&#10;rbIinAyC8/jOE47vXFHnz9bXl9+duTp/1wJ215RdeIS+GCIKstuYf801baedckoL5zzkpKn5TO0i&#10;51wNhBPVknpnAZmtkDljjHDGbKb6yhVCd17GOXd8son33n8/eMnvflf5348/3ib55ISQeCgUWh6J&#10;RD6ybfujSCSysrS09OuJEyd+9eijj3a7XOisWbPCy5YtG7V58+ZRnLEdLdseH41GJ3Z0dIyR6WV5&#10;x+5TprAb5s+vHz9unAXAlPnrVLlmHSK3N2/ezJ997rm8N04xDGO1bduF0DgFAPY3gQVWhhkzmWCc&#10;YVjH1NQ0jI1E2qlweQcVRd7lXPJAiqIwnYhcbHuInLhjjUMxBSXVuTS3y/S0pO88yjmXvvNO6vyc&#10;1au3z3SpGQEOb+//1h9N6D6MBfBxJr+rsqICS15//dsaWUTGKe/qBL8llbnbgKV3B8JlSebMjWK3&#10;QYiVsKzEY4sWlV1w4YUl+fwZlNJocSTyJqH0lfLy8n+vXbt2GYBoHnYdHjZs2JT2trb9YrHYfu0d&#10;HVMZY3n1Ry+89dbNx/z4x02mYZgADO5OsHZrayt//oUXSq///e/L8tk4hVK6gTFWCI1TAGBSEFgQ&#10;Bw7I1w5HUsqOra5u2K2kpDXgLwrThVzyQIrqbmbnFDTi5JRTpa2z9O2kKjOcNAnZjAnfjlTnMVlI&#10;RvWd94A6f0+qc+07LzBCvxvAqZm88fcLFrSeNHt2K5xuak7zFek376TOe3kgnNPkNLm9JTJXCT1Z&#10;biwZxW41bd7Mbrzppsrb77wzLyZ20zTry8vL/xEMBp/csGHDq+gdjToitbW1BycSiSOam5sPtSyr&#10;Oh87Pffss9svvPDCdWUlJQwAbW9vpy+9/HLl7//wh8pPli/Pm5XEMIx627YLoXEKAOxcBFwTBY7J&#10;1xxZI3PJdy8r21xEqQFfwJtC5I5pvVMueWAL1d1UPzmR252IPM30pUReetW5NLWr6lyWfvWo882W&#10;FT97zZps1PkR7cA/NV0XFqFvRwj5WgazdQsDBw7kb7z88ndVVVXJEq80hTr3p6n12k5qijrPkswT&#10;a9euxa9/+9ua1954o0fT0Qgh8fLy8qfC4fC9GzZseAlAohePtUBtbe2PotHoSc3NzYdwznu0SMvM&#10;gw+Oz5s7d9Xn//tf+c1//OPg995/P2+pgZTSZsZYATROAQAMMYArbCEK8uJuCQOYXVGxeVp5+eYS&#10;w/DnkhtSNKTLJU8q8nRFYaSsh9EFIvdPXlyZS5ROal51zjmitp1WnQNof66hoeyupqbyjC404IME&#10;MFmr88Ij9HkQUbbdxg3z57ee8rOftfKtqHND1Hnt3ep8C2QuA+BSk7nrM7dlSlri408+Mc88++yq&#10;niwSEwgEvqkoL//Tprq6ewBs6oPjbkBNdfWZm5ubz0wkEoP7zcRASDvn/C8Arodoa9qfUWkCl9jA&#10;uVxwbF4wq7S0Zb/KyqZ0ueSp+pL7C8E4ZG4oueT+ojCqaZ10gcj9hM4AnqE6j222rFg26jwMHNmR&#10;RYEwTeh9EyaldDVjLKMJ9T/vvfft4EGDTOeCykCd9440Nb/fPF00e2oyZ8nyrYTEX3/jjaLZp5xS&#10;0VMR06FQ6OtYLHY9gHsBxPr+EBwdBFYcGw6H53R0dIzusxMCIXHOeaE0TokEgPMt4LccqMzXTo8q&#10;Lm4/qKqqoTYQYL52pl3KJXeKwphui9O0RWG6SuT+kq7OfbJBQ4bq/F8NDWV3Zq7OP0wAk7Q67wYR&#10;9pPf8aNMyfzCCy7oGDJ4MJxIYuJ2vlLLbjr3HKKmNnym9t5P5qLHClcrv6Uj8xdefDF84kknlffE&#10;1wyHwys6Ojrmx2Kxh9GvoqNXxAE82NFx8cPA3GPD4fCVfYzYbQAPcM4LoXFKIAicZgGXJYC8WVUO&#10;KiqK/qi6umFYKGRxkYJWBG9RmJzlklMnYt0pDuPMUkqRmC3NWm4onKcynMhdFcQNS0Szw3KeVyoV&#10;ArA2WxZ/MEMyl+Q0L6HJvCAJ/bRM33jkEUe0KmlByUYY1NunmoIQ7pjZ1apdvcXU3qlrGpLWdjhF&#10;YzxE7vjM3S5pNiEk8fSzz0ZOPf30nOdmm6ZZb1nWxR0dF9/bv/OV5zIAj3Z0dDwO4HTTNK+yLGtA&#10;L/7ChdQ4hRQBxyWAeXFgp3ztdFowGD+8urphx3A4SoCgNOvnJJfc9EWuq7nkmRC5f05xUtVkmdfk&#10;zXKJnct67pyJCoZOSmX87ebm8kztewHgP9rUXpiEPgwZ5p3POuGE+M477ZSAWClT2TGte+q8V0zJ&#10;XFXpUNtncqdXtt/ULgPgVGX+z2eeKf75L35RmuNvx6qrq++tr6+/GEA9MLdQri0LwP9ZlvUwgLmE&#10;kHPlwrE34RmIuJP/FMD5ONgErosCE/O1w11M0zqmurr++5FIByUkyIFi7rQz9RE5VRW5JOxu5ZLn&#10;iMh5jtR5s1bnmtAzxCmQlbS6i+OPO66FEGJyzh3HOO1z6lwNgoPC5mrbU7c2e7KfuRPNLgPg4i+8&#10;+GI412ReXFz8n7a2trPq6+uXFvA1thnABZzzhwHcCWBCL/hOhdI4BQD2CAALEsB++fLvjBK55PW7&#10;lpS0mcLlHeEpcskN0UTFUxQmm1zy7hK52jktFbFvQ3X+3w7gH5qeC47QRxuUrvo5Y9234O4+eTLb&#10;ddddY5zzkKyXDUIp/OocvVmd+/zmvs5phHFuK2Z2V6kzpnZLS7z+xhtFufSZE0Ls6qqqq+rqB1wH&#10;rLD1ZQYAeBci/eZyAHMyXYRmiaVy368UwPEeEwKujQFHJvJ0uQ4khJ9YVdU4pbS0pYhSQzGtp80l&#10;NxUizzSXXFZ26xKRk66QulpMJkN1/kiGRWS0Oi9oQl+xH2PYPpN3nnzSSa3BQMDgnBtKhxVntUuS&#10;5N6L1Xlav7nINWfS3A5J6nBqs8MpHUpI4qOPPzZnn3JKRa6+UyAQ+CaRSJxQV1//ev/Pduo2LAhf&#10;9QsAHgQwIk/7LZTGKQAwzADm2sBJsTwtmsIATqqsbNqrrGxzsWFQAEXcm0vumNeTBWGkad1bpjWz&#10;XPKMiFxV4uo296lznoE6X9rcXN7CeUbzowl81AE8qaeKgiR0HJfpG/eeNq1d/n4ZDJokciK7qEGa&#10;4LmqzHuTOvdclKrfXLrHPT5zpTa7U851zdq1+MVZZ1XlKjWtsqLihcamplnIYz751KlTa9etWzem&#10;vb1951gstlMikRjFOS9ljFVyzosBlHDOiwkhrQDaCCGtlNImQkhzIBD4IhQKfV5cXLxy2LBhK/79&#10;73/nqxj6EohugA8AOLQH97NSLCD6feMUAKg2gN8x4Je2iInJC04qK2vZp7KysUIUhQlhC33JJTl7&#10;1bgvr9x5jZpL7hB5V1LQSBeJfCvzilsZrpvqvMWy+MNZqPOAaH6j1XmG6Mt56AHDML6xbbumu288&#10;4/TTY9dcdVUDnBap/kIypkl7dc32LaSoSSXOmG3DFvf+9DSbEJJobGqyfnHmmQNzVAGO1VRXX1FX&#10;f+78PBDH2IqKihnt7e37JRKJfTjnOSvBSgjZFAgEXi8uLn6tsbHxFQCf9exPmUuBuVcAuCLH1+Jq&#10;AIXSOKXEBC6wgd9woDxfOz2muLjtwKqqxgGBAO9qURiPfxy5zSXPlMi5X537CsnEu5d33vFCQ0PJ&#10;7U1NGVn8TOBjS8SYaEIvQEI/GMC/MnnjM089Vb/HlCmMiyYsJqGUyopwSVL39DtXOqr1iqpwnHO1&#10;LKOMZmdOJTjbIXHb5rYgc8YdvzkhiYRlxefOm1d9x113ZV2bnRAS45z/DMCiHiS9/YqKimbHYrEf&#10;cs5r83ZxELIhFAo9G41GHwDwZg9OND8BcD+yV5YbAFwLjL6z/zdOGR0MYsUZFjCHAXkbEz8sKor+&#10;sKamYWgwaHFfvfWtFoVxU9CIJHMkU9C6kEuuNk7JhSLvZG6X84kN0YSlS1XhOLflojHWYlmxc9eu&#10;HZapub0IODYqUig1MkSfNbkXFRUdG412v+nWhPHj2a677BLnnAeJuAgd8zqIa2p3bPDcleW9ZO3j&#10;dE5DZ1O7LB7j+M3B3JQ1JPuZA4lHH3usLBdkblDaYjN2FICXe2LGBjCb0nmzGcOwTM51DtZNg6LR&#10;6GkATqOUfs0Ye0Cq3s9zvKu/AfgWIrK3YkUNEwAAIABJREFUKoP310OUaP0LgPb+nU4+l4Yw9wQL&#10;K66KAzvka6/Tg8H44TU1DTsURWIEbKu55IbMlgn4isKYSlEYM4dFYbKZnbLynbutfBNLW1rKsvCd&#10;fxLF3CcKKK1VK3R1dU7pqm8ZY90u13jj9de3njR7divnPETcnufUME3Imu1py7z2BnXuiPMUpnbC&#10;bNtOqnLX1M4Uv3n83ffeMw85/PCszdSmaW60LOsQAO/n+CfuBeB3AA7ppeOTQ3R+uhYicj2XGAvg&#10;JQDbdfH1zQAKpXEKAPzIAK6zgV3ytcOJppn4cU1Nw+hwJEoJAlxtZ9rFojD+XHLTDYzLOpecZDGI&#10;c6rObTt27po12ajz46I9ZuXTCr2XY8WBjGVWe3mP3XePwvF1KZXhlCIyaQvJ9AJ1zpWLMFVUu1sN&#10;zikeI/meEGLVNzTwS+fMybpmdSgUWh2LxQ7MsVI9ACKlar8+sAg+Qt5elMT+eo4+e7n8/a9gyyVJ&#10;26UaL4TGKQCwl8wln56vHMidKbV/UlPTMKG4uM0kJMCBcFdzydXIdSeXPLClojDofi55rmakXKnz&#10;d5qbs1Hny6OY+7hW5wVK6OFw+PBMIrN3nzyZ7ThqVELmnieZO2lql1XitlBIZluSubuq5lzNO3ej&#10;2qW5Xa0O5xSPsW3buuXPf67678cfZ9VD2zTNjbFY7AAA/8vRL/seRI/tA/rgUDxQ3hYDOA/AFzn4&#10;zJWS1F8HMMj3XByiOE0hNE4BgHEh4LoYcFi+eukOIYT9tLq6cXJJSWtI5pLz1Lnk1CFlM3VRmK3m&#10;kvsD3kieiHxreeddimyXPVsAWK22zR7Nrirc1Vb/z8LQhJ4OViIxM5P3HXfsse2maVLOuQhgkZSd&#10;DHxTlLqfwEluF8aZX4duzrlbQIYxWyF1UQlOXKROvrn10iuvhP/v9tuz8psblLZYlvXDHJF5BMK0&#10;fiFEuk9fxiEAfgBgAYAbAGTr8P8cwExJ6hVSBd0P0SL46wKYl0ZQ4CoGzIoBNB87LCWEz66o2Lxn&#10;WdnmyFZyyQ2Zz+pT5P62pp2IPJtcctJDE0qu1Hlj5ur806hIq9RsXKCEPjZhWRkVk5m6++4dsp42&#10;gbMi9hG5VOS9KxguRSCc9KFDpqIlVbliamcyqt3etGkTn3P55Vml9BBCYjIA7oMc/KIZUmmO7EfX&#10;UhgiVWwWgJ9DRMVng48AHAbgLEnkKwtgPhpgAJcx4EwmIsh7HAEAs8rLm/epqGgqNwzCfbnkxB+5&#10;Ls3kW8sl95Vp9RA53BQ0onZrJHki8lyr80e0Ou81oH3wO2fUiGXq7ruzHXbYISF/s1Pb1eM/hy+y&#10;nbjEv62D4bjn4lPKu6rlXJkSKCej52zOuXXnPfdUrF6zJpvvz2RqWpbR7KMNiKX48/2MzFXsBOBV&#10;8TvnZnt9vQXgxAIg8+IAcAkBPreB83ieyPzHxcXtfx42bP1h1dWbywwjyIXVqAhAAJKnKWCYhFCn&#10;kluQEBKilBRRSsKEkCJKSci5EYIgISRIKQnIDmlBWRHOIASGdO0ZYrWQdOqRFGROelCV9yJ1/lkU&#10;c3UgXCEr9EAgMDOR6L5H7SfHHNNmmqaRbMQCuBVf3XQ1xXNOeq06VzqqMc45fE1XnFB4Rgixly5b&#10;Frr5lluyym+uqa6+vK6+PtsLbzCw4iH0/qC3XMCAqNC2J4DZADbqqSYlQgFR2e3SBJC3FrOHhsMd&#10;M6urGwYHgzYX7UxD6GouuUw5CyhFYbaaS97T1d20Otfoowq9xLKsvTN5464TJsTAOVUEt6PGPW1S&#10;4ZrdlSts22aq+dU53NaoXCVyrpZ3BeyOjg77DzfdlJWpvbKy8vm6+nMXZPkb9gTwYYGQuYqD5O+e&#10;pKcar6UmBJxsACsTwE0sT2S+XygU+8PgwRtOHTRo4+BgkMpc8hCAoFTkhiEVeYAQGhTpZkKRE+Le&#10;DMN5DCFCSMgwSJBSBB2zu9LqlDr+cyfA1qfI86HKe0qdL2tuLs1SnT+mr4XCVuj7c1GutXukVFGB&#10;UaNGJaQpj8Db5xxJczvAFTM7UVbL24zReecVtb/fudPbXOhyuYImgPX8iy8WZ1PaNRgIrG9sbJyd&#10;ZTnXQyAKp0QK9BobDGGC76kCPH0KYeDIOFZcExM593nBFNNMHFlTU/+9SCRGgYA0rXcrlzxAiFuq&#10;1VHk2ziXfFuq8zbbZo9lWOJVEs+1Wp0XOKFHIpH92tvbu/2+E44/PlociYBzTj2pIUqb1E7R7b3D&#10;3O7PO1d950xR5q4JXqwB7PqGBj736qsz7m9OCLHiicQJyK7RyiwA90AEGW0TTJ48OREMBlk0GqUf&#10;fPDBtvoepQCeBdCDJXJ7PfYJAAs6hLUmLxhjGPYx1dX144uL2w3Rl9zNJSfEUIk861zyXk7kPeA7&#10;L63LXJ2viGL0o/27oqEm9K3CSiSmZfK+vaZOdYrJeKLgVJ95p+h2l9m2HZ+rq+kUke3Mq86TqWoE&#10;sJ5ZvLhk/fr1GX950c+8/o0svv45AP6Uj3nrpJNOapo6dWr9sGHD2oYOHdo+ePDgtpKSEiscDtu+&#10;/fOOjg6jubk5sGHDhvD69euLV69eXbJ06dLqBx54oKcbe4QAPAKRhnZHAc0xE4LAgjgwM1+55MMo&#10;ZT+tqmqcVFLSEqDUlNYhA2lyyQ0lBW1rueSmErm+LXPJ+7I6N4BrLaywoZFz9KXSrxFCSBPnvNsq&#10;68Nly74bOmSIwYEAIcSghkFlVzWnIQtVO6v5Sr1um+PEXXmu1HflnDFiKyVebctinhKvQKKuvt6e&#10;ts8+tY1NTRnturi4+MO2tmFTkPlFNxvAX3vquI0fP56dccYZDRMnTvxq7Nixm8vKyjjUJhnO4i31&#10;/h2BYjsTFACrqamJLF++vGLJkiUD77777iGrVq3qqV7aDMDxBaDUR4WBqztEi+O8xOpUEsJPrKxs&#10;mlpa2hwWueRO85Su5pK7jVOw5aIwvSWXPCN1nmVHtVebmopvbWjIqOKkCay0MHosNKEXvEKfkgmZ&#10;7zV1Khs8eLAlazAnI9zhBsFJDzpJp8i3dWc1vzp34uKcIDhI3zl31Pk/n366NFMyB8Da2trOyuKC&#10;OwTA3T1x3C666KLmI444omHixIltRUVFBkQBl5ItkLk6t6ayOiZJvaKiwpo2bVrHtGnTPj/nnHNW&#10;vv322zV///vft1+4cGF1jn8GhSgSU4/+6VPfzgAut4HTO/LkajEBnFRe3jy9vLyx1DQpROqZv0yr&#10;2pecGHD94E4ueVKZdyGXPBWRA9solzy/6tx+tLFRq3NN6NmhtLR0ektLS7ffd9CBB3ZQSpPpavCS&#10;uScgDulJfdtcdoJ1uHJPpFvL6W/uqnfp42psasL1v/99caY7rqmpuauuru6dDN++h1SeOZ3IL7nk&#10;kuYTTzxx47hx46JSdTkm1HJVgSGZGZS898+nKqkzeP2CTqMJKxKJxGfMmNE8Y8aM988///zwI488&#10;ssPcuXOH5PAnhQA8CVFd7v1+MpeUBIBzLOBSGyjL106PLy1tnVFZ2VhlmvAXhYGos54kcqcvueof&#10;D0D0JTfczmjiNZR2IvLupqD1BiLPeWR7S0tZpr5zA/hfTLidNAqd0KPR6NRM3jdmzJi4avJTfee+&#10;KPfek67m0Lkb1c7hV+fSh+50RnfU+Wuvv16cqTo3TXNTXV3dpRl+6yEAngZQnKvDcM4557T9+te/&#10;Xjty5EhLkmCJqrzkvrpK5lsidVuZtCyp8OIA4jvvvHPsyiuvXH7sscd+dcMNN4y77777KnL080oh&#10;urbthr6dp14UAM61gYsTQHW+dnp4JNJ+cFVV4yA3l7zrfckVIu/zueR5VOfttm0vykKdm8DVtri+&#10;NHoIfSUPnTDGMoqOHTVyZELNP1f6n3PZUa3XpattJVWNK41Xkk8AYNFYjP3fHXdkTKiWZV0MoKH7&#10;75xLIXzmOcknnjRpkv3cc8+tveWWW74aOXKkIYk8LIk2KG8B5bGQfCykPK9uB9M87mwXyVtYqv+I&#10;3GcphNqsGDNmDLv77rvfWbx48X8nTpyYq/iuwQAekRX0+hjm0iLgWAP4NAHcwPJE5jNCodhNgwdv&#10;OHm77TZtJ3LJI9hKLnkwTS55UR/MJd/W6nxjdur8YU25PUyUfeR77gRgVbcl4+DBfNnSpRuChlHE&#10;gQAVINQ0iWmayd7n1DDcBi3KBbtNyr12DoaDTFHzB8M5/c5tzrlNgMSbS5aYPz722IyCVcLh8IqO&#10;jovHZphzfg1E69OsccEFF7TOmTNnTXV1NYXXhOr4yFUlHvc9RpDejclTzHf+uY4hhQneUesQPvv2&#10;uro6dtVVV+1266235orE5gC4rq9MGsXAgTHgDxYwPl/73CMQSBxRXV3/vUgkRpBZX/J0ueRK5DpR&#10;U896fS55dwg9y37n7bYd/c2aNdtnSugh4OSYWPRr9CD6isl9XEZmucMOiwdNk3DOXWbu7D9XL9ne&#10;1Ps8yeoecneD4Zw8NUFGhFhPPvVUxqlXHR0d12RI5gcAuDTbnxuJRHDPPfd8e8wxx9QZhhFSVHgq&#10;MncIPZCGzEkaIk8XHOcRMHBN8Kac0Ey4BBKoqalpv/nmmz+YMGHCDqeffvqoHJztqyCaubzZy6/D&#10;/U1gfhuwe94ufMOwjqmpaRgbibTTLHLJAzKX3OzDueTbUp2/29JSmqU6f0jTrSZ0AEBpaemETALi&#10;dtt112hywvfmn0PWcnf8Yby3+M+3am7nnHEfCMBWr1ljPPDQQxk1tQiFQl/GYrFMyjBGANyFLF03&#10;I0aM4IsWLfp6ypQpHfIznXSjVKpcJfBACgInXZhr/fMd5ORlyHuq3DuR84ayuDBM0wycdtppX40a&#10;Nar5uOOO23XTpk0ky+vwbgjFG+uFl+CkIDA/DhyYLwfoSErZsdXVDRNLSlpNQeRudbfu5ZInidzs&#10;HLlOnBPc53LJuy8OsvKdP9rYWJnF4L5W+87zgz7hQ7cta5eMJoURIxIKAUDprgYlTS2d/3xbXHj+&#10;ynBIVoZzAuNEVTiiBMNxEMLefOutjEurxmKx65HZBXcZgOFZMcWkSfbixYu/nDJlSgxqtytXnXuI&#10;VCFZP9E6N7IF1U58z/s/nyoLCUeV+/3vRfJ7FgMo+8EPftD03HPPvfu9730v21ScnQBc1MsuvZ0p&#10;8BiAd+PAgfnYYQ0h/PyqqsZrtt9+ze6lpR0mIWqchEgTF35yGhB+chKgVHRBI4SGKCVhSkmRYdAi&#10;x29OKUKUerqgBdzUtWQXNBkE53ZhRO/2kedLnb+XnTr/IgY8qKlWK/QkLNvOyOQ+aLvtbHBuprwO&#10;PayO3pV/7jO3wxfd7pC7EwxnWZb9yGOPZUTowUBgfTyRyMS3NRrAb7Il87/97W9fjBw5EhABacEU&#10;xJ1KmW/JV761zCG+BdHlmOSJotKZbyHQ6TZp0qTWJ5988p2jjjpqj5UrV2YT4HYphGnyy218yQ0B&#10;cAWAU1me5ogwgNkVFZunlZdvLjEMIh9Si8KQLeSSJxV5wDWzpzKtbzWXvF8o8hyr80XZqfPrtDrX&#10;Cl1FcTwe77afcsjgwby6utrmcKzrHnVOOrVLTU3q2/pCTAazIJW5XUTns8//97/AsnffzehcVlRU&#10;/BGZmXn/giz6Vo8YMYI/8MADX0syD6Uhc78iV0nVT8RbC4zzv35L7/NbAUzFahBIodZLxowZE3/o&#10;oYfeHzBgAM+S127ZhqOuEsACiADUX+RrwT+rtLTlz9tvv3ZmVVVziWE4dQZEQKRU5NSNXO/cl5xS&#10;yHsSohROX/KQT5H7+5LLk+vpS44+qMh7Wp1vyE6d369pVit0FWMzWXgceMABCdMfEOcqc+diTRX9&#10;vK2IvXMxGaHEiVO73TG1K8FwHISwd5Yty0idE0JiGzdtui+Dtx4MYP9Mf2gkEsGiRYu+HjNmTEJR&#10;5oEUBE5TkC5XFqO5EFIcnYPouDsngct92VtbMEyaNKnl0Ucf/c+MGTN2y2IcHApgOvIbIBcBcB6E&#10;yb8yXzs9qri4/aCqqobaQIBzN3I9WRRG55JvW3Xekb06n6/VuVboHlRXV38/k/d93y0oQ+AUd/UF&#10;xEEpKNN7asP5SF2oc3iEuWJut23bfnTRoowIvaK8/EkAdRm89XfZ/NR77713w5QpU6Jw88pVZZ5K&#10;lasEStG5eEw2QipVZHyqxYTqs3d87KpvPQygeP/996+//fbbv8hyNMzJ06gLADgDwOcA5ueLzA8q&#10;KoreMmTIN7Nra+sGBgIGd+sJBHo6l9zoY7nk21Sdt7Zmo86/1OpcK/ROiMfjIzJ53/DhwxPq9UqE&#10;miU+Ba5Gt2/bgDg/saeq3e7UdJfV3QnA1qxbZ77/wQcZLczCkci9GVSVmw5gn0x/3kUXXdRy9NFH&#10;NyC1z9xIQ6iphFRPnCqSQrU7jzsR8FuaTxkA+5RTTvni/fffr7rjjjsyJciDAUwG8F4PjTIC4FgA&#10;V0ME4+UF04LB+OHV/8/emcdJUtb3//N9qqqvuXZ2Z3dZdlkXEVgEMcgliAIiEsVbMWhE8UhiYjQx&#10;JkZ/Xkg8Ea9IvI23eCRgMIqo4AW4RBDkWlg5lr2vmZ2rp6+q5/v743mq6umantnp6p6ent3n+3r1&#10;zrFTXdX9dNW7Pt9z2cgT8vkyqe5ucZzc1pJ3nTr/wchIK13hPhyoYS7WLNBjq9VqqYB++KpVfp0H&#10;Qjdyp/r+7UgAfqHObZ5RrddFzKOEuMjdfv/992dTLbzr7t2xY8dNnVTnZ511lv+Od7xjq1FnfqAE&#10;ODGDaKI5QLn5973+OTjhFeBZPFqmIAo8z/Mvv/zyOzds2PCMu+++O+059v8AvGQ+BLJW40/p1If7&#10;RNf1X7Zs2fATC4WSIMow0MOhpyMBcltL3j3qfLvqsJlGnT9qm8gsjHW9y91xnMen2W7Z0qUBlLuI&#10;kJywBtRPWGsM9YU6IZPx83DaGocnp6kIf3vzzfk0+1uyZMk1aD6+dTyAP0/7Gi+//PIdg4ODYgaY&#10;iznAfCZvaFq3O83hOZN/lyyZS5a4ZQEUVq5cicsvv3xjCx+JFwE4qo0fsdMB3ATghk7B/Cgh5DuX&#10;L9/7riOO2HZ8T49PRAWOwyxqlDEgHKIo4S2jktooS6TKzlQJGuWEoKxKdENWu989Y1KaHqoSPYRx&#10;ji/mErSOqfO4osMvS9mSOnfUDaNV5xbo061aqaSqc9Yzsik6ac079G7LbJ8tfh6K9BjygGomw6VS&#10;ib/z3e+myjTPZDI/TLHZa9K+xLe85S2TZ5999rgGXrJpjDNHmM8G3VZtNrA3A/VsCPULL7xw5yWX&#10;XDLWwvFc0obXdRyA/wbwO6jpbvNuK4j4rcuWjfzb2rVbT+3rq8xYS65j5LqWPAJ52lpycYiCvC3q&#10;XLnbw8z23hbU+eYq8DWLVgv0Rub5QdD02MpnnHVWkM1mmZNAoDmkvy0k4BNT1jBL/ByA3LZ9u1sq&#10;lZpfdCGmduzY8avmtlrvENFfpn1pb33rW7cJIcLe7I1auVLiMzkXmM+HNQN1M1nObEiTBZBzXTf3&#10;9re//d7UJ6cQl7TwOo+A6j53D5Trft4/2HkAbxwcHL1y7dotZw0MFLNC5HScPAsgYzaFcY2mMFmV&#10;5CaMMjQRJbsZIM/Ug1y54g+ypjDdoM6/PzKSOjnSqnML9NlsLTM33ajj+OOPj+PnccF5sqVjXXe4&#10;LrjBroN55F4P4+X18XMA4EceeSTV3PHenp5fQw0aacIeOI+ZD0+zvw984AP7161bJ1Hf/a2Ri92Z&#10;A8w7cV2eqWkN0DjjPnyYPd8zAHInnHDC5Fvf+ta9aQ5CSvl4AE9LsemboWrJX2e8p/Nqr+nvn7jq&#10;cY/b8uzBwYkelSPRqJZcgVx3dssQiaxS39Ejr74iq7LVD8la8oVU53e0ps4fq2K9VecW6DMDPc1G&#10;a9as8dG4OxyMSWpx0vs8S74miG662gmxq53YmMIGnRB3X8qEOBKi6WS4bDab2v178cUX70Fca+5i&#10;5rj5XGDeSZsN6snjN9vImvH0/KWXXvqn1Ko3n39Vis2WQbm4591e1tNT/MIRR2x74dDQ6BLHybDZ&#10;vleHt51EUxjPUOM5De3ooZvCZJQqbwjyuhK0cNASZi5BO2SsdXXu/6CFunOlzh+oWqxaoDe05cuX&#10;r0yz3WErV9YBnRpflLkLWN4I7GGcPHSzh7VrMOrPGYDc8H//lyp+vmTJklub2+IyUa1Wn5NmX+98&#10;5zvHjzrqqHBiWTJW3gy8F2qN5nJcybi6GVPPnXjiiRNvfOMbR9LsvFKpXJhis1vm+015Ti5X/vc1&#10;a3a8cuXK4SHPcxvUkpsgDxPeRFhLno1ryYVZS545xGvJF1id92+VMq0631LF+q9apFqgz2i+76ea&#10;N710cDDg+oYIbMTWeEHmnM9+V93oJI087lz//wSAJycn6Ze/+lXT7lQhRPmxxx67o0mgn8jMqdbi&#10;BS94wTCmZ7Unu78J4wark/HytFBPMqORUjcz33MvfelLH0uzYynlGjRfK75BX6Tbbk/PZKofO/zw&#10;XW84fM3u1ZkMMRBnrjdoChPFyc2mMDpzPes4lDWawmRnA7mR8IZDPU4+f+q8lcz2j1h1boF+IKAP&#10;pdmut7dX1t24z1ZzTtSNJ2as0AEyE+LCm/Dde/akio1ms9l70GTv9oGBgVRtXk8++eTgKU95yhTq&#10;s9rpAI+u8ZjMEfCz9YAPe79nzzjjjH1HHXVUKsgODg6e1+QmEwDua+cLforr1v7tsMN2/cPqNTsf&#10;n8tJQBYYyLFOdjNA7jRIeAtLzszubpG7PSOEisWYrvUGICcL8vlS59U/TEz0tajOv2JxaoE+qwVB&#10;sDTNdoVCgRt89usQPksNOi3AeVmn1I3RqFGpGtf/De/Zs8dN+d7c3ew2pVLpnDT7esMb3jCSyWSc&#10;BMwP5HLv1r4fM7naG8XVk2NZvZ6eHvH6179+R5odT01NpSk3awvQjxYieNfy5bvfsXbtticWCj4I&#10;+QjkgBcOTglryV2jljxnJrwZIDcy1yNF7tla8gVT5xUpg/9qLXb+UavOu8O6ulNcEASp3LyFQkES&#10;4HIC40YnGeriE9MkfXwDbuTEESD37duXSfmeNgt0qtVqqVq9nn766RMNYD4TwLvR1d7oePgAx5m8&#10;cYlc72edddYeqHKypqxarZ6d4ljvb+WFHk4kX7F06e5T+/vHM0JkmTnPcVKjQ0ZnNxF3bIu6urmh&#10;61yIsEVrONI06u420/AUOtTatC6wOr9jcrLvsfTqfGtVlUdas0Cf3aSUqVzuhXyeo5M+bA0Xcb1L&#10;x6VOhztHE9aS5zAR79q9O5XLvVAoPDDaRP/2k046ac2dd945kGI/OOaYY8pQyVIOZh5TeiCod7PN&#10;xJmG8fTjjz9+LOVHYSVU5vrwfAO9B+BXLVmy9ewlS/YWHKcgmXskcy6EuZ5JLkyIOzHE7VzyxajO&#10;W6s7/2iQbvyytXmwrna5SylTKfR8Ph/UXQDmCu4FADw3vvFudNLWJflt2bo11c3YwMDA5mb+fs+e&#10;Pcem2c9rX/vaYk9Pjz7nU8XKu/XaTQc4n5IKPcp8X7p0qf+KV7xiPM1O165du77JTTal2c95hcK+&#10;5w0NPdTjOBmpVHmOw1atsTIXemhKWFMuskQiR4TQxR7OJU+0aa1PeJullty61jujzv/QgjoXwLYq&#10;8GW7Khboc1UmfSlgjnw+L6d1hTPmoHfxtSH0q1PdT8A0lb5t27Y0Cl1u3LixqWzrqampVEA/7bTT&#10;JjG9TG2xwbsVpW56ISKVfsYZZwyn2UGxWGx2Hban2c+Y7+ehM9cZyMrpyly4cT252V8dOccJy9Ki&#10;ErTZmsLMVktuQd4Zdf7fLahzF/gorDrvKuv2aWtNx4nXPe5xTEQUhZwbqG7qDpBwg5g56mrQ49h5&#10;BHPSQN/4wANNA93zvL21Wq2pE7BSqRyTUlFWZlHnc0mGW0wwT/Y0aJT1LgA469atm0yzk3K53Ow6&#10;7CegzE02mNkdBFlWLvawEVB0U0bKbU6Odq1nwq9agZvxc9dIbEvGyPXdXTTK2LrXF0ad3zk52fdo&#10;enW+3apzq9DnHegDaihL/YVBOfO42y8Y02rQw0fYVEYfcrVWw8OPPNL04Xuu27Q6rNVqqabdrVq1&#10;qorp9eZJ6PEiVew0yxLOdPPiAHBWr15dTLPDNOtAwM5mt3koCLyA4enxpkIrcxKA0Elv5Km2rZTR&#10;MNe15KF7PcxcR6OmMLaWvHvU+X+1rs7LdiEs0Jv4zHLTrU17enpkgytvrKAWfvb5XLne6NgYRCiX&#10;SqnWjYTYl2INUjWbWLFiRRWNXe0Hc2fORirdvKlxVq1aVUp5LjS9Dg7QdA95H0CVZQaAw/q4w9Ix&#10;PaMckRtdAzysOTdVejjXXIQPrcptCVpXqPNaG9T5l+yqdJ91rcudmUkI0bRCzxcKDKJpHdgaNJSh&#10;BSRKciALG3fdsXJlbpQgxzXfT3XYruOMpliH3jT76uvr8zG7W/1gvXbPFk+n/v7+Wsrzoel8EgFM&#10;pdlXwOx4GuRswFwY7vYQ4B5AnhDQZWrQZWzT3evWtd5N6ty/prXM9o9Jq84t0Duh0OuayjSoO28q&#10;630+YZ5o6QqjmUw0WS3+ff0FNwg4pUIvp1iD/ma3WbNmDbuuiznC/GC5njcKIUwLM5gVGPMNdEp5&#10;0fXVtC0yXgCFBfWudp1r1zu7QsAxYB6WocVPUH/jfMgOTukidX7X5GTvw+nV+c4a8EW7Kt1pB10M&#10;PZfNpoNdh++wG7SyM3u31/dxN6FOhCAIUh2ulLLW/KE2D5I5tDjlQ+w8i9ZLCIHjjjsuSLEOTd1Y&#10;TZx8MhGQyr0vjetCOP+ADNe5bhbDYZMYV48jFg1gbqegdYE6VzCXAPxq6+r8o0j5ubJ2CAP9ox/9&#10;uJPmvDeUoemy7haAcANlHifAhS53lQRHDZW8PlFTUYXIT7FZvtkNBgcHA3tqzfzZXbFiRZobq0KK&#10;kztVSZFkDos+iaAz1PXFwiHiMGvcBn2ZAAAgAElEQVTdMRLdHA3/JMwbqXIL8w6rc7VJGDvvfUjK&#10;VE2prDq3QE9t//qvbwvSgLhSrZqDWLqnJMrsyW78Lpbi0bccqnSOY+p1r0OkDBkws5dis6bvxsfG&#10;xoQ9tWb+7O7Zs6fpdSCiqRQH4KW6KCQ+XxrmTIZbfdrYPA3z0ItkVflBqc4/ZtW5BXor1rSSmSoW&#10;U1035lHCRwFxs9acuZ7gUZtXKSUzg6U0Z6LX5ce5jpPqcKWUuWa3IaKJZrd59NFHD5Sbcahd29lY&#10;A2zcuNFJsQ7jKXaaTXOwjvpUmo2Yojh6lKGuXfBktFE2IE6H+oJ3ozq/qzV1vqsGfMGuigV6aiOi&#10;pl2G4+PjVKeKExfUaTHpeVbl3FiVcwR1A+YyhLkJ+Hh7glJJ7Lhu2sSqjgB98+bN5Pt+o+sSDvD9&#10;wabIOXldLpfLTspzYTLFAWVT7it6PZHKJuJG8fCoaYyhzmGVeVeq8/9uXZ1P2YWwQE8LcwbQ9Ei+&#10;0bEx0RDYyd+ZM0rnB+SczGI3QK1PN8lSSkgpIYMgiH4OAkj1PRtNZaJnynheKqBXKpVCinWYSLOv&#10;iYkJtwHMD0aQHwjspsDisbExL+X50LRCD4BUPQRcde5NmymsH6xVOs3gUl+wWcRWnc+izovFVtT5&#10;7hrwebsqFuitWtNA37VrFzU4Mcza7rkoq9Qgx8wg5wTImaWkENwa5CyDQLL6P5j0ByCJSBJRkC8U&#10;Us0e9n1/ZQqQjKbZ1549ezLhNWiW9/tgg3qj6zAb70Owc+fOfJonJqKmJrVtKpVIqgltTZkHwBOi&#10;XpwjdqOLMHM9VuVkE926UJ0bdec1KWvXDg9bdW6BvuAqvWlwbd+xg6SUNE0wqyYZ80NyjlPYeI4g&#10;Zyk5kDLQEGcZBKxEukSgVHsMdfNum8jPZrPlI488UqY40qaB7nneI2nekp07d2YSMOMGwKM5qtxu&#10;V+GmIOUZHgGAYPv27T1pduh53sPNbiOBpscPHylEIGY+H+tUdyO3uoV7l6hzs+68WOzb1Jo6/5xd&#10;FQv0dliqshvf9zlxdzvT1Zgb3QmnADnPAHI0ADkCKYNAQTxS5YEBdg4CHU5nqeNgARH5RFQlonKl&#10;UqmsXLEijdt9EE3GVbPZbKoxnFu3bs3qCwrP8gBmGxu7uFV5eB02H8Fjjz2WqvNeLpdrah3e9+ij&#10;/Qw03RRopesGzEw83XXOjWBe/0fTs+OtLYA6N2LnNSlr17Smzq+06twCvV0KfSzNdr7vU8OYOXN7&#10;FGDsWk+CPHSThyCXDUAuQ5AHvi8D9ZUNpS6llIx6mNeIqOoHQeWXv/pVz0UXX3zihttuSxOLJQBH&#10;NLNBoVB4MM1bdNttt/VqoEs0dr0vJkXerGJPQj2AapNeu/XWW5el2UFPT09T6/BQtbouzX6We56v&#10;rwuxR8uImde1cCWL7K5U50bs/I/FYm8L6nyPVecW6O07OCFSzY6u1mr1TVmaz2rnA4Ac00Aelqcp&#10;WS010ImV+7wRyGX4vQlyrcoDZvahQF6RUlZ+t2GDe+nrX7/mpS9/+arf3nyz18Lb2tRc7eXLl6dS&#10;6FdffXWhWCxiFpV+IJB3K+RnOy7z5qVOmQPw9+/f71x99dX9aXa6ZcuWpoA+LmUqoA95Xg1GDpyZ&#10;/Fb3oEbtHqwo7zp1PjKytAV1/nEARbsQi8e6upe7EGIkzXaTExPOQF+fCtIq/kZqQ+tqFb9lnq2v&#10;+zS3/bRkt/DvpteVEys4B1LHwTmOizMzI8xgNxR9HQiIKJBS1u784x8zX/jSl5b/97XXem16W48F&#10;8OO5/vFdd921lYjGmHmgmZ2MjIzQpk2bcieddFKggeagsUs6/H1yrvhiEVSNblRMkEfq/N57702V&#10;dU5Eu5m5qUl5VeC4NPsa9DyfAcG67jxRi27L0RaZOn8wCNKq87014D/sqligt80cx0ml0McnJsRq&#10;4wLLsZJuDAwNdn0DMLskawDymONarYdSWye26R/D76O4ut5U6hsMCSKpL/7+vffdl/nKV7869M1v&#10;fzvT5rf12GavM67r/rZWqz2v2R3ddtttfSeddNJwQrUK422lA8C82wDPBwA7Gih0H6pBUvXmm29O&#10;pZozmcyvK5Xm0klKzCek2dcS1eOAKFbo8dhTQ5Fbt3uXq3Pm2jUjI6taUefSqvNFZ13tcnccJ5VC&#10;Hx8fd3hmGLDRN31aItxMkquRaz1OXpcswxI05UqPktyir76PIHStB0G4acDMAQM+iGoAyo9u3szv&#10;ff/7l53zrGfNB8wB4ORmNygUCr9Ks6Mvf/nLS6vVaqhQk6Cba3Jc9/Thn1lQIfHagqQ6LxaL8itf&#10;+crhaXZcKBR+2czff3HtWqoAT04FdMepmdeFOpe7bv3aKJPdjkTtLnV+9+RkK+p8uAZ81q6KVejt&#10;Bvr+NNuNjo0JAgKunysexdWNnw+sAJOKvL7LW9jNTRotW5PKvM7VHnWKMxQcEfnbtm0TV3//+4NX&#10;XHllfp7f1hOhBq7MuSfz2NjYjWl2dMcddzh33nln4fTTT/c12MIW4LPF1BeD6322enMT6jX9qNx6&#10;663LH3744VQX2P379zf1/v98eLjXb94TAwAYVAo9a6j0+tnmiT7tIgFxC/KFV+c+s//D1tT5lRKY&#10;sAthFXp77zZcN5XLff/IiAPV7Sq88BLHd7s0w+kzrYSN4zat02rJDUUe1ZIHvs+BVuVJhc5hwhsQ&#10;gNkHUCOiyvYdO/jjn/zkkpNOO21lB2AOqN4hJzW3yWV3E1GqtbjuuuuWQTUI8hFnvSfr0yXqa7gP&#10;pI4XWp0DjWPm0+Lm+rWXr7322iNSnaBCbAXwp2a2ua1UOj3NzfpTPa+WadxUJhrEQvWqnbr+InII&#10;qvM/Tk723J9ene+rAVfZVbFAb7vt27dva6rthocd/QGPz5fpfd3NPukwp55xo37r9SCHAXIY4JZ1&#10;JWhKmcsI5Do+DqLqnj17gs9+/vP9J5166oqPfOxj+Q6+rXcBaLKN6GUyk8lcn2ZnH/rQh/ofeeQR&#10;NwH02VzumOPPCwXzmUrU6jLaDaBX7rnnnr7Pfe5zqcrVstnsT5rdZpL56Wn2dXQ+X9FeFNLjT0nD&#10;nAQRCSJyEPduT9SgW3HeJer82tYy2z8BYNIuhAX6fNiWNBvt2r3bAcAUJ8WZLvcwhh63gjWy2I3p&#10;ZrOBXBogl1E9uYa4hrkuQmdpXOCrIyMjtW9/97uFp5977sr3XX55oYPv5QMAXgNcdjKAe5vduFKp&#10;fCvtjq+++uoVWqnWEMfTkw9uoHwXGuqzxc3lDMo8MJR5BUDpa1/72hPSHkCpVPpmCqCfm2Zfj8vl&#10;ShzOW0Fd3Bxmu1cypqxZjneXOr97crJnY2uxc6vOLdDnzbYRUdMd0R7dvFm53Inq+4bXJ8KZ98TT&#10;mrQmu7vNBHLTrR4mxYW15IZKq46Pj9eu/t73Cmefd95hb33b2/r2j4526j3cDOC1wPoTAHwDuEym&#10;e5r1vyCiHWm2fPe73z24efNmod+LIKHUTRe8P0flPt9g5wPAvJGr3cxo9zXQy/fdd1/hE5/4xIpU&#10;J6cQjwC4tZltnpvLDVaBp6bZ36pstgqY/NZJcMb8czHDrHNrB406t7FzC/R5s5rjOE1D5Lc33+zW&#10;ajVucGFmNpV6PG+8Lk4upUQ4OGVad7cEyAPdECb8BwbMiag2WSzWrv3hD/MXXHjhyn/4p3/q271n&#10;T6feux0A3gSsPxbA14AHgtae7oGAmb+ddutPfepTa6SUlQYqfaZBJgdqQDNfUOdmhBSmu9l9rczL&#10;QRCUrrjiiielPRAp5TebfZ13VirPhMqTaMoGiXi560Zd4qI4eajQtcud6omvVHriuSzoF0ad31Ms&#10;Fu5vTZ1/xq6KBfq8WiaTadrtXiqVwjh6dK6w0TXOKD8DwpnjKkMdepypOTglBnnY3c1wr+vJaCbI&#10;a0RUKZfL1R//5CfZF7z4xSv/5k1v6n/4kUc6dZ3bB+BfADwBwGeBB6ptfO5vpN3w05/+dO9vfvOb&#10;Pg07PwH1QCvaZmLs7VbrB0rIa5TNHqBBzFw/pn784x8f/o1vfGOgheNpOswxzvziNDs7O58vu0TC&#10;4LWKncfx82kJcWaWu1XsC6/Ofzg83Io6/6RV5xbo825BEGxOs92e3btdImKzCYa+SqqLsgK5aphu&#10;gFxKKetAXt+m1QS5jBLemAMw14ioWqnVqj+/8cbsy/7iL1Ze+oY3DNx7332dus6NA7gMwOOhBiqU&#10;5mEf9wK4Ie3G73nPe1bv379fYnrWu2zw82xT2maCcbNw5zk8ZzMwD+PmU7t378Z73vOe41p4r/8H&#10;wEPNbPDa/v7CFPD8NDt7Yk9PEbqskIgo6Wp3wu+JIrd7LMltIL0b1Pm9QZCqDFkAI1adW6B3xDzP&#10;eyzNdtt37HDRaJqaMUSlbhpaPBxl2gS0mUAOVYJWI6JqLQgqv/7tb71XvfrVK155ySVL/u/22zv1&#10;3k4BuEKD/P0duMv+YNoNb775ZvcjH/nIEUEQVBpA3TcAOZNSn2sP+Lk+5nq9lU3AvFSr1Urvfe97&#10;T7r77rvdTr7PN0xMXJBmwhoArMvlKhz3CZgWP6cGMLccPzjUuQA+haYrX6x1o7ndfoC5XO7Bycnm&#10;qygee+wxD0Rls76cY5iDpQQbSXMR4MNQuNmu1bwDqL8zDgJm//f/93/Z//j855f+9IYbOvl+VgF8&#10;UV/4d3Vwv7/Vj1SlUVdccUXfKaecsvSiiy4aheHe1VCcCa4C03uYsPF9u4VTI4UeQj0J86oJcwDF&#10;r371q0d98YtfHGzhOG4AcHuzG+1nvjTNzk5wnGCZmrIWNZTRrvYwEY4civ3xJsxt/Hzh1fm9Lapz&#10;H/i0XRUL9I7Yvn377k2z3X0bN2YIkBG0FdcpipULwcRMBswjeLMJ9BlALplrd911V/aLX/5yOwen&#10;zMV8qFj25QAeW6Bl+SCAn6bd+NJLL121bt268qmnnlrWDNgPIDcDWEPom81nzERrbpEns40+Tap0&#10;eSCY33TTTcv+5m/+5qhOe0Ge6nlrNtRqz02zs6f3908S4HKcEBe9uY6CeajS47r0+M0mGz9fcHV+&#10;WAvq/NPSqnML9A7aRiIKmLmp7M2f/exnXs334bouJyatEUupvhLVNY9JwLx+AhpzAKKAgdp9anDK&#10;8m995zuZDr4PEsD3AbwPwKYFXpMbANwE4JlpNp6amsLLX/7ydddff/0j69evr0CFDZIwZUOdswH2&#10;5HAXaqDaWxVNSVU+U9OYKGYOYPKOO+4oXHzxxX/W4nv7v9oD0pT9yfdfl/Z8TsTPRZjR7hiNZAQA&#10;R4h6l3uEc2sLqc7vSanOCdhv1fnBZYuha2Mpk8k80uxG+0dHMbxvn2NcbmJ1rvuryyBAEDaOCWPn&#10;0Wg0rm/hKUTlwU2b8K73vGfo3PPP7zTMfwTVrvUVXQDz0N6kgZbKNm/eTK9+9avXbd68GVBTnYoA&#10;yhqQYROamgHQ2RLmGDPH2zGLAudZnisJ8ZrxCEFeDmG+cePGzCWXXHLK3r17WyFcCcA/NLvRk123&#10;Zz/zm9Ls8ATHCVZ5GT+Mn4d3TEKrcq3OKVl/buPnC6fOWavzgNn/n9bqzj8NYMwuhAV6Ry2fz9+f&#10;Zrtde/Y40QU7ET+PMtvjpjDScLObKqz86ObN8gMf/ODSs845Z8WXvvKVbAdf+o0AzgDwAgB3d9my&#10;PADg4608we9//3vnZS972VF33313FqrdZFFDLQl2P/EIDNjKWQA9U0c6nmG7AI3ryv0GIC/p4524&#10;44478i996UtP37hxo9Pie/phAE3fvG4Ngr+SQKrmNecMDEyIkN1m/DwsV4tj6aGbnYQRP0+6SKzN&#10;rzpnQJKhzu/2/bTqfNRXyXDWLNA7a6Ojo6ni6A899FAmHNJiJL3BLFOL4uZG1rq+gFe2bd8ur/zk&#10;JwdPO/PMlZ++6qpcB1/y76Dc2c8CsKGLl+YDaDGOf8cddzjPe97zTrv55pv7oGJ5k1r1mlCvzgD3&#10;ZMvVYBbV3Qj6yTGncgaIVxuo8iKA8ZtuumnJc57znNPaAPM/QVUrNGvZUeZ/TrvTE3t7i6xc9QKm&#10;u10pODhCwHS7C/PCYWV629V5MMfYeaAmqll1bm3xAR3APakU4O23ZwkIKFbp9e1d9QOxe71GRLXd&#10;u3f7n/385wdOOvXUlR/t/OCU5wE4E8AvF8G6TAF4A+JBOKls69at4vzzzz/lG9/4xtogCMahSu9C&#10;sJcw3Q1fQ32bVT8B56TaPtDvw+3N553JvV4EMOH7/sSXv/zlI88777yTWnSzQ+/z9Xo/TdkQ0Wsl&#10;sDrNTi/I5cpDalxq6G6nyN1OBFe72x1driaMXu7W5ked+3NU5/cVi3mrzq0tVqD/Ps1G37766myp&#10;UgknnMUxWAXxEORRu86RkRH/W9/5TuHp5557WCcHpwgic3DKjxfZZ+gXUK7ilqxcLuM1r3nNMW9+&#10;85tP3bt3bzWh1kPFnlTtNTR2yfsJ4AcNbgAa/W2tgRo3QT4JYGzfvn2Vt771rU/5q7/6q6Pa9B6+&#10;DykS4YD1zn7mt6Xd6dMGBsZZtYl1iEgY7vYoO24WdzslIGGtc+q8dt3IyLK0u9fqfNQuhAX6Qtkj&#10;juPsbnajUqmErVu2EAlRJaIaESmwq6++/l1lYmKi+oNrrimc++xnr/zHDg5OcRxnC4C/kcxPQkuD&#10;UxbaLnsvVLy/Zfvc5z639FnPetbZ//M//7NcSjlmgD2Mr4eKPemOb6Tg/RlAXmsAcBPkFWNfIcjH&#10;pZRj119//bILLrjg7KuuumpZm968m4D1H02z4VJ68M2BavHbtD1BCHlMoVCG0UxGK3NyichVlIcL&#10;7XbXLvfootFohKq1dqhzNtQ5THWOWJ0X7kyvzsdsZrsF+oJbEAS3pdlu00MPuUQ0JYjKJESZiMJH&#10;aXJysvJf116bO/f881f+7Zve1Ld9+/aOXJ+EEDsAvCkIjj4aqjmMv7g/RpdJ5WHA3nY829133+2+&#10;6EUvetIb3/jG0zZt2gStJsagXPHFBNxN1V5JgLk6A7CT35uJblOGIp/QNxSjGzduFK973etOf+5z&#10;n/vkP/zhD+3qO7ADwCvSDM5ZLcTh+5kvS7vjFw4Ojno6VE6AMBLhQjc7uUZzGZvd3jF1DkOds6nO&#10;qX3qfL9diIPTnEV0rI8HcF6zG61duzZ45rnn7tTjVAMiqpbL5eBnv/hF4e/e/Oah//zqV3OjY2Md&#10;uUo5jjPMzJcz86sA3ArsCw6iz9IEgF8DeCWAtpT0/eEPf8hfddVVjxsbG+tfsWLF+KpVq0YxPe6d&#10;fPiz/E0j93utgToPgV7ctGmTd9VVVx170UUXnfDHP/4x1+b368/RZL/20CTzF6rAKWm2HSTi1y5f&#10;vs8TIgPAIyJHAMITgjwikRGCskJQRghyichT8XRy9Bz0sCWszW5vTZ3rEjX4zKgxowpwVUquAlzT&#10;aj2Ikzd9Air3Tk3lvjsxkaq9LwHjUpW+luzKHJy2mM7Fc6GamTR3F/D4x8vfb9hwo+e6uVK5nL/x&#10;xhsP/+SnP73y97ff3rGbGSHEmJTyEzg0JhpdCOBapBjheSD7x3/8x70vetGLtpx++unDuVzO0TcO&#10;HlSWtqs9Tg4aV1Q1uraafeQjuJdKpWDDhg1D11xzzdqrrrpqaB7eo6p+n36RZuNeomdOMv8i7fn7&#10;xiVLxp69dOkEA3kAniByXSLKCCFyRJQVgvJCiKwQyApBGeV6pzDjnfQYVQv0JoGupzyqVpMSvgZ3&#10;VUouS4my+splZq5JyTVmGTAHrGEeME99eOvWI9K6213gAz7wHrsqFujdYH3aVdQ0iG/+zW9+tmXL&#10;lsP+43OfW3/LLbd0rCEMEU0x82egypFGDqHP1asBfG2+Pl8nnHCCf+mll24/88wz9xx//PFj/f39&#10;PAvUG11jzbp0H4A/OjpK991335JbbrllxVe+8pXVmzZtmq8bPqm9GN9Lt/n6jIsH7vSBJ6ZV559c&#10;u3Zrn+NkAWSJyHUAx9NAzwpBeSLKOQ7l1O+UhNeZ7w5Ayfi5Bfrc1DlCF7uOmdeYucqMioZ4OQi4&#10;zKxUunLBS2b2GagRULqnWPQu2717ZVp1zsCRh9h1yAK9y+0PUB3TmruILVnC+0dHO/ZaiajKzF8A&#10;8CF0dnBKN9k/aI/EvL7vuVwOF1988ehTn/rU4SOOOKK4Zs2a4qpVq6b6+/v9bDYbJPbP5XLZGR8f&#10;93bu3FnYtm1bYcuWLT0bNmwYamFuebMwfxOAz6d9gkGiD+1nfmfa7f9ucHD0WYODEwwUSLnbXZdI&#10;ZLQyzxJRXsNcu92VOtdAJ+tuXzB1/pGtW9f8wfdTeb5c4IM+8G67Khbo3WRXAPiXrn0ziXxmXujB&#10;Kd2m1L+MeXC/z9XOPPPMSqFQkJOTk86GDRsyC/heVKESB7+b9gl6gD8vqrLGVMmsK4j4yrVrt/YY&#10;6lwodS4yQiCnXO7IOY7IESGjYurkapiHc1WtOu+8Or+3WPTeZ9W5tQPfuC0q+0WXAp0B/BczvwfA&#10;g/ZjFdk3oDK5r4EKmXTcbr311mwXvA9FAC9DCxPqjhDisO1SfhUtVKZcumzZSI/jCH3eCwKELlND&#10;WKrmChGWrEXjUkUMhrocdwvzuV4dlDo3M9sDNMhs17A3e7YT4Evm2v+OjKxMu3sH+IxvYX5ImFhk&#10;x/tbqPKibrLrAPwZgJdbmM94E3YBgD2H6OvfCeDsVmAOrHf2SPk9CaQek/kU1/VP7usrQiUSOkQk&#10;BBBNU3NNsIfx8liVR7XnFuQp1Dnq685lo7pzpd7NiWocdoW7f2qq8PtaLZWXi4AJX4W+rFmgd52V&#10;ANzcRaB6KoAXovsGp3Sb/Q4q9+HXh9jr/pm+2bujlScZpAcvrwDPaOU5Xr58+bCnRTjC2nPdSMbT&#10;6tybrs5n7Axnbd7VeQCtzq8bHm6lZ/tVAIbtQligd7PiW0jbADU05XwAt9mP0JxtB7D+PADvh7pY&#10;HcwWqNd52XNa9UysJHpVK0lwAPDinp6po/M9lbDNqyAS0bxz/dCZ7KY6J0Od28z2eVDnwRzU+cap&#10;qZ47UibCEVC06twCvdvt5wu03zuhBqecgTa1OV1EthrAZwGc1trTPBAAuAyqocrmg/S9eghqUt5l&#10;rbbyLQAX7mb+z1b4uYqIXzg0tI8gMwDcsGe7A0RNYzwiuELETd0Rz0S38G4Z8DOq85qUMdwbq3P/&#10;uuHhwRbU+WfQpu6N1izQ5xOs2zu4vweg4uOLcXBKq7YUwEehRnv+rX79x7XJy3I8VFlf9SB5r8r6&#10;ZuVJAH7T6pP1E51RAr6PFisEXr98+XC/4zjREBblahdha1c37N1er9CtOm+HOtfd4JBOnfsPTE3l&#10;b0+vzid94ON2VSzQF8N5c20H9vMogEuB9ScA+IFxvh4KVgDwDgAPA3g7VEcxABgCcAOAdW3YxxSA&#10;dwE4EQsfRmnVfgLgBKhwQstJm8uInjjJ/CNW65DaXlQolE5S8869UJ0LQLjqB2iFHsXQXT2ExbHq&#10;vK3qPFBgj9R5oCeqTVPnRrMjyVz7UWvzzj8LYJ9dBQv0xWDzCfQdAN4ErF8P4OtpBmcsYvMAvFEr&#10;8g8DWNLgb44A8Cuo3vrtsAeh8hGerZ93MdkvoFoSX6hvflq2ZURP3M98gwRamub2BCHkS1as2EtA&#10;FqqBjBC6TC2cqOYRwVOd4FSvdnVBUI1jrDpvqzrX0FYK3ezVbqpzZobuXPhAqZT/v/SZ7UUfuNKu&#10;igX6YrHfzMPd5z6oGvcnAPgs8ED1EPocEIC/AHAfgM8BOPwAf/84qIz1Y9p4DD/XcDwLwPVdfu2+&#10;DqrC4fx23oT0E52xn/k3EljT6nP91cqVe3qFcBOudhPmprs9Uudm7XmjhvjW0qtz35h33kCdhy2J&#10;A8lc+9/WMts/Cxs7t0BfRObri2o7bAzA+7TivBKH3iSiCwDcDtXB7OgmtlsDVUJ4epuP5xYAz4Xq&#10;Vf4RIcTWrjhRhHgMwAcArIcqVWxrhUMBuHCC+eetKnMA+PulS0ePzudrSVe7AwjD1Q5PCAr/wFEg&#10;IKHVObQ6t9Z+de4b6lzG6jycK1B7oFTK3WbVubVDCOiA6j7Wik1BJXw9HqpV68QhtvanQ02v+ymA&#10;p6R8juX6OV44D8e3EcA7pXzvOgDn5XK5rxHR7o66LYh25nK5LwM4W0p5JNSkqk3t3s8KotdMAdcy&#10;0NPqc72gUCidPTAwxrGr3Qld7a4QcIkoozLbo7GoZiKcSIxHteo8nTqHoc5lqM6BZN05B8rNHqlz&#10;Zq79eHg49U2dUB62PXYVDk1bzOdpFsBuAM0O1agA+CIO3cEpxwH4IIAXtXH9AwDvhYq78zx/Xo9f&#10;smTJeVNTU+fUarWzmXmwbU9ONOx53q97enp+uX///hv1TcU82npnkB68bD/zu9qxFn/muv7bVq/e&#10;UXCcDICMHr7iuEQiTH7LCqEGrzgOZbVKj8ajanVuJ6q1ps4DgDmec861Bj3bK2oAC9c4THJHFUB5&#10;49SU8+5duw5LeXJM6Z7tFugW6IvSvgDgr+f4tz6Ar2s1vuUQXOsjoMqqXoMUI2ib8Jpc2klvxymn&#10;nHL4rl27ji0Wi8dWKpWjfd8/WkrZy8z9zDzAzL365q9CRJNENEZE40KICc/zNmWz2T8VCoVNq1ev&#10;fuC2227r2A3eaqLV+5i/XVFtYVtfXCHke1av3jHkeYKBbAhzYcKciHJ6RGo2Hr4SqXSrzlsHOrP2&#10;nUuJwJyoxoxyEEQT1apSypr6W6nFe4WZp67ctm31hpTudgf4eAD8s10VC/TFak/DgVvBMoD/ghod&#10;uOkQXOOlAN5OwFs4Lj+bT3sUwCVQsXBrDayX6JlTzN+SwKp2PJ8L4COHH77z8bmcZCBHKizuChUz&#10;F54QyGqga2VOGT3rPBzKIoSAo7u12/GonVHnPrOU9ercffeuXWknqpVZhQ932pU5dE0s8uO/9QCQ&#10;NgenHGow7wXwblKA/dcOwc/Dac4AACAASURBVBxQLr9fAvh/wHrHnmJ15g0SfXBSJb+tateTvnfl&#10;yj1H5nK+VuYuiBxzklqo0D09DtXT8XSz5jxS5DYRrhXAM6AayISx88CMnQN1sXOeHjtPHT4SKrPd&#10;wtwCfdHfJH+jwe9vgXJlHoqDUzwAfy3UDcy/MdC/QMfwQRcP3A7gFHuaAX1Ez3CBO/cz/792nnfv&#10;WrFi7wk9PWWosIKLOAlOZbNriGf0I2zz6kJltTu25rxt6jzs2a4JHU9UU2qcfQ1yqeGvvw0A1B4s&#10;lXK/q9UyadV5YLvCWTsIgA4NdGko9rCW+TeH1lJeJgD8pVCNWr7QTgWY1nzlHfldH9EV2mNwyNkR&#10;QhzWA3xzgvlXvmp32zb756GhkZN7e0sM5KCS4EJlLswucGHym+7bHk9UM2CerDm31hZ1DlOdB2E/&#10;93p17jOj9uMW6s51ZvsOuwrWDgagbwXw71CDU56GxddtrB12oYPL7gTwLalc3t1k7gTzvwhg03Ki&#10;N+gbj0PA1jvLiN68TcqNReBV7WblPw8NjZzZ3z8RlacpRju6Exw8lQyHjJnJnixRAyKYJ13tFuzp&#10;1bnRs50DQ5n7zCzDcaqGOt9Umsrdml6dlwLgCrsq1ux5u/jtaR7w4Rrw9MVywC5w73Ki9+9k/m8c&#10;lP3x12eW04OvHmH+10B1HWy7vWv58r0n9/WVNMwzOgkubBxDGuAiKwSy6nvK6ri5odBBuqGMdbW3&#10;BvSIzkqJh5ntSCbCVZllTUoO6jLbMfXJ7dsOv6VaTQV0B/h0APyjXRVrB4tCPxTthCzwIwA3LyaY&#10;A4APnLCT+QcucPdhRBdfkMt5B8OCnOS6hWVEb3bwwJ/2Mn9pPmCeB/D+lSv3aJjnkjB3YpibzWMo&#10;E8McBszVyW9h3jF1HjaaSarztDDX6vyjdlWsGYLJ2iKydQK4XAJ/WVnkN2M+cMIu5qv3lstblxF9&#10;/smZzJduqlQWXf/p0zxv7cO+f8kfff/vJXDYfO1nNZF826pVu9epbPY4Zm7APBPDnDJCUDZ0tesk&#10;uOTglWS9ubVUgDdj59AT1aLYue7hHsK+PnYO+D8ZGVneghr7UmAz263V3+RZWwS2wgHeJYE3MpDp&#10;xA5dAK/s799xQk/P9u/s3fuku3w/N88fxEoe+NEg0TdeOzR0wwf27u3a4TgvKRT6by6VXjzGfElF&#10;JWHO683Vn7mu/3erVu0a8jzSbnY3ipmrTHXSTWJUjbkQIdyRCYev6Ni6YybBJUak2otB8+o8rDsP&#10;dN15NW4kw6Ug4ErsbjfrzmsASptKJeedO3em7QpXZuAo2GQ4axboi8b6XOCfA+CfuINZ4hf19Iw9&#10;e+nSrSsymSIBKEpJP9iz55hrisUlndi/APYWgB8NEF13bm/vL741MVFc6IW4qKen79apqWeOMl80&#10;BbyoHX3X52LPLxRKL1++fG+P47hmnbnQ09NcwHSzq4fj1PVrd8LmMfr7MAnOutpbA3oidq6ALiUq&#10;Ruy8rGFek1LWxc6B0qe2bVt1c/rY+WcC4C12VaxZoHe/ZT3g7wLgnVINQOmIXZjPTz1n2bI9q7PZ&#10;CuIpmmpgFODfPDo69Inh4ZUd/oBOZYDf9RL9aoDoV88dGLj9tatWVU++/345X/v84tq19Jv9+ws3&#10;F4unTjCfNcl8bhV4mlbHHbM3DQ6OnrNkyZggCjPZPcRzzYXOZq9zs4ftXDMGzB2ouLnQ2e0W5vOv&#10;zhPJcHXqnIDyg6WSaFGdPwHAdrsy1izQu9bWO1k88GofeF+gZo53xM7JZCrPGxoafnw+X9YufQfM&#10;AgAxwARIIgoAVB4tlbKf3bXr8IelXKgYfs0D7ssCd+aJ7ssAmwaFePjMvr5H/+bwwyvH5PNzzpzf&#10;VCrRJ7duzd85NbVuTMp1FeC4EvMJFeBEHzi+U+GNpB0lhPzrlSv36BGooYtdec3rO8AJDXSYbnav&#10;AcxtRnt3qfNPb9u26rcp1XkP8B9F4O/tqlizQO9SywMvqgIfCNrcfGQ2O8V1ay8eGho+tlAoE5Bh&#10;FTp3OVbnoUnSiTyCqDrm+/K6ffuGri0WC930HgpgRAB7BDAsgEmhh8Q4RGMB84C+IOcCYKlUjyEJ&#10;DHXTa3hhoVB66YoVe3uFcPU887DGXIgY5mHTGESxc6NxzFxhbi8AzcNcifPW1PmmUkm8I706r2h1&#10;vs2ujLWk2Sz3hbezPeDDJeCMTu3wOMcJXrZs2fCTenqmHKIMAwWp4OFokCev+2F2riOZnX7Hqb1q&#10;5cq9JxWLua/v3bt8AdV6nWlIT++4xd1f7r6KiF83NDR8Ul/flFA3Vx4MVa7j5cKNu75FytwzytRc&#10;C/N5h7uZ2R4gasaOaT3bAU5ktgcSqP1keDh1F8cC8JWihbk1q9C7zo7PAZeVgZd1aocriPgvBgdH&#10;z+jvH88K4SBW5Y5+0ExA11gMlXqoNqrFIAhuGBlZ+u2JiV67pOnsJT09U88fGhoecBwRqnLUq/K4&#10;N/v0dq5RnXnY0tXCvLPq3JiohnIQyHlU51UGjgHwmF0Za1ahd4cdpWvJLy53qJZ8kIj/cnBw9Kl9&#10;feN5xxFQdcwua5ATIEAkSJUzTStNZvUzMzNBxdXDvxE9jlN76fLlI0/u7Z385p49Q/cEgf1MzdFO&#10;cl3/5cuXDx+Tz1dgqnKo/DXTxe7EiW5qyIoRL0/CXFiYz6c6R1Kd+7E659nUOQO161tX5xbm1qxC&#10;7wIb0iVo/9ipbGkXwGsGBsafPjCwv891hVZ+nga50O5cCh9ClTSFUFcUh54MhSgRiBmQuh91oBV7&#10;jYCaz+zfWyzmv7tv39JNUtrRqTN9EIj41UuX7j+9v3/CI/JCkJuqXCggCzdW5jBArqamGR3ghJ6c&#10;JvTCCgvzhVPnKkFumjr/U6kk/tWqc2tWoS9qGwDwdgL+we9Q7TIAvLKvb/KZg4P7l7ouwgEeiEEu&#10;CBC6WxgJDXMdQKeoVNlQJZIZkgiBGi4hJDNLImJAgpkYcBwi/896e6vrC4Vtv5+Y6Pv2yMjgHqXq&#10;rQHoI+JXLVky/tT+/vE+xyEG8mHIg4x1ceJmMJGbXcM8Snoz4+UuVJMYs2mMhfk8qnNgdnWuhrBM&#10;V+cjI6k7CRaAr1p1bs0q9IWzPIA3EfAOBpZ1aqcvKBSmLli6dP+qTCbQZVeufoRudRECPFR1jvoZ&#10;jlKHZhCdtCIPE39Yj3+EnuvMklka/akloK5vBNSKQSB/Nz7e/83R0YGJQxjsfUT8ioGB8TP7+8f6&#10;XZeMdXEAOEKHO4Rq4xpORSPX7Mlujj9tHC+3MO+0OgdQURntdeq8JiXXEur8oVJJvL01dX40gC12&#10;ZaxZhd5ZEwBeCjU04chO5Vefl81WLly2bGRdLldlFY/NhsAI4+OhKzcEuatds1FbUMRzss3riQQg&#10;peSAiLQiib6XgAjU/GdigFjVrzsMuAXH8Z81ODj5tIGBsfuKxZ6f7N+/5C7fP2Q+c0cJIZ+7ZMn4&#10;yb29E/3aU2Iq8ugGS4GZDGU+HeYh6A2YCwvzhVXncUZ7nToPpqvz6k9HRlqJnX+1aGFuzSr0jr+X&#10;LwHwAQDrO7XTp3pe7YVDQ8PH5PMVUvHxKB47E8hDN20IctdIvNIx2OiDEbnbAQqnRulHeCFj7WKM&#10;VDurJhrSuP4FAGqS2X+0XM7eMjY28D9TU/mD9YNwfjZbOWvJkrFj8/myp6oJQi9JPchjz4hS5EBY&#10;Yw63XpWbs8wjj4qAio/orw2bxdgT/KBQ5zZ2bs0q9A7aeQA+DODUTu3wBMfxXzY0NHJ8oTAliDwY&#10;8VjoZLcGIEcIDSeOw4ZQNwLs9RiQzJDMHBDBZyb9YF9d3OADFAAsdIw9YHaYSGiwOxrsriAKjsrn&#10;/Sfk8/ue5/t09+Rk72/Hx3sPBtV+nOMEz+zvnzixt7e43PMCfWOVQ1wSGMXISavx0CPimBDXsXKX&#10;KFLlzhxd7CbALcgXRJ0r8CfU+fUtqPM88PUpC3NrVqF3xE4B8CEA53dqh0cKIV++bNnIU3p7J111&#10;zY8VeQyNKB7rhMBOglyIUKXrQK6IXLhAXE8XNkwPFNQRGBcwXyuS6MJmuBx12Q60Yjdj7FGsnXSy&#10;0O5azf3T1FR+w/h43+9qtUUzH3294wTn9PVNHtfTM7U6k6kKIjdR1x8mnVMyd8FVvdXhNQK6kRDn&#10;GsluRkmadbF3UJ3rXJF06rxcFm/fsSNtMlwNSp1vtitjzSr0+bNjAPwbgIs6df0c0rXkp/X3j+WU&#10;GzdvgNyh2L1OOg5eB3LXUORhBrVjjNUUJn0S+5ZqJyyJEADkSAkH4PBmwZcSNX0zoC96cJgpIGLJ&#10;TEaMXSCGu8tK8GRWel6wcmCg9PSBgcl9tZrzcLmce2hqKr9haiq3XcXku8L6iPicfL58fE/P1Lpc&#10;rrzc83zSa8BAgeshLhIlgXDitYkT34A40c0IhbhCRAvrQLnUw1CIhXln1TnPos7D+ecN1TlR7afD&#10;w61ktn99ysLcmlXo82arAbwXwOs6dTOUB3DJkiVjTxsYGO1VTWEyCZBTnRtXA8BtoPxmAnndjGyt&#10;AuuArkrVwisV64sXfCkRaMUShGpdl/EEoWLXDTYCpXQQlvMYqp0Tyl0CCAgIJHMwEgTurkrF21Iu&#10;5+6Zmsrf1kEFf4rr+sfm8+XH5XLlVdlsdYXn+Z6633E4ocKh18Bs0CPM+nCd+ObW5zDAE0Ktk15M&#10;A+QqVj6LKoeF+bwqdFaf+7CqAz7AVeZInVeklCUp69W5KuOsEVB6uFwW/2LVuTWr0LvOlgL4VwBv&#10;1oztiL2qr2/inMHB0Ua15OEYzRDkIgRCvRqPYK7VegQNE+R1iXAJ1cdaHUK73MNELsHMQggEzORo&#10;iDuOoxLnQgUTxtQB8pVaD4lNMlbtSMBd5eGpCW+8zHXlMtcNTujpmXjusmWjZSlpMgjEeBA4Y77v&#10;DNdq3r5azdtaqWS2+L7TjKJ/nBByleMEKzzPX+F5tUHP8wdc11/qef6g4/hZIRC+3xrgnjG4RlX3&#10;xTdUoLiuH4anBE7sYo9A7gpBhiIP107Fxw33uohDIFaVdxLmiTvNUImHn+0gDjEhvFllgKFEu98G&#10;df4Nq86tWaC31woA3qJhvqRTO31xT8/Us5cuHVnpeZKNKWhoUEvumJnrIcCBGBhEUWNwx1B/IqH+&#10;QkiYXeLqLnJETERg5sjtKxTtOCCCw0yuiq+T6zhhjF1dBJnhahd8ELrgmUOoMyvAkzH4gpWQN6ZV&#10;qusqZ4XgrBBymeeFcfhaeN0lddPAFWaSzKKqhsZElYPa1c0C4IwQ7KjXEzkmOC7Bd6He9+j/4rcn&#10;arwTutNhQjxMKozKAZMJiULUKXSn3lMSu9fjr1aVLwjd9dRz5lipGyD3VZc49mMPlDTc7f6jpVLm&#10;xkolbUfI2hTwQbsI1izQ22MegNcCeB+Awzu10/Oz2fJzli3bvy6frzJzllWc2TV7rYv6uuUY5FoF&#10;ukaWtKnIZwO5lrQRONAAGKS6wSmwh8pddY8LYaZi6hribqzQKUyU8xXUlarR/yfrk+cgw4soEZuA&#10;j66u9YnHIehB+iaAAM6rFDTucZwZrtWqyU2iNz3C741+9qECD98ZitSyAVsD4lEWujDffwPc+ndJ&#10;kE9bl2hN9N6pAbwtzDujzsNpasGB1blqrERUbVGdf3MKeNSuijUL9NaMoKaffRCqM1NH7AzPqz5/&#10;2bL9x/b0lMHsMXMBRm/vpCIXDUDuTXfjRuVoofozXet10DBAPhMkONxOg10SsaNc78oVT0QSUDVq&#10;OnnOlRKRKtfK3Nd/72uoyxjuYc07SSJmZsFKwYcueTARI4Z88jocHnvy/6Yvsn7FXO+NINawRr2n&#10;IlThcUJaCGD9O2MoSpi/ADMpUQO+7vuZQB7dMFhV3jXqXDZQ52GDJal6MITqPCDAf6RUyvzCqnNr&#10;FugLas8C8BEAJ3dqh09yHP/Fy5aNPKm3V9WSM+cBeAj5cIBa8jpFHidc1XV+E43duHUgb6Z2OQS7&#10;0xjsxArmyhUvBAKAojp2ZvIVxClsIRuWAwVEFKj+8GCt5MOmNtozAA69BIgHxkD/P+mf5wq7xN9G&#10;YKf49oZNmBsgj/MIjBul6MZJiPimy4C2Ge6gEOIW5ItKndcSUA/inJBInTNR9ecjIytbUOffmgIe&#10;satizQI9nZ0G1RTmmZ3a4ZFCyIuWLh05ub+/6BK5YC4ws6sbwoQT0JJtWqeB3DVA7k7PXJ8GjVZA&#10;TnMEexhjZ+YQahwGuCUAV0rIULUbcNdgJz30JbqQsv4bvY9YrWtFDe2aV86DdI12E25t/fao34YK&#10;mhKTzMwmPHX98E3lHdeQh6qcwmD8TCA3jmPW999a59V56Fk6gDrP3lAu51LuPZhS1yJr1izQU9jr&#10;AXypU9fLFUT8l0uXjpzS1zeZE8JlIM/MLiuIx93dQve64aZ1E1nrBsSjeKwJE0LcUSzKwJ4DyOkA&#10;KmZOYDcUsNCqPYyRB0KoLHetzqWuVdduetP1DhmXuiGqb1PPFwfTDdUO7ZJPHvOBblDIyBwwEwTN&#10;unyRADgpqNM093nCpW7WjZteEg1y6FK3umOyqnzh1TljeuzcaHvMDWLnARNVf9baRLVvTQF/sqti&#10;La0d6teLHgB3ADh2PneSB/DKgYHRZwwOjvYK4ZhDOpBQ5GZL0LoRmjpD2jNi48lacicB8qT6mwnk&#10;zXwIeJYLYqhw9PdRHRrCi59xEWQT3gACKRHGzEM3ewCjU1f4vZEZJ+N9zfh1tg8+Nfg5Us/x90RG&#10;rJxidR4B2REivgGIt69T40BduMOCvBuBPkPdeTUIuMKMkpRcVnXnUs87Z4moFUN5c7lMb0tfdx4A&#10;eCKATXZVrFmFns6KAF4J4HdQDVvabhf39o6ev3Tp3kHXdSSQl3EZmgOlxkUIDtdQ5KYK10M6wv+f&#10;vZbcyFyfD2jQARR7pHWZSSt1ltp7wPpFhy50EbrQAUghwOFkN63OGWDT5a6VPoUXXpm8KBuAb+b1&#10;UOI9CuPlIbzr1HVChSduABpCvE6NJ26uWr3Bsjb/6jww1HlQr84lh2Xq7YmdW5hbs0Bv0f4A4P1o&#10;c2bp8/L54ecPDW05LJNxAqBPMuclkA1j5WAOvblR7NUFKMxW9xTI1fhMIFLkwuj2lmwKY0JnNpC3&#10;AxpzATuHClYDGDo2HsbaTbizAXcN8ShOLg1Yq9o0iv4vjJuzsU/MotLpAN8nVXSDm6Q6YDfqsEeJ&#10;fviN1sOCvNvoztG/0vAKhZUZvqHadTydjUYytcdKpcxPW4udf8gugjUL9PbYR6Cy3M9t9Ymelsns&#10;fcnQ0B+PKxTKAfOKAOjVNeUZZvYYUDAP24NqFegmQJ7RbVs9w7XumjPLMXsJ2nyBfDZAHkC1EwA0&#10;hLu+lHKsvusBr59DqiQ5SqoqxNs3uE5z4lCmvwPU4Oan7pFovNMQ/o0gPgc1bkHeZepcq+/AqDPX&#10;UwWTsfNInRNR7ecjIyvSHkse+HbJqnNrFuhtMwnVSOYutNgR7ql9ffcf39OzLWBezUBG6hnlHHZ6&#10;M4QehaVQoWtdu9oz8ffwVG252rhBnHyuCW+dgMYBVTuiJLoQ7jFuNeCh1Xv4W2lCWcM/Klkzga6B&#10;Os3tTjTjsdIMTXTQCN5IzBw3thX121s1fpCocz9RoubHpZaxOieqbS6XvetbUOcl4AN2EaxZoLfX&#10;HgPwVwB+0MqTfGp4+Owhz/NO7O2dMvp+ExsPSnQdE0QsYhVOLsBh7Dzs+Wr0a5/3OHm7wT7jcZhU&#10;VC54ZgPCespbEvJxyVojVU7U2nEnlHYjVT8XgFs1fpCocyCpzrlOnQO1nw8Pt6LOry7ZzHZrbTLH&#10;vgV1dj+AJwA4sZWLxe3F4uqn5PNjA54HqIx2D6qNqyCElUsa0GraVpj4FnZ8i5W54WZ3AJBOhjNh&#10;nnQRdws8Zjqm5O8jtUyGJdwZ0aCSsKY+8TD/ptmHI8T05wvzFJJlbIgPE0YGPM3xNVvrTnUeJmMG&#10;uu68pnq1o6qmqKEGcE0nxbGaqOYTUfWxctm5av/+wbTq3Af+AsCwXQhr7TBh34Jp9tdQpWypbYxZ&#10;XLFz55P3VKsZQLV/RpxAO60feVJhTgMe0bRJW6Yyn6s67Da4NwJ83QSUGJoR5B00mFuKqD96qkfd&#10;8xgP8zjqjmWW47YQX7zqnBuoc6P23IydB/qcrv18ZCQtzJEHvgsbO7dmgT6vVgLwUgB7W3mSLVI6&#10;n9m+/ehx32ciqhHgE1FAgKR4glg4VSweL1bf3rReR8wAysVmTcN9NrhONzTxmHFjmgO8aY6vy1p3&#10;q3M21Hld7FzVmkO3KWaOY+eSiGqPlcveT0olGzu3ZoHe5fYYgFdodZ3a7g4C7z937TqiImWNgEoI&#10;dSiXXQh1hLWtATOHPc4DKcOymaiBijQasegLC3iRv9F0ABBS8w9q4tH08zdz7NYOKnXO0qw7b12d&#10;fx/AA3ZVrLXTbAx9ZnsUqvHMBS3dGQSBO1IqFZ7c2zvuheVbYSw4BhAEwGSM4aS4JC2Kkwsi1fQ0&#10;zraedVLaYlfv1MTftfvRyrFZWzzqfLbYeVXHzn3dx10mY+fpgR7GzvfZhbBmgd45+x2AxwE4qZUn&#10;2RwE7liplH9SX9+4p724xsztOCFMTfiCAfx4UEjctISgoQ7Ul6wdLFCfK7gPhv1ZW3h1rt3sYb05&#10;qkAIdK6Fg1hide4TUeXavXuXbarVvJTq/Hs+8AW7KtYs0DtvNwD4cwCHtyT3FdRzJ/b1jbka1hHU&#10;iRqz1/h9EurhVDPEz4WZkuQOVhh1Splbs+rcVOdbymXn39Orc9lP9KoSsMcuhLV2m42hH9jKAF4G&#10;YHerT3RjpZL9+s6dK6rMFSKqEFBT4oClBGSgS2MSF5b4e2PqUzReNK6NrYupH6gFqjVrVp0fOHYe&#10;NIid/6KF2HkO+MEI8z12VaxZhb5wNgbgRqhEuWwrT/Sw77uT5XLuhN7ecU+oaLluphKp9Yb1bHF3&#10;k2hGKJkdT+JvF1U5mzVrXarO0UCd17aWy9SKOh8gekWpxQoaa9Ys0Fu3XQA2ALgYLXbYe9j33T1T&#10;U4UTenrGskIw4uqosI85JVQ1cT2063qFAyAY7VEPVRe8NWvNqPMDxM65Qey8/MO9e5c9mDJ2ngN+&#10;MAF81q6KNQv07rDNAO4FcBFaDFdsCQLnkcnJ3uMLhfEexwmQ7CiqoF5fk64HmBgXqlikU13AfVE2&#10;n7FmrdvV+adGRpamVed9RH9ZbkPozpo1C/T22YNQCS3Pa/WJdjOL+yYn+55UKEz0u24NzELDmhIt&#10;5cKfCXG/87jbaDiq1GA6G+NLrVq3ZtV5KnXOuitcO9T5f00CV9lVsWaB3n12u37vzm71iUaZ6XcT&#10;E31PzGanlnleBXH7ckxzxScvUvXzv+tc8IkseKvWrVl1vnDqnK06t2aB3t32SwCrAZzc6hOVAfrV&#10;5GTf0Z5XWZXJTGm+Kpd7DO14Vnj40FrdgHycVGckzM1VrVuwW7PqvLE6v7Y1dX7NJPAZuyrWLNC7&#10;2tb/BNh3FFqYzhaaBPDrYrFngJmOzOUm9ZQv4hjuEbTDi5P+PYeJdBRfyKIkOtYJcwmQm2regt2a&#10;VeezqPNtlQp9ani4ldj5K606t2aB3vW2jwH8EMBatNhNLrQ7yuVcsVLJHtvTM54hkmSwNVTaMz50&#10;wxk21DoSYA9/buSGt2C3ZtW5VefWLNAP9evHdQCGAJzWjif8k+97D01M9B5XKEz2Ok4NRiMzNrLf&#10;EY90DC9YkVo3Ds6sVW/khrdgt2bV+fyo8zB2vssuhDUL9MVl17cT6nuYxW0TE31PyGZLKzyvnLyD&#10;SCbIyQZqXWpFnoitA4mkOQt2a1adt1+dZ4EfTgKftqtizQJ98UK9H8AZ7XiyKYBumpzs7ZFSHJnL&#10;TTjJnu9EkGFJm24H20it19WwG2CfIb4+J7BbuFs72NX59kqFPtmCOu9XsXOrzq1ZoC9iuwGqk9wz&#10;2vWEd1Yq2R3FYuHoQmGyx3DBJ9XINLXOTDIEe31tu+l6j4APC3ZrVp2H6rzyo337lm606tyaBfoh&#10;b7/U15Jz2sW7rVI6t0xM9K3xvKoubYM5gjWh1iH1Aciw/A2AJIJkDuvaqe5GQMfX2QB7nSs+AXsL&#10;d2sHrToHajuqVfq4jZ1bs0C3pu03ADYCeD5a7P0eWhmg3xaLPdVKJfOEQmEiSxSYcE6qE61QOAK8&#10;zoCXCv7htClKxt5DsCdj7GgC7Bbu1ha7Or8/vTq/rgh8yq6KNQv0g8vuA3ALgBcCyLfrSR+o1bwH&#10;Jyb61mSzpSHVXY6pXm3HLWOZSQJkuuE56YZvDPZwe9VvNpzFHsN6mjvewt3awaLOr2xdne+0C2HN&#10;Av3gs80A/puA5wBY1q4n3cssfjE52RfUat66bHYiK0RQV7OeBLRWKgGmJ87JGcCOWKETxxnzSdWu&#10;eN0E3C3grR3E6vxHReCTdlWsWaAfvDYC4DsEPA2qCU3b7P5qNXPHxET/KtetHpbJFENe6gsbN2pG&#10;E2jXe1AP8gjschbFDsTueG7sem8a7hby1g4SdY5eoldXgO12IaxZoB/cVgLwHQBHAzihnU88zky/&#10;LhZ7Jsvl3LpcbrLgOH4IyGlueA3r8IIXqvZQsWvXPJkKZzZ3PBLPTzPAnVPC20LeWofV+eD9tVqm&#10;BXV+pV0Vaxboh4b5AK6Bmqj29Hbz6k++7906MdE/KIR/WCZTdFTrWPPiR6ZijzLhY8Ue/qyUi86K&#10;5xj+jcGOODu+wRS4OQE+LbzbDXxucXt7A7J41flOpc7ThsW4j+hVZWCHXQhrFuiHlqj4JYCbAfw5&#10;gN42uwFoQ6lU2Dgx0bfMdasrPW8qLDVPKBpOgj0wFTtz9LPUT2CqejYT7WaAe6jcw/3SLIA/GCFp&#10;4X5IqfMfF4GP21WxZoF+aNqjAL5LqqvcEe1+8r3M4tfFYs/eUim/MpMpDbru9Gz4BNjZiKGb6j3Q&#10;rnjjd2a9OzUYElOfM9SJUQAAIABJREFUQZ9Q77MAfs6Qbzc4uY3vvW2Xe8ipc/QSXWJj59Ys0A9t&#10;GwfwTQBLAJw+HzvYHATuDRMTfY7vO4dnMsW86jTHiHvD1YM9TJBTECfjAlmn0CVAdb9LwF3Ww70u&#10;oW4mwPOBYdgQ9q3CmOfyJzzDXyVG0pIF+6Gozn9SBD5mV8WaBbq1AKoH/B+hStty87GTe6rV7HXj&#10;4wPC953DMpmiTpwLwc5G8hybrvQocY6ZAxjueICNWDuZrvoQ7tIAeyPARypf30TQDJDneVbnzcB9&#10;tmOaKYxAFupdrc531Wr42L59Vp1bs0C31jZ7AMAPCTgLwGHztZN7q9XM9ePjA9kgoBWeN1XQip1i&#10;lc4h2JNT3KTpeg9Ve+iSZ+ZAwz2ovxEIvxInAC8xbcZ7nF2fUPLA9IS72WbDzwZOeYBtzZsZnuPf&#10;wngdM7XLJQv17lXn1WoqdZ4Brp8CrrCrYs0C3VrS9gH4T32NOnO+1kcCuKtSyf5kfHwgEwS0PJMp&#10;FYSoarBLjnUPIwZ9DGOjlWwwE9y1Yte/p4R6R6A62MWJd4lHIhufzIu2CXyeQVnPCt8Gf5d87iTM&#10;jWPjANNG1tIMXgYLdavOrVnrmNnrSvfaiQR8jYGTOrGz5+XzpWcsWTJ6VD5fAeBB9Z93WN1UOFpx&#10;CiIiAkgAJIhA+qvQ/+mor3CM3ztEFH4lInYAIvU36kkBkPFcpH8WiQ9p9PP0NrR1n+W5fKi5ERYa&#10;/J950zCTCeN49Ouh8Pj1Vwr74pOFenvVuQI0h1UZWomjIiWXmVEOAlmWkivq91InePpgrhJR6bu7&#10;dy/9/uRkT0p1/tOqCpNZs2YVurVZbbdW60UAZ8/3Wm3yfe/nk5N9j05M9OSF8Ic8b8ohCgiQVB9r&#10;ZwCQRqxdxol0kZs9MC6y0fcA65/rYvI+QMbvYWynvqoxsFFiXlLVBwl1HzRQ/HP5+yDx8MNjCL/X&#10;YQXzkUwShO7OFzI7cv8TkTl33kJ94dX57loNV7SgzgtEr60CW+xCWLMK3VozdjoBX2XguE7t8HFC&#10;yBcsWTJ6Yk/PxDLPY56u2gVpcQ1DtZNGl6m2Q/Uu4u9hKHyl1NX/s3IBEBHAobKlWMFPf9QDklIo&#10;9LpsfxiudvPv5Awnj3kcocfBEYKUW0O9ztBroV9j3WuxJ+HCqfPv7d699Hvp1fkNVdVHwpo1C3Rr&#10;TVsOwGUEvJWBTCd3fEEuVz5jYGD86Hx+KieEgIK7o+EecrrOJU8hjEOIxaCvc0Ub34c/ExGx8XdE&#10;IRBjtRslngnzw5xQv3MCuuFSl0nAm3Bn5kbd70zXuga4cDXc3RjsEeAt1NsEdLU2yssjJXwggnlF&#10;SpSl5BDmVSmlrzxCATPXCKjsqdWCN27dujrtsfQTPW2c+Va7KtYs0K21YkcL4FMSeG6nd5wH8MK+&#10;vsmn9PZOrMvlyg6RG6p2/RAccjgGPJAAfAhjA9SxIjeVeAjLGZS6QMKdrX4+UNt4s2seIQHsZPKc&#10;oQanhdLNG5QoV4AILhHpBzz91U1A3am/MbEn4/yqcw6YZRvV+c+qwAV2VaxZoFtrl72QgE8w8PiF&#10;2PmxjhM8o69vYn2hMLUmm626Sng2hDtMyMcAj0q7kpCn+r/h8JagzgU/HYjUDBgTSXCcUH6mYg9/&#10;5kYnT3h8YeKfq5S68IjgCUEeQB4ReUJYqB886vysceZb7KpYs0C31k7LAPhbAj7Abe4J34z1EfH5&#10;hcLUn/X2Tj4+lyvlHYc03EPIk467UwLw6jMYA5wMUNKMwDZc7qEiNwHfFCTqS9+I6wU78XRVz8Yx&#10;hsfCYU6AQ0RuCHEFcspqxZ7RUHe1Z8IJb2SM47Yn5Pyr8+/v3r30u+nV+c+rwLPtqlizQLc2X7ZW&#10;AFdK4KKFPhAXwHMLhan1hcLUEdlsZWUm4zuKW44GeTLuTonvTTe6WYpWl/BmAn+uH2RC4w5viaQ4&#10;blDbPq2qTe+PzTBC6HYPXe4eEWWIREZD3TOg7mig23h6x9W5/8atW9e0cPP69Anmm+2qWLNAtzbf&#10;dqYALpfAed1yQINEfE6hMHVMPl9ak82WV2YyNUeXpYcMhHLPJ8E+rfy87gNbHzev/68mQYHpme51&#10;PWIawJxNn0HkLVCAJodIaKCLDBFlFcgpKwRlhKAMEVz1d5HrnRK17NbaqM6ZfQBVIir9YM+ewasn&#10;JlJ5szLAjVXgWXZVrFmgW+ukPU0A7+8msBsKh5+azVbWKvVeW+l51RWZTC0jBAzIR3BPgD5injmd&#10;jVr7PHNSiSfc7EyJPLm6xLs46U8JdEA4RCKEeiaEuhCUE0JkiZARgkLXuyMEksmA9sRsjzqvqTK1&#10;SJ3vq9X8v25NnZ89wfwbuyrWutVc+xYclHaLVEriWR7w/ppqI9sVNsFMPy+XcyiXc+aH8OnZbOWo&#10;XK40lMn4S1y3NuA4tX7XDXJCSCRK40zuUULUallNDVR4ckhKBHKKwW4q8Omt3QGUgkAUg8ApSulO&#10;BoE7HgTumO97+2s1Z1et5r5l9eqxrBDhfh2dNEeCGQ4zO/p7AtghIlb979lhprAfvIX5DOocRote&#10;oK7Bjw/VPCZ86Pa8HI0fIKr9anR0MO2xZICbLMytWYVurRvsOS7wfh84dbEd+OOEkOszmephmUx1&#10;0PP8ghBBwXFkQYgg7zgyJ0SQEyLIEnFYq65BIGaZiBb1idFuW1GW0ikHgShK6ZSkFKUgcIpBIEZ9&#10;//+3d+dBctz13cc/v5nZQ7s6HVMG6zExDvFBqFSIk6rnoXJUxThAkVBUJamkYgIkRQJVOUgqz5OQ&#10;qjyPsbmJE8hJHBIO4xOwwcYpI9+WbMsGy9ZhST50y7JkXXvNzuxMd/9+zx/dPdOzWq12fz27OzP7&#10;flUtKmS3tO5p+6NP//r37dJIGJaO1ut9W8OwLzjH9/vF9evHLh4ctEYqFo0plpoNvTBojBksFhst&#10;vS/dzpY+wU9LX7B2fiIIwo/QzkFDRw+4L4xf0Xr1gPTntXjCVaEbvvGD1hYOTmv0sznfGHdBoRBJ&#10;0nnFYpRW+nTM60gUFSXpVWuLI861PTP3VavFiwcH68kLWwqR5EJjTNE5hcYodM6V0pe5GNPcJmeM&#10;U9LS0f52vjFHO++THiHMQaCj0zxQkx6Q9BMl6Q8j6SNOWttL/4AnnTMnoyi+rtMfF9EzExODv7Ju&#10;3biTClYqGOdMEjoudE6htQqLRVOKH9gy2Ql4xUyQEevZdHeN/01ntttmiCu01oXNN/45G+9UsJIi&#10;IwUng8Dc4vkgnCQNGHN94ByfAzpegVOwLO0NpY876Y390keL8bvY0Qabg6A0FoZOzkUuefd2MkNc&#10;019MY5tNMm2jbqaWSjvP0c6l4LGREe8/tPZJj5ade5QrGwQ6Ot1EXboxkn5K0vv6pQc183tIMA+H&#10;p6b6JUVyzqbrv9k3taVvB0u3XknpTjlNe5ErcrfzMMzbzq/jQwCBjm5iJd1dl66WdFGf9Bd90rOc&#10;Fj97qtVBSZGLn4xPW7qi+La7C611SQA126daXw5DO29PO9+Yr50/RjsHgY5u9mogfSmQrpT01jXG&#10;XF+UDnBa5m5juTxsXZrZLn2PfPbd6S1tc9pt9xkDjnY+t3ZuM+38dBjqDto5CHRAkrRzzLlrI13+&#10;5mHpnSukbxpphNMyu/3WFo6HYVFKsiYNnDSY0nBKbrtnp6At6/xuQztXdu18dHRt4Pm99Ekby849&#10;wtUMAh095oVoUrq/Kn3A6fLXrTXm59cYc31yW55F3xkcirfZRUpuAWdaZvpgXNosG6GuJIlYR29P&#10;O799fHwV7RwEOjBLuI8698yYc9cmt+XfdL4xHx2UvmOkMucntmtyctgkDT1pnc6mX0mI23Quefw3&#10;OTstzmZ4SQztfHHa+RNl5x7mKgaBjuXm4EnnbpySfstJF6w35tdXG/P5fmmTkSrL9aQ8UKmsmLLW&#10;qXnbPbuOnm5lc+m6evaW+7Lv5/Nr58q0c2uk4FQY6pt52rn0Cf61RjdisAzaqXLEuXsl3ZteX28p&#10;Fq84bu3bq879Qk362VB6y3I4EVVJR+v1/osHB6M0r61zzhljbDy/XemPmWlxcaibZNL8Mpkal7Od&#10;u0w7jyQFm0ZH8zzZ/mQ53r4JEOhARrgrinZI2iHpRkl6gzEXSfpfFemnAueuqEuXR9KlThrotX/4&#10;vdXqiosHB8tKn3Y3xlnnXJSEetLSTZQGvJpjaotJpEvLbGrcHNt5OEs7vy1HO++XPhHw7y0IdODc&#10;jjp3WNLh7M+9b/jS0r6pvZecsvaKinRF4NzlNemKSLrISq/v1kzbUi4Pv2PdujGXFs60fcahLtuc&#10;6e5s/KpY587y1rVefQubbzuPztLOH8+5dj4Zj0YGCHTAx/cmXwolvZR83Z39a7/Q3z9QsXb9iLX/&#10;o+rc+kB6XSidHzp3fiS9zkrrrLRS0rCThqyUvoSj30nD2V/LSBOSQiPVkvV9V5DGJNmidLIknSga&#10;c7JPOtEnHe835uSgMSdqzq07YO298/3nejoI+kbD0KwplZq33eMvk92+Fjlnpr+rdVlqQzu/NV87&#10;v552DgIdWCCP1+s1SfuSr1lNXHmld4l9qVptOXYsDBv//7V63Vxz4MBRK71hvr/u4VptMAn0dMhM&#10;/BpQY0y6L92l6+mSXLJ+7oyR6fF19A5r55snpfv5Nw4EOtABVm3Zkqfcthy75S1vKaTBfkF/v1sh&#10;PTwpXTPfX/TlSmXFW4eHR9W87R439KSZZ/ajO2eMmdbSW9bRe/W2ezva+ekw1C352vl1tHN0O7at&#10;ATO4ctcue+WuXXZNqeQkaY0xXk8+b5qcHE5fruYy6+gu3YOevLSlMRI22cp2xp8waOfnbOehf6t5&#10;alLawFUPAh3o8WBfUyq5y/r6HvDJ2IPWFl4Lgr40r5MH3xpjYLMhbp1r7kVfTtPicrRzJe385nz7&#10;zpkKBwIdWC6hfsOb33y0JD3vc/zBqakBSaHiVtnyopYofY1q5ud6fQxs3nZuM+3cSMHjY2N52/kP&#10;uMpBoAPLyEpjvB6a2pmMgTXJK1VtupaeberJLXin1jGwrtfHwHq0c5dp56NR5O4YG8vTzq/nygaB&#10;Diyzlr7KGK89yhuq1RXVeAysNc3ta0oWgM86BrYXb7q3vZ2Pjq6t+rfzLbRzEOjAMvSOlSs3mXiq&#10;67yEkl6t1QaUvn2tuY7eCPFGmGfW0TX9R9p5azsPQ3fb2Nhq39++X/p/YnQ+CHRg+fna+HhlQHrc&#10;59h9zdep2nQd3TVf1KKkgSr7xHvaXjXttjvtvLl27tvO+6RnK9J9XNUg0IFlaoXnbfcfTkxkX6fq&#10;pr99LRNsLglzd7a3r/VEpVzidt4nXUs7B4EOLGMXFApegb4lDPtG4ulzjdvu2YfiMmNgWxpsr2xf&#10;a2c7lxQ8ka+dP1eR/purGQQ6sIy9EEXbCtJRn2MP12oz3nZPa7tNwq2xJz0bhr20jp6znY+FobuV&#10;dg4Q6EDeOBryfF/2S5XKCk277Z7cbnfZhmqbM9+z+9K7dvtaB7bze7mMQaAD0LDnOvpj5fKwPdcY&#10;WLVOkHO9NgZ26dv5J2jnINABSJL640Cfdygcca5wvF7vS1v6Gevoag6V6ZUxsO1u50+Oj6/J0c63&#10;VqTvcwWDQAcgSTps7bE+abvPsQeSdXSTjIFVtpH3+hjYfO08HAtDd8vo6Brf375EOweBDmC6Qf8x&#10;sEPJ9rWWMbCNRtpDY2Db3M7rm3O286p0D1cuCHQALdZ5rqPff5YxsGnY9ewY2JztfDwM3c352vl1&#10;tHMQ6ADOcMjajUaanO9xoaQj9XpzDGzCxl9njIG1XToGtsPa+baqdDdXLQh0ADOpeY+BrVbT/ejN&#10;2e5x4J0xBja7da1rx8DmbOcTUWTzTIWjnYNABzCrIf8xsCuTdXSnZpj3zBjYdrfzJ8fG1k44ZzzD&#10;fCftHAQ6gFn5joF9NgxLI2FY0JlvX+u9MbD523k7ZrZbrlYQ6ADOancUbS9Ir/gce6j5OtVZx8BG&#10;1nbVGNi2r52Pja3J0c53VaXvcqWCQAdwToPSQz7HvVSpDGkOY2AzW9Vc142BbUM7/xbtHCDQgcWw&#10;ynMdfWO5PBS1joF15xgDq04fA9vuqXCbx8ZWj+Rr53dxhYJABzAnK+IBM/NugUecK7zWOgZW8xoD&#10;2+nr6T7tPPnHlxSWo8h+a2ws71Q42jkIdABzc8DaE33SNp9jD04bA+uyYX6uMbAdVtTb0s6T2TqS&#10;gs3j47na+ZR0J1cnCHQAPi193p4vl4ezY2DTW+92bmNg1bHr6G1o53fknwpHOweBDmB+fMfAPjg1&#10;NZiOgVUXj4Ftdzt/Kn87/w5XJQh0APN20NpNRirP97hQ0pHm9rVZx8Cmbb1l21onrqO3oZ3fnq+d&#10;X087B4EOwFd9QNrkc+DeanWF4nX0WcfA2mlDZjplDGy72/nT+dr57inp21yOINABePMdA/tUuTyc&#10;lPXuHwPbhnZ+W752/knaOQh0ALm83nMM7LYwLI0EQVFzGAPb0tI74HZ7B7bzO7gSQaADyGVXFD1f&#10;lA77HDuXMbBnrKOrw8bA5mznk/nb+ado5yDQAbTFgPSgz3FzGQNrp912X+oxsAvQzlf5tvOi9PKU&#10;Lqedg0DnFADtsdpzHf3hycnhKH0FevbBuBnGwGaDczEDfCHbeSWKom+Pjq71/e37pOukFyKuQBDo&#10;ANpiRRzo877te9w5c6xe71d6hz0OvtbJcR00BnYh9p0fz9fOb+fqAwh0oG32W3uyT3rO59iDU1MD&#10;yoyBlVrHwEbWduYY2CVu5/G+c9o5QKAD7W/pXmNgd0xODpt4+1rkJGunj4FthvmSjoFt+9r5xESu&#10;dl6TaOcAgQ60n+8Y2PunpgYno8joLGNgW+a7q0PGwLahnX9rZCRPO/+k4j8EASDQgfY6aO0TPmNg&#10;JenVeB39rGNg3RKPgW13O/9hvna+pybdxhUHEOjAQqkPSI/5HNhVY2Db0M7voJ0DBDrQyXzHwD59&#10;rjGwyRPuSzEGtt3t/Ef52vnemnQrVxpAoAML6sIcY2BPzzYGNv4LSz8Gtg3t/PZ87fxTtHOAQAcW&#10;3PNRtKsoHfA5thPHwC5AO1+Vs53fzFUGEOjAohiQHvI57sVOHwPbjn3nIyPrcrTzT9POAQIdWDS+&#10;Y2AfjcfAWnXIGNh2t/NnJiZWHc3Xzr/J1QUQ6MCiGY4Dfd4TzI47Z44FQZ86cQxse/ad52nnn6Gd&#10;AwQ6sKj2Wnu6T3rW59gD1eqgZhgDm107X4wxsB3Wzg/SzgECHVgS3mNgy+WhmcbApkGZrqMv6hhY&#10;n3ae3GWQFE5ZG96Vb2b7JyUFXFUAgQ4suvOM8Xo/+gO12pKPgW1LO0+eBVCy7/ywtV7/vaGdAwQ6&#10;sKQOWPu4kcZ9jj2SHQPb3I++NGNg29DO78y/77zOFQUQ6MBSCQc9x8DuicfAhkaKkv3oLgnxBR8D&#10;2+52/kz+dn4TlxJAoANLynsM7MTEcNrQtZRjYNvQzr+To50X433ntHOAQAeWlu8Y2B1RVDqVGQOr&#10;RRoD22Ht/FBd+gZXEUCgA0tuRxS9UJT2+xx7qFYbTIIx3tKthR0D6zqvnX+Gdg4Q6EDHGJC8nnZ/&#10;sVIZMjONgY0b8YKNgW1TO69vyd/Ov8bVAxDoQMdY47mO/sjk5FAw0xhYqe1jYBegnUd35mvnn6Wd&#10;AwQ60FGG4/3o8x4De9I5c6xez46BdQs9Brad7fygfzs/XJe+ypUDEOhAR9lj7Ui/9IzPsQemprJj&#10;YKVsmDunyNpZx8DO5bY77Rwg0AHMke8Y2O3l8nA6BlaZMbC22YzPHAOb47Z7O9r5sxMTq2jnAIEO&#10;9CTfMbAP1WoD5WQMrJvrGNh5tPF2t/OatdF3crxRrSh9TlKNKwYg0IGOtN/aJ4005nPsjGNg469c&#10;Y2DdArTzLeVy3nb+X1wtAIEOdLJwUHrU58A9lcqZY2Dj4PUaA3vWBp+zndetjb53+nSedv552jlA&#10;oAMdz3cM7OZyeaXmMAbWzmEM7Nmaejumwm0pl1ft9WznBekoa+cAgQ50hfWeY2B3RVHxZBCUdI4x&#10;sPZsY2Dncts9fzsPv5ujnZfiqXBVrhKAQAc63vYoeqko7fM59lCtNiCPMbBzeftaO9r5s/nbOWvn&#10;AIEOdI9Byaulvzg56TUGVnMI8na087vytfPP0c4BAh3oKqs919EfqlTmMgbWzTQGdnqITw/5xh8C&#10;kpa/BO38K1wZAIEOdFegFwoPSgrme9zI3MbAmsbT7meOgXVuplDPPDxnMw/WzdrOk+V7NdfO80yF&#10;+zztHCDQga7zYhSN+Y6B3X+OMbA286BcmriZ7Wtna+rzb+fxLxlJCp4rl1fusbbo+R+fY4H0H1wV&#10;AIEOdKUVnrfdt2XGwLoZxsCm6+i2+RBc6/a19GG6Rqo3H67zbed35d93TjsHCHSgO/2Y7+tUM2Ng&#10;NX0MbBK4M46BbV1Lj386E+6Nyk07Bwh0AHO3z1662UgjPse+0ty+1hwDmwR79q1rM21fa6yZT9ur&#10;vkTt/AuSKlwNAIEOdLEXIu8xsNXqmWNgMxPjouaa+hnb16TWsa952vnW/O38Rq4DgEAHut6w/xjY&#10;4UzhPmMMrMu+tEWZYTHJzynb2D3beWBtcGe+dv53tHOAQAd6whuLxQ0+x+2Ox8AWNcMY2Ki5fa05&#10;BjZz2z0N8pZ1d592Pjm5Kkc7fy2Q/p0rACDQgZ7wbBjuK0p7fI49NDU14xjYNJxb1tGV3HbPBHv2&#10;7593O3cuuDtfO7+Bdg4Q6EBP8R0D+0KlctYxsNnGbTO35NMQb9x+T8bEtrRz5xSce+181e4o8m3n&#10;J2nnAIEO9Jw1nuvo91cqQ3VrZxwDGzWDvfGQXHrb3baGeRr6zVaezIUPm02/3e38C5LKfPIAgQ70&#10;VqAXCg/JYwzshHPmWBD0a9oY2PRBtygT1pmG3tLWI8lFcZin6+Yt7dzO0M63lcsrc7bzL/OpAwQ6&#10;0HN2R9F4v/RDn2P3V6uDJh4D23h4vWUdPWnkUeY2fLqFrWWLW7J2HjTbuZupnYfOBd87ffq8HO38&#10;72jnAIEO9CzfMbDPxtvXkmfXnE3X0dN2HVnromaoZ59md1GmxaftPPNke/qgXPqK1Ma+85zt/N/4&#10;tAECHehZ53sG+qZ6vb9sbWMMbMs6ejbA1bxvnn5FmXDPhPms7fzufO38Bto5QKADPW2vvfTpgnTa&#10;59jDU1P9mjYG1rWGeXxr3VqXvpUtbe3pg3CBcy5dOw+ntXOTWTvf5d/OT9HOAQIdWAZeiPqlR3yO&#10;3FOtDqVvX1OzobvsK1XTEA/T/enJ9rRI8dN4YWbbWmPfebPMt2Pt/AZJE3zOAIEO9LyVnrfdn5iY&#10;GLZxk55+2z1+peq0sA6bXy5Ib7XHTd0lT727ZHxsy5PtOdv5v/IJAwQ6sCyUJK8xsC9ZWzyVjoFN&#10;HoxL95knrdylD8GlT7EHzT3n2WBX2LhhH7dz0552/ve0c4BAB5aNY84dKEov+Rx7sDkGNn0/umts&#10;WUv+QjooJoibeDPMrY33ozdf6JJt5/Xt+dv5v/DpAgQ6sKz4joHdXakMGWPiMbDNue4ue5s9ytxu&#10;D6xVEId74+fSF7pMa+dhzqlwX6SdAwQ6sOys9VxHfzAdA2tM5JI96Y1pcK0z2tMfTdCcCpfuS288&#10;JZ+082D75OTK56Oo5PkfldOB9E98qgCBDiw7qwuFR+Q5BvZovd6veGqck5oT4tLb60mYm7q1Jmxu&#10;UzOZQTLKhHkYScH3c7TzAu0cINCB5Wp3FI33SZt9jt2XjIF1yVx3TX8laqaRZ263u2SN3SWT5mzy&#10;h4Jge7k8vD0Mvdq5kUZD1s4BAh1YzoaNedDnuOfK5ZVKxsCqOa+9sYYeNL9cy9p588l2JykyxoSR&#10;FNyb78n2f5A0yqcJEOjAsuU7Bvbxer1/PAyNMi09ecrdRK37z7Nr5403rykzs31HuTy8NV87/2c+&#10;SYBAB5a1/7ly5Y8K0kmfY1+p1QaSUa2NITMzvFGtORku+eu2GeZh5Fzw/Xzt/Iu0c4BAB5a9m8fH&#10;vcfAvlypDCkzAtZJppHU8QNwaZibdN+5y7we3RiTt52PhTzZDhDoAGKrPG+7P1our1z3/g8Wsw3d&#10;JcEdZYbMRM3b7Y2187Sd35OjnV9yydtvp50DBDqAREn6gc9xB60tjFx4yZrG0+7xw24m+4CczQZ5&#10;c8xrZKTg+XJ5aJt/O69vevy7w3x6AIEOIHHdRRe9UpJe8Dl289/+xZSkyMTjW11jtruar09z6Zcx&#10;zjhnjRQk+85/zPd7Lkr/eOGFF/wenx5AoANI/NGhQ853DOzLlcqK6Q/GJW1cLv1KMz3zRrUd5fLQ&#10;c/nWzj/LJwcQ6ACmWeO5jv5wtbqi7pyVMc0dacbINdfL0y9rkgfhkn3nedr5lySN8KkBBDqAac7L&#10;MQb21Vqt38Tr4s077MYo+WoEuoyJjBTsnJzM087HQ+kf+cQAAh3ADHZEUbkkvexz7P54DGyYtHAr&#10;yRnnnHHOJrfZbRL4wXkf+ePiPadO0c4BAh3AQnn3r310h89xPyqXVxopMMaERooKkjXGWGOMM8Y0&#10;wtxItcf2j6zZSjsHCHQAC+dd7/6lrT7HPR0EfRNRpCTUoyTAG18FKSwYE7zt1tvXfvU/PjOQo53/&#10;k6TTfFIAgQ5gFh/+8G/sM9KUz7GHp6b6ClK9EDfxsBHkcZjXjDR18033Fg9b6/Xvv5HKtHOAQAcw&#10;BwMDA9+6+lf/4FWfY1+uVocKxkwVpVrRmHrRmHoh/rFWkGrrP/63pW/f+Ol+3+/NxWF+kk8JINAB&#10;zMEv/uLPHfE5bmO5vFrOlQvGVIrGVIvGTBWNmUr+f3nD//2baGcUlTy/rYpo5wCBDmDufvM33/mK&#10;z3EHrC2eCENTMma8aEy5JJWLUrlkzISkiXtPnbogx7d1q6QTfDoAgQ5gjq644id+V9Jun2P3VSor&#10;SsaM9EmjJWMVA01/AAAD6UlEQVRGSsaMlKTT28rlVc+E4aDntxTcc89Dt/HJAAQ6gHm39D+r+By3&#10;YXT0x0vGnCwWCidKhcKpkjEnL7/plgu/duLET/p+L7//+3+z673vvephPhWAQAcwT+9+9y+d8jlu&#10;exgOXfSNW9/WZ8zxkvRayZjXbr79B2sOWNvn+a2E1177J8/ziQAA4GFkZPzriie/ufl+ffnT/7Z3&#10;42WXXf/YZZd9+ujuF7e+wZi6z68jyX3oQx/fyqcB0NABeFq3bvWHLrnk7a/5HPvE5q3DBWOOFaTX&#10;vvKVO9ccdS5HO//jnXwaAADk8LGPfepHPq36fGOmnrj88t86sf/go68zZsq3nX/wgx/fxqcAAEBO&#10;GzZs+q5vGD9+/6aNn/jfn9vpe7ykYP/+w7fwKQAAkFMURf+peKDLvAP5//zp9TvXGuN1rCT3gQ/8&#10;1XY+AQAA2uRd7/rwHp9ALnk+UJd8VWjnQPfgoTigC/iOgQ2lou/v2de3+s43vemiazj7AAC0ycsv&#10;H7glR9P2+Zq8664NV3PmAQBov9OLGOg3cLoBAFgA73//X+5YpDCvSrqQMw50F9bQgS5x1VVvP7JI&#10;v9WNkl7ljAMAsADGxspfU76n1ufyFUp6I2cbAIAF9Na3Xn1kIQP9ne/8gwc5ywAALLD3vvcj31zA&#10;QK/RzgEAWBw/s4CB/kVOLwAAi8MofmBtIZ5sX8/pBboXT7kD3cVJemgBft2vSDrC6QUAYPF8QDzZ&#10;DgBA13u9JNuuQP/t3/7YTk4pAABLY1ubAr2+a9ee2zidAAAsgfXrf+a2dgT6e97zh09xNgEAWCI3&#10;3XTXfW0I9JB2DgDAEjp27MTvKB4E4x3ob3vbe+7jTAIAsPQ2KN9UuB/nFAK9g33oQPd6IMex/ynp&#10;IKcQAICl99Oe7bxOOwcAoHP4joH9MqcOAIDO8g2Pdn4xpw3oPayhA91tvuvoX5V0gNMGAEBnuUBz&#10;HwNbl/QmThkAAJ3puTkG+o2cKqB3ccsd6H73z+HvCb/whf+6k1MFAEDnese52vkv//I1T3KaAADo&#10;YGNjE9dJmpwl0KMnn3zuS5wpAAA630OzBPr3OD0AAHSHv9bZn2x/M6cHAIDucLYxsN/g1AAA0F2O&#10;TwvzUNJPcloAAOgut08L9K9ySgAA6D7XZMI8knQppwQAgO5zfhLk7qqrfm8rpwMAgO61RVL01FPP&#10;fZtTAQBA9/qspK9zGoDlp8gpAHpKXdJ9kk5zKgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&#10;AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgB/1/yTz7dpEdwj8A&#10;AAAASUVORK5CYII=&#10;"
											id="image1" />
									</g>
								</svg>`,
						iconSize: L.point( 36, 36 ),
						id: 'gym'+guid.replace( '.', '' )
					}
				} );
			}


			if ( !star )
				return;

			window.registerMarkerForOMS( star );
			star.on( 'spiderfiedclick', function() {
				// don't try to render fake portals
				if ( guid.indexOf( '.' )>-1 ) {
					renderPortalDetails( guid );
				}
			} );

			if ( type==='pokestops' ) {
				stopLayers[ guid ]=star;
				star.addTo( stopLayerGroup );
			}
			if ( type==='gyms' ) {
				gymLayers[ guid ]=star;
				star.addTo( gymLayerGroup );
			}
		};

		thisPlugin.setupCSS=function() {
			$( '<style>' ).prop( 'type', 'text/css' ).html( `
	#sidebar #portaldetails h3.title{
		width:auto;
	}
	.pogoStop span,
	.pogoGym span {
		display:inline-block;
		float:left;
		margin:3px 1px 0 4px;
		width:16px;
		height:15px;
		overflow:hidden;
		background-repeat:no-repeat;
	}
	.pogoStop span, .pogoStop.favorite:focus span,
	.pogoGym span, .pogoGym.favorite:focus span {
		background-position:left top;
	}
	.pogoStop:focus span, .pogoStop.favorite span,
	.pogoGym:focus span, .pogoGym.favorite span {
		background-position:right top;
	}

	/**********************************************
		DIALOG BOX
	**********************************************/

	/*---- Options panel -----*/
	#pogoSetbox a{
		display:block;
		color:#ffce00;
		border:1px solid #ffce00;
		padding:3px 0;
		margin:10px auto;
		width:80%;
		text-align:center;
		background:rgba(8,48,78,.9);
	}
	#pogoSetbox a.disabled,
	#pogoSetbox a.disabled:hover{
		color:#666;
		border-color:#666;
		text-decoration:none;
	}

	#pogoSetbox{
		text-align:center;
	}
	.pogoStop span {
		background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAPCAMAAACyXj0lAAACZFBMVEUAAAD///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAABAQECAAAAAAAGAQEAAAAPDw8AAAAMAgIAAAALAQEBAQETAwMAAAAGBQUMAgISEhIAAAAWFhYBAQEWAwMAAAACAgIDAwMFBQUGBgYJCQkPDw8REREVGBgWFhYXFxchISEiIiIkICAoKCgpICAtLCwtLi4uBQUuKysuLy8vEBAvMjEyMDAzMzM0NDQ4ODg5OTk6Ojo+Pj5AQUFBS0tCSEhDQ0NISEhJSUlMTExSUlJUVFRWVlZXV1dYCwtZCwtaWlpcXFxeXl5gYGBhBgZiYmJjY2NlDAxmDAxnZ2doaGhra2tsbGxtbW1wcHBwfHtxcXFycnJ0dHR1dXV2dnZ4CQl5eXl9fX2CgoKEhISFhYWGhoaIiIiIiomJh4qKioqLi4uMjIyNjY2PiZCQkJCUlJSXBASaERGanJycBAScnJytFRWuDg6urq6wFBS2wcG3t7e4FRW5t7q6Cwu6urq7Dg6+vr7CwsLDwMTEDg7FxcXHxsfIyMjJFxfKDw/MDg7MzMzPz8/P0NDQ0NDRDw/RFxfS09XX19faGBja2trbExPc3NzlGhrl5eXo6Ojs7u7u7u7vGxvwGhrw8PDyGhry8vLz8/P0Ghr3Gxv39/f4+Pj8/Pz8/v79/f3+////HBz/HR3/Hh7///9j6e8DAAAAPnRSTlMAAAIKDBIWGBshJTI0O0tQY2VocnN1fImVnZ6lqKmrrLCxs7u8vb3G0tbW1tra39/i4uXl7Ozv7+/v8fH6+jTKPt8AAAGeSURBVHgBYwACZiFlAxMdWT4Qm5ERImBoqgsUgAAeDfe8hsbaZEd5VpACkED6rK27Nk4IAAoAAbdZVldXd3dXV5OXOgtIAbfFlFMnT5w4eXJ3IVCAgVkzGywNJJo9JIAKmLWnnwJJA9XszZBgYBD0AEp1F2fWd3W3VtpwMTIKZgDlT8yZtPnUiYPrbLkYVEuBuj3t7OxyurpbPEUYGdWWnTp5MjeuwnfqqRMHCkQYjIoqK9Psqu2jHapqyiKlGRmN5y1f3h+7vn1G8Iq1i+qkGczsgMDewS7JDgSUGBnN/fyD3Np67BaG+IUGeisx6M0/fbrELjXK0e7QsfkukoyM+jtOn17ts2R2d8zR4zsmSjIoRJ8+fdoVqLn59LYFdgKMjApzgQKTw+KjN50+vDNPgIHf7jQQLO0EEqvyzdgYGfkTQAJ7tgCJfSst2RiYVJxPQ8E0O2FgODCp9MEEticKA0OSQ9NhP5jbYCcFDmoOrY4jYIENSVLguGCXs3NKKY2wsxIDRxZIILx38ZqZ5dZAAQjgFVdUlhHlhMQmmgAAN4GpuWb98MUAAAAASUVORK5CYII=);
	}
	.pogoGym span {
		background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAPCAMAAACyXj0lAAAC7lBMVEUAAAD///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQEAAAAAAAAAAAAAAAAAAAABAQEAAAABAQEBAQEAAAAAAAAAAAAAAAAAAAADAwMAAAAAAAABAQIAAAAAAAAAAAAAAAAAAAACAgIAAAAAAAABAAAAAAAAAAAAAAAAAAACAgIAAAAHBwcAAAACAgIAAAAbBgYBAQEBAQEZBgcAAAAAAAAAAAABAQEXFxcCAgICAgIHBAUBAQEGBgdyFRcRERFsFRYCAgIDAwMFBQUODg4EBAQFBQUREREFBQUGBgYTExMRCQoEBAQGBAVcIiYaGhoaGhsFBQUUFBRaJSgGBgYdFBgDAwMEBAQNDQ0ODg4fHyAjIyNYWFheLTEHBgcHBwgJCQkLCwsNDQ0PDw8RERESEhIUFBQVFRYWFhYXFxcYGBgZGRkZGRoaGhocHBwdHR0eHh4eHx8fHx8iIiIlJSUmJiYnJycpKSkqKiotLS0uLi4uLi8wMDAyMjIzMzM0NDQ2NjY4ODg6Ojo7Ozs7Oz09PT4+Pj4/Pz9DKS9DQ0NJSUpLS0xMTE1NTU1PT09QUFBRUVFSUlNXV1dZWVlbW1tcXFxeXl5eXl9jY2NkZGRmZmZoaGlsbG1wcHBycnJ1dXV7e3t/f3+AgYGBgYGFhYWIh4mPj4+THyGTk5SVlZWYmJqbm5ygoKCnp6irq6uvr6+wr7KwsLGxsbO1tbW3tri4t7m5ubu9HyDGxcjGxsfJJyjOzs7PHR7QIyTQ0NDR0dHSICHS0tLU1NTY2NjZ2dndIiPd3d3e3t7fIyTi4uLj4+PnICHn5+jq6urs6+zs7Ozu7u7w8PDw8PHx8fHx8fLy8fLy8vLzHR329vb29vf39/j4+Pj5+fn6Hh76Hx/7+/v7+/z8Hx/8/Pz8/P39Hh79/f3///+f+BszAAAAcXRSTlMAAAECAwQFBwoPFhskJSYqKy4yMzU4OTw/Q0hRW1xjZGVmb294e3+Fi4+QkZibnaWmqq+2t7m+x8nKzM3Oz9HR19fd3d/h4eLk5ebm5+rq7O7v8PDy8vP09fX19/f3+Pn5+fr6/Pz8/f3+/v7+/v7+/k5HHiYAAAGUSURBVHgBY2BkFHMMizAVYmRk5NLSVAJSUg5uwYHOlmIMjFzq+soMbHrZ3WsWNyfJ8Gh7pOTxMjJKW6fd/v79S6IFn4FXciUvg3HNoqXNk5Y3ZcXXLSrVBRooW3Dvw/lTr75nZM7Yvd6dgcF37YqGxTOrayZsubkgkpOBkd3v7MddLX2zL7cef3srSoWBIWh1z6yL2zo2XH9wpRLIZeSKu3Bj4uGj03tOv/+60IaBgSG0cWrnypldO5+8nubPDLSBI6GwpGje5KoDn3/uCxAEKvBctH9Oe+/GOy83lykyABUw+aw7sbV/yt4XPx83aTEAgXzxwSeX7t78ca3DDiTPyKBQsePd/YfPP71f5crGAAJGOduP3X3/aHW6AEQBg1ru3DM/fn47kioHFACpMHSy3/PsULc5SB6sQtI2Ov/pm2UeDEAREGLRsPK+uilaAqoApEku/NzJWHGQAASLurd1m4CYcBUuS+abQW0E8xXLQ4RBTLgS1foYfpgCEClSqwFiIYBIqzZEACrMrceKqoBbhxmqAAABho1+nW2udAAAAABJRU5ErkJggg==);
	}

	.PogoButtons {
		color: #fff;
		padding: 3px;
	}

	.PogoButtons span {
		float: none;
	}

	.notPogo span {
		color: #FFF;
		background: #000;
		border-radius: 50%;
		font-size: 10px;
		letter-spacing: -0.15em;
		display: inline-block;
		padding: 2px;
		opacity: 0.6;
		margin: 3px 1px 0 2px;
		height: 15px;
		width: 16px;
		box-sizing: border-box;
		line-height: 1;
	}

	.notPogo span:after {
		display: inline-block;
		content: "N/A";
		position: absolute;
	}

	.notPogo:focus span, .notPogo.favorite span {
		opacity: 1;
	}

	.pogo-text {
		text-align: center;
		font-weight: bold;
		border: none !important;
		background: none !important;
		font-size: 130%;
		color: #000;
		text-shadow: 1px 1px #FFF, 2px 2px 6px #fff, -1px -1px #fff, -2px -2px 6px #fff;
	}

	@media (min-width: 1000px) {
		.pogo-text {
			font-size: 1.2vw;
		}
	}

	@media (min-width: 3000px) {
		.pogo-text {
			margin-left: -0.5vw !important;
			margin-top: -0.7vw !important;
		}
	}

	#PogoGymInfo {
		color: #fff;
		display: none;
		padding: 3px;
	}

	.isGym #PogoGymInfo {
		display: block;
	}

	.thisIsPogo .layer_off_warning,
	.thisIsPogo .mods,
	.thisIsPogo #randdetails,
	.thisIsPogo #resodetails,
	.thisIsPogo #level {
		display: none;
	}

	.thisIsPogo #playerstat,
	.thisIsPogo #gamestat,
	.thisIsPogo #redeem,
	.thisIsPogo #chat,
	.thisIsPogo #artifactLink,
	.thisIsPogo #scoresLink,
	.thisIsPogo #chatinput,
	.thisIsPogo #chatcontrols {
		display: none;
	}

	.thisIsPogo #mobileinfo .portallevel,
	.thisIsPogo #mobileinfo .resonator {
		display: none;
	}

	.thisIsPogo #portal_highlight_select {
		display: none;
	}

	.thisIsPogo #sidebar #portaldetails h3.title {
		color: #fff;
	}

	.gym-main-outline {
		fill: #FFF;
		stroke: #000;
		stroke-width: 5;
	}

	.gym-inner path {
		fill: #fff;
		stroke: #000;
		stroke-width: 2;
	}

	.GoldMedal .gym-main-outline,
	.GoldMedal .ball-outline-center {
		fill: #FEED55;
	}
	.SilverMedal .gym-main-outline,
	.SilverMedal .ball-outline-center {
		fill: #CEDFE6;
	}
	.BronzeMedal .gym-main-outline,
	.BronzeMedal .ball-outline-center {
		fill: #F0B688;
	}

	.GoldMedal .gym-inner path {
		stroke: #EDC13C;
		stroke-width: 20;
	}
	.SilverMedal .gym-inner path {
		stroke: #A4C1C7;
		stroke-width: 20;
	}
	.BronzeMedal .gym-inner path {
		stroke: #DD9D71;
		stroke-width: 10;
	}

	.gym-inner .ball-outline-top {
		fill: #f71208;
	}

	.exGym {
		position: relative;
	}

	.exGym:after {
		content: "EX";
		font-weight: bold;
		text-shadow: 1px 1px 3px #BED1D5, -1px -1px 3px #BED1D5;
		color: #09131D;
		font-size: 130%;
		position: absolute;
		top: 0;
		right: 0;
	}

	.pokestop {
		opacity: 0.75;
	}

	.pokestop path,
	.pokestop ellipse {
		fill: #2370DA;
	}

	path.pokestop-circle {
		fill: #23FEF8;
		stroke-width: 30px;
		stroke: #2370DA;
	}

	.missingPhoto path.pokestop-circle {
		stroke-width: 20px;
		fill: white;
		opacity: 0.5;
	}

	.smallpokestops .pokestop {
		opacity: 0.85;
		pointer-events: none;
	}

	.smallpokestops path.pokestop-pole,
	.smallpokestops ellipse.pokestop-base {
		display: none;
	}

	.smallpokestops .pokestop svg {
		transform: translateY(20px) scale(0.8);
	}

	.PogoClassification div {
		display: grid;
		grid-template-columns: 200px 60px 60px 60px;
		text-align: center;
		align-items: center;
		height: 140px;
		overflow: hidden;
		margin-bottom: 10px;
	}

	.PogoClassification div:nth-child(odd) {
		background: rgba(7, 42, 69, 0.9);
	}

	.PogoClassification img {
		max-width: 200px;
		max-height: 140px;
		display: block;
		margin: 0 auto;
	}

	#dialog-missingPortals .PogoClassification div {
		height: 50px;
	}

	img.photo,
	.ingressLocation,
	.pogoLocation {
		cursor: zoom-in;
	}

	.PoGo-PortalAnimation {
		width: 30px;
		height: 30px;
		background-color: rgba(255, 255, 255, 0.5);
		border-radius: 50%;
		box-shadow: 0px 0px 4px white;
		animation-duration: 1s;
		animation-name: shrink;
	}

	@keyframes shrink {
		from {
			width: 30px;
			height: 30px;
			top: 0px;
			left: 0px;
		}

		to {
			width: 10px;
			height: 10px;
			top: 10px;
			left: 10px;
		}
	}

	.PoGo-PortalAnimationHover {
		background-color: rgb(255, 102, 0, 0.8);
		border-radius: 50%;
		animation-duration: 1s;
		animation-name: shrinkHover;
		animation-iteration-count: infinite;
	}

	@keyframes shrinkHover {
		from {
			width: 40px;
			height: 40px;
			top: 0px;
			left: 0px;
		}

		to {
			width: 20px;
			height: 20px;
			top: 10px;
			left: 10px;
		}
	}

	#sidebarPogo {
		color: #eee;
		padding: 2px 5px;
	}

	#sidebarPogo span {
		margin-right: 5px;
	}

	.refreshingData,
	.refreshingPortalCount {
		opacity: 0.5;
		pointer-events: none;
	}

	#sidebarPogo.mobile {
		width: 100%;
		background: rebeccapurple;
		display: flex;
	}

	#sidebarPogo.mobile > div {
		margin-right: 1em;
	}

	.pogo-colors input[type=color] {
		border: 0;
		padding: 0;
	}

	.PogoListing .header {
		align-items: center;
		display: grid;
		grid-column-gap: 5px;
		grid-template-columns: 1fr 40px 40px 40px;
		text-align: center;
	}

	.PogoListing .header > span + span {
		font-size: 90%;
		font-weight: normal;
	}

	.PogoListing .PortalSummary {
		align-items: center;
		display: grid;
		grid-column-gap: 5px;
		grid-template-columns: 100px 1fr 40px 40px 40px;
		height: 70px;
		margin-bottom: 10px;
		overflow: hidden;
		text-align: center;
	}

	.PogoListing div div:nth-child(odd) {
		background: rgba(7, 42, 69, 0.9);
	}

	.PogoListing img {
		max-width: 100px;
		max-height: 70px;
		display: block;
		margin: 0 auto;
	}

	.Pogo_Photos,
	.Pogo_Votes {
		width: 100%;
		text-align: right;
	}

	`).appendTo( 'head' );
		};

		// A portal has been received.
		function onPortalAdded( data ) {
			const guid=data.portal.options.guid;

			data.portal.on( 'add', function() {
				addNearbyCircle( guid );
				window.clearTimeout( relayoutTimer );
				relayoutTimer=window.setTimeout( relayerBackgroundGroups, 100 );
			} );

			data.portal.on( 'remove', function() {
				removeNearbyCircle( guid );
			} );

			// analyze each portal only once, but sometimes the first time there's no additional data of the portal
			if ( allPortals[ guid ]&&allPortals[ guid ].name )
				return;

			const portal={
				guid: guid,
				name: data.portal.options.data.title,
				lat: data.portal._latlng.lat,
				lng: data.portal._latlng.lng,
				image: data.portal.options.data.image,
				cells: {}
			};

			allPortals[ guid ]=portal;
			groupPortal( portal );

			// If it's already classified in Pokemon, get out
			const pogoData=thisPlugin.findByGuid( guid );
			if ( pogoData ) {
				const pogoItem=pogoData.store[ guid ];
				if ( !pogoItem.exists ) {
					// Mark that it still exists in Ingress
					pogoItem.exists=true;

					if ( missingPortals[ guid ] ) {
						delete missingPortals[ guid ];
						updateMissingPortalsCount();
					}

					// Check if it has been moved
					if ( pogoItem.lat!=portal.lat||pogoItem.lng!=portal.lng ) {
						movedPortals.push( {
							pogo: pogoItem,
							ingress: portal
						} );
						updateCounter( 'moved', movedPortals );
					}
				}
				if ( portal.name&&pogoItem.name!==portal.name ) {
					pogoData.store[ guid ].name=portal.name;
				}
				return;
			}

			if ( skippedPortals[ guid ]||newPokestops[ guid ] )
				return;

			newPortals[ guid ]=portal;

			refreshNewPortalsCounter();
		}

		/**
		 * Draw a 20m circle around a portal
		 */
		function addNearbyCircle( guid ) {
			const portal=window.portals[ guid ];
			if ( !portal )
				return;

			const circleSettings={
				color: settings.colors.nearbyCircleBorder.color,
				opacity: settings.colors.nearbyCircleBorder.opacity,
				fillColor: settings.colors.nearbyCircleFill.color,
				fillOpacity: settings.colors.nearbyCircleFill.opacity,
				weight: 1,
				clickable: false,
				interactive: false
			};

			const center=portal._latlng;
			const circle=L.circle( center, 20, circleSettings );
			nearbyLayerGroup.addLayer( circle );
			nearbyCircles[ guid ]=circle;
		}

		/**
		 * Removes the 20m circle if a portal is purged
		 */
		function removeNearbyCircle( guid ) {
			const circle=nearbyCircles[ guid ];
			if ( circle!=null ) {
				nearbyLayerGroup.removeLayer( circle );
				delete nearbyCircles[ guid ];
			}
		}

		function redrawNearbyCircles() {
			const keys=Object.keys( nearbyCircles );
			keys.forEach( guid => {
				removeNearbyCircle( guid );
				addNearbyCircle( guid );
			} );
			relayerBackgroundGroups();
		}

		/**
		 * Re-orders the layerGroups within regionLayer so that foreground objects don't get hidden/obscured by background layers.
		 */
		function relayerBackgroundGroups() {
			if ( !map.hasLayer( regionLayer ) ) {
				return;
			}
			if ( regionLayer.hasLayer( nearbyLayerGroup ) ) {
				nearbyLayerGroup.bringToBack();
			}
			if ( regionLayer.hasLayer( cellLayerGroup ) ) {
				cellLayerGroup.bringToBack();
			}
			if ( regionLayer.hasLayer( gymCenterLayerGroup ) ) {
				gymCenterLayerGroup.bringToFront();
			}
		}

		function refreshNewPortalsCounter() {
			if ( !settings.analyzeForMissingData )
				return;

			// workaround for https://bugs.chromium.org/p/chromium/issues/detail?id=961199
			try {
				if ( checkNewPortalsTimer ) {
					clearTimeout( checkNewPortalsTimer );
				} else {
					document.getElementById( 'sidebarPogo' ).classList.add( 'refreshingPortalCount' );
				}
			} catch ( e ) {
				// nothing
			}

			// workaround for https://bugs.chromium.org/p/chromium/issues/detail?id=961199
			try {
				checkNewPortalsTimer=setTimeout( checkNewPortals, 1000 );
			} catch ( e ) {
				checkNewPortals();
			}
		}

		/**
		 * A potential new portal has been received
		 */
		function checkNewPortals() {
			checkNewPortalsTimer=null;

			// reuse to update grid counters
			drawCellGrid( map.getZoom() );

			// don't try to classify if we don't have all the portal data
			if ( map.getZoom()<15 )
				return;

			document.getElementById( 'sidebarPogo' ).classList.remove( 'refreshingPortalCount' );

			newPokestops={};
			notClassifiedPokestops=[];

			const allCells=groupByCell( poiCellLevel );

			// Check only the items inside the screen,
			// the server might provide info about remote portals if they are part of a link
			// and we don't know anything else about nearby portals of that one.
			// In this case (vs drawing) we want to filter only cells fully within the screen
			const cells=filterWithinScreen( allCells );

			// try to guess new pokestops if they are the only items in a cell
			Object.keys( cells ).forEach( id => {
				const data=allCells[ id ];
				checkIsPortalMissing( data.gyms, data );
				checkIsPortalMissing( data.stops, data );
				//checkIsPortalMissing(data.notpogo);

				if ( data.notClassified.length==0 )
					return;
				const notClassified=data.notClassified;

				if ( data.gyms.length>0||data.stops.length>0 ) {
					// Already has a pogo item, ignore the rest
					notClassified.forEach( portal => {
						skippedPortals[ portal.guid ]=true;
						delete newPortals[ portal.guid ];
					} );
					return;
				}
				// only one, let's guess it's a pokestop by default
				if ( notClassified.length==1 ) {
					const portal=notClassified[ 0 ];
					const obj={ 'guid': portal.guid, 'lat': portal.lat, 'lng': portal.lng, 'name': portal.name };

					newPokestops[ portal.guid ]=obj;
					//delete newPortals[portal.guid];
					return;
				}

				// too many items to guess
				notClassifiedPokestops.push( data.notClassified );
			} );

			updateCounter( 'pokestops', Object.values( newPokestops ) );
			updateCounter( 'classification', notClassifiedPokestops );
			updateMissingPortalsCount();

			// Now gyms
			checkNewGyms();
		}

		/**
		 * Filter the missing portals detection to show only those on screen and reduce false positives
		 */
		function updateMissingPortalsCount() {
			const keys=Object.keys( missingPortals );
			if ( keys.length==0 )
				updateCounter( 'missing', [] );

			const bounds=map.getBounds();
			const filtered=[];
			keys.forEach( guid => {
				const pogoData=thisPlugin.findByGuid( guid );
				const item=pogoData.store[ guid ];
				if ( isPointOnScreen( bounds, item ) ) {
					filtered.push( item );
				}
			} );
			updateCounter( 'missing', filtered );
		}

		/**
		 * Given an array of pogo items checks if they have been removed from Ingress
		 */
		function checkIsPortalMissing( array, cellData ) {
			array.forEach( item => {
				if ( item.exists||item.newGuid )
					return;
				const guid=item.guid;

				if ( findCorrectGuid( item, cellData.notClassified ) ) {
					return;
				}
				if ( !missingPortals[ guid ] ) {
					missingPortals[ guid ]=true;
				}
			} );
		}

		/**
		 * Check if there's another real portal in the same cell (we're checking a pogo that doesn't exist in Ingress)
		 */
		function findCorrectGuid( pogoItem, array ) {
			const portal=array.find( x => x.name==pogoItem.name&&x.guid!=pogoItem.guid );
			if ( portal!=null ) {
				pogoItem.newGuid=portal.guid;
				movedPortals.push( {
					pogo: pogoItem,
					ingress: portal
				} );
				updateCounter( 'moved', movedPortals );

				delete missingPortals[ pogoItem.guid ];

				return true;
			}
			return false;
		}

		function checkNewGyms() {
			const cellsWithMissingGyms=[];

			const allCells=groupByCell( gymCellLevel );

			// Check only the items inside the screen,
			// the server might provide info about remote portals if they are part of a link
			// and we don't know anything else about nearby portals of that one.
			// In this case (vs drawing) we want to filter only cells fully within the screen
			const cells=filterWithinScreen( allCells );

			// Find the cells where new Gyms can be identified
			Object.keys( cells ).forEach( id => {
				const data=allCells[ id ];
				// Only cells with all the portals already analyzed
				if ( data.notClassified.length>0 )
					return;
				if ( ignoredCellsMissingGyms[ data.cell.toString() ] )
					return;
				const missingGyms=computeMissingGyms( data );
				if ( missingGyms>0 ) {
					cellsWithMissingGyms.push( data );
				}
			} );

			if ( cellsWithMissingGyms.length>0 ) {
				const filtered=filterWithinScreen( cellsWithMissingGyms );
				updateCounter( 'gyms', Object.values( filtered ) );
			} else {
				updateCounter( 'gyms', [] );
			}
		}

		/**
		 * Display new pokestops so they can be added
		 */
		function promptForNewPokestops( data ) {
			if ( data.length==0 )
				return;
			let pending=data.length;

			const div=document.createElement( 'div' );
			div.className='PogoClassification';
			data.sort( sortByName ).forEach( portal => {
				const wrapper=document.createElement( 'div' );
				wrapper.setAttribute( 'data-guid', portal.guid );
				const img=getPortalImage( portal );
				wrapper.innerHTML='<span class="PogoName">'+getPortalName( portal )+
					img+'</span>'+
					'<a data-type="pokestops">'+'STOP'+'</a>'+
					'<a data-type="gyms">'+'GYM'+'</a>'+
					'<a data-type="notpogo">'+'N/A'+'</a>';
				div.appendChild( wrapper );
			} );
			const width=Math.min( screen.availWidth, 420 );

			const container=dialog( {
				id: 'classifyPokestop',
				html: div,
				width: width+'px',
				title: 'Are all of these Pokestops or Gyms?',
				buttons: {
					// Button to allow skip this cell
					'Skip': function() {
						container.dialog( 'close' );
						data.forEach( portal => {
							delete newPokestops[ portal.guid ];
							skippedPortals[ portal.guid ]=true;
						} );
						updateCounter( 'pokestops', Object.values( newPokestops ) );
					},
					'Mark all as Pokestops': function() {
						container.dialog( 'close' );
						data.forEach( portal => {
							if ( !newPokestops[ portal.guid ] )
								return;

							delete newPokestops[ portal.guid ];
							thisPlugin.addPortalpogo( portal.guid, portal.lat, portal.lng, portal.name, 'pokestops' );
						} );
						if ( settings.highlightGymCandidateCells ) {
							updateMapGrid();
						}
						updateCounter( 'pokestops', Object.values( newPokestops ) );
					}
				}
			} );
			// Remove ok button
			const outer=container.parent();
			outer.find( '.ui-dialog-buttonset button:first' ).remove();

			// mark the selected one as pokestop or gym
			container.on( 'click', 'a', function( e ) {
				const type=this.getAttribute( 'data-type' );
				const row=this.parentNode;
				const guid=row.getAttribute( 'data-guid' );
				const portal=allPortals[ guid ];
				delete newPokestops[ portal.guid ];
				thisPlugin.addPortalpogo( guid, portal.lat, portal.lng, portal.name, type );
				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}
				$( row ).fadeOut( 200 );
				pending--;
				if ( pending==0 ) {
					container.dialog( 'close' );
				}
				updateCounter( 'pokestops', Object.values( newPokestops ) );
			} );

			configureHoverMarker( container );
		}

		/**
		 * In a level 17 cell there's more than one portal, ask which one is Pokestop or Gym
		 */
		function promptToClassifyPokestops() {
			updateCounter( 'classification', notClassifiedPokestops );
			if ( notClassifiedPokestops.length==0 )
				return;

			const group=notClassifiedPokestops.shift();
			const div=document.createElement( 'div' );
			div.className='PogoClassification';
			group.sort( sortByName ).forEach( portal => {
				const wrapper=document.createElement( 'div' );
				wrapper.setAttribute( 'data-guid', portal.guid );
				const img=getPortalImage( portal );
				wrapper.innerHTML='<span class="PogoName">'+getPortalName( portal )+
					img+'</span>'+
					'<a data-type="pokestops">'+'STOP'+'</a>'+
					'<a data-type="gyms">'+'GYM'+'</a>';
				div.appendChild( wrapper );
			} );
			const width=Math.min( screen.availWidth, 360 );
			const container=dialog( {
				id: 'classifyPokestop',
				html: div,
				width: width+'px',
				title: 'Which one is in Pokemon Go?',
				buttons: {
					// Button to allow skip this cell
					Skip: function() {
						container.dialog( 'close' );
						group.forEach( portal => {
							delete newPortals[ portal.guid ];
							skippedPortals[ portal.guid ]=true;
						} );
						// continue
						promptToClassifyPokestops();
					}
				}
			} );
			// Remove ok button
			const outer=container.parent();
			outer.find( '.ui-dialog-buttonset button:first' ).remove();

			// mark the selected one as pokestop or gym
			container.on( 'click', 'a', function( e ) {
				const type=this.getAttribute( 'data-type' );
				const guid=this.parentNode.getAttribute( 'data-guid' );
				const portal=getPortalSummaryFromGuid( guid );
				thisPlugin.addPortalpogo( guid, portal.lat, portal.lng, portal.name, type );
				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}

				group.forEach( tmpPortal => {
					delete newPortals[ tmpPortal.guid ];
				} );

				container.dialog( 'close' );
				// continue
				promptToClassifyPokestops();
			} );

			configureHoverMarker( container );
		}

		/**
		 * List of portals that have been moved
		 */
		function promptToMovePokestops() {
			if ( movedPortals.length==0 )
				return;

			const div=document.createElement( 'div' );
			div.className='PogoClassification';
			movedPortals.sort( sortByName ).forEach( pair => {
				const portal=pair.ingress;
				const pogoItem=pair.pogo;
				const wrapper=document.createElement( 'div' );
				wrapper.setAttribute( 'data-guid', portal.guid );
				wrapper.dataPortal=portal;
				wrapper.dataPogoGuid=pogoItem.guid;
				const img=getPortalImage( portal );
				wrapper.innerHTML='<span class="PogoName">'+getPortalName( portal )+
					img+'</span>'+
					'<span><span class="ingressLocation">'+'Ingress location'+'</span></span>'+
					'<span><span class="pogoLocation" data-lat="'+pogoItem.lat+'" data-lng="'+pogoItem.lng+'">'+'Pogo location'+'</span><br>'+
					'<a>'+'Update'+'</a></span>';
				div.appendChild( wrapper );
			} );
			const width=Math.min( screen.availWidth, 360 );
			const container=dialog( {
				id: 'movedPortals',
				html: div,
				width: width+'px',
				title: 'These portals have been moved in Ingress',
				buttons: {
					// Button to move all the portals at once
					'Update all': function() {
						container.dialog( 'close' );
						movedPortals.forEach( pair => {
							const portal=pair.ingress;
							const pogoItem=pair.pogo;
							movePogo( portal, pogoItem.guid );
						} );
						movedPortals.length=0;
						updateCounter( 'moved', movedPortals );

						saveStorage();
						if ( settings.highlightGymCandidateCells ) {
							updateMapGrid();
						}

					}
				}
			} );

			// Update location
			container.on( 'click', 'a', function( e ) {
				const row=this.parentNode.parentNode;
				const portal=row.dataPortal;
				movePogo( portal, row.dataPogoGuid );

				saveStorage();
				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}

				$( row ).fadeOut( 200 );

				// remove it from the list of portals
				const idx=movedPortals.findIndex( pair => pair.ingress.guid==pair.ingress.guid );
				movedPortals.splice( idx, 1 );
				updateCounter( 'moved', movedPortals );

				if ( movedPortals.length==0 )
					container.dialog( 'close' );
			} );

			configureHoverMarker( container );
			configureHoverMarkerAlt( container );
		}

		/**
		 * Update location of a pogo item
		 */
		function movePogo( portal, pogoGuid ) {
			const guid=portal.guid;
			const pogoData=thisPlugin.findByGuid( pogoGuid );

			const existingType=pogoData.type;
			let gym=null;
			if ( existingType=='gyms' ) {
				gym=pogoData.store[ guid ];
			}

			// remove marker
			removePogoObject( existingType, guid );

			// Draw new marker
			thisPlugin.addPortalpogo( guid, portal.lat, portal.lng, portal.name||pogoData.name, existingType );

			// copy gym status
			if ( gym!=null ) {
				pogoData.store[ guid ].isEx=gym.isEx;
				pogoData.store[ guid ].medal=gym.medal;

				saveStorage();

				const icon=document.getElementById( 'gym'+guid.replace( '.', '' ) );
				// update gym marker
				if ( icon ) {
					icon.classList.add( gym.medal+'Medal' );
					icon.classList[ gym.isEx? 'add':'remove' ]( 'exGym' );
				}

			}
		}

		/**
		 * Pogo items that aren't in Ingress
		 */
		function promptToRemovePokestops( missing ) {
			const div=document.createElement( 'div' );
			div.className='PogoClassification';
			missing.sort( sortByName ).forEach( portal => {
				const wrapper=document.createElement( 'div' );
				wrapper.setAttribute( 'data-guid', portal.guid );
				const name=portal.name||'Unknown';
				wrapper.innerHTML='<span class="PogoName"><span class="pogoLocation" data-lat="'+portal.lat+'" data-lng="'+portal.lng+'">'+name+'</span></span>'+
					'<span><a>'+'Remove'+'</a></span>';
				div.appendChild( wrapper );
			} );
			const width=Math.min( screen.availWidth, 360 );
			const container=dialog( {
				id: 'missingPortals',
				html: div,
				width: width+'px',
				title: 'These portals are missing in Ingress',
				buttons: {
				}
			} );

			// Update location
			container.on( 'click', 'a', function( e ) {
				const row=this.parentNode.parentNode;
				const guid=row.getAttribute( 'data-guid' );
				const pogoData=thisPlugin.findByGuid( guid );
				const existingType=pogoData.type;

				// remove marker
				removePogoObject( existingType, guid );
				saveStorage();

				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}

				$( row ).fadeOut( 200 );

				delete missingPortals[ guid ];
				updateMissingPortalsCount();

				if ( Object.keys( missingPortals ).length==0 ) {
					container.dialog( 'close' );
				}
			} );

			configureHoverMarkerAlt( container );
		}

		function configureHoverMarker( container ) {
			container.on( 'click', 'img.photo, .ingressLocation', centerPortal );

			let hoverMarker;
			container.find( 'img.photo, .ingressLocation' ).hover(
				function hIn() {
					const row=this.parentNode.parentNode;
					const guid=row.getAttribute( 'data-guid' );
					const portal=row.dataPortal||window.portals[ guid ];
					if ( !portal )
						return;
					const center=portal._latlng||new L.LatLng( portal.lat, portal.lng );
					hoverMarker=L.marker( center, {
						icon: L.divIcon( {
							className: 'PoGo-PortalAnimationHover',
							iconSize: [ 40, 40 ],
							iconAnchor: [ 20, 20 ],
							html: ''
						} ),
						interactive: false
					} );
					map.addLayer( hoverMarker );
				}, function hOut() {
					if ( hoverMarker )
						map.removeLayer( hoverMarker );
				} );
		}

		function configureHoverMarkerAlt( container ) {
			container.on( 'click', '.pogoLocation', centerPortalAlt );

			let hoverMarker;
			container.find( '.pogoLocation' ).hover(
				function hIn() {
					const lat=this.getAttribute( 'data-lat' );
					const lng=this.getAttribute( 'data-lng' );
					const center=new L.LatLng( lat, lng );
					hoverMarker=L.marker( center, {
						icon: L.divIcon( {
							className: 'PoGo-PortalAnimationHover',
							iconSize: [ 40, 40 ],
							iconAnchor: [ 20, 20 ],
							html: ''
						} ),
						interactive: false
					} );
					map.addLayer( hoverMarker );
				}, function hOut() {
					if ( hoverMarker )
						map.removeLayer( hoverMarker );
				} );
		}

		/**
		 * Center the map on the clicked portal to help tracking it (the user will have to manually move the dialog)
		 */
		function centerPortal( e ) {
			const row=this.parentNode.parentNode;
			const guid=row.getAttribute( 'data-guid' );
			const portal=row.dataPortal||window.portals[ guid ];
			if ( !portal )
				return;
			const center=portal._latlng||new L.LatLng( portal.lat, portal.lng );
			if ( settings.centerMapOnClick )
				map.panTo( center );
			drawClickAnimation( center );
			// Open in sidebar
			if ( !window.isSmartphone() )
				renderPortalDetails( guid );
		}

		function centerPortalAlt( e ) {
			const lat=this.getAttribute( 'data-lat' );
			const lng=this.getAttribute( 'data-lng' );
			const center=new L.LatLng( lat, lng );
			map.panTo( center );
			drawClickAnimation( center );
		}

		function drawClickAnimation( center ) {
			const marker=L.marker( center, {
				icon: L.divIcon( {
					className: 'PoGo-PortalAnimation',
					iconSize: [ 30, 30 ],
					iconAnchor: [ 15, 15 ],
					html: ''
				} ),
				interactive: false
			} );
			map.addLayer( marker );

			setTimeout( function() {
				map.removeLayer( marker );
			}, 2000 );
		}

		function getPortalSummaryFromGuid( guid ) {
			const newPortal=newPortals[ guid ];
			if ( newPortal )
				return newPortal;

			const portal=window.portals[ guid ];
			if ( !portal )
				return {};

			return {
				guid: guid,
				name: portal.options.data.title,
				lat: portal._latlng.lat,
				lng: portal._latlng.lng,
				image: portal.options.data.image,
				cells: {}
			};
		}

		function getPortalImage( pokestop ) {
			if ( pokestop.image )
				return '<img src="'+pokestop.image.replace( 'http:', 'https:' )+'" class="photo">';

			const portal=window.portals[ pokestop.guid ];
			if ( !portal )
				return '';

			if ( portal&&portal.options&&portal.options.data&&portal.options.data.image ) {
				pokestop.image=portal.options.data.image;
				return '<img src="'+pokestop.image.replace( 'http:', 'https:' )+'" class="photo">';
			}
			return '';
		}

		function getPortalName( pokestop ) {
			if ( pokestop.name )
				return pokestop.name;

			const portal=window.portals[ pokestop.guid ];
			if ( !portal )
				return '';

			if ( portal&&portal.options&&portal.options.data&&portal.options.data.title ) {
				pokestop.name=portal.options.data.title;
				return pokestop.name;
			}
			return '';
		}

		/**
		 * In a level 14 cell there's some missing Gyms, prompt which ones
		 */
		function promptToClassifyGyms( groups ) {
			// don't try to classify if we don't have all the portal data
			if ( map.getZoom()<15 )
				return;

			if ( !groups||groups.length==0 )
				return;

			const cellData=groups.shift();
			updateCounter( 'gyms', groups );

			let missingGyms=computeMissingGyms( cellData );

			const div=document.createElement( 'div' );
			div.className='PogoClassification';
			cellData.stops.sort( sortByName ).forEach( portal => {
				if ( skippedPortals[ portal.guid ] )
					return;

				const wrapper=document.createElement( 'div' );
				wrapper.setAttribute( 'data-guid', portal.guid );
				wrapper.innerHTML=
					'<span class="PogoName">'+getPortalName( portal )+
					getPortalImage( portal )+'</span>'+
					'<a data-type="gyms">'+'GYM'+'</a>';
				div.appendChild( wrapper );
			} );
			// No pokestops to prompt as it has been skipped
			if ( !div.firstChild ) {
				// continue
				promptToClassifyGyms( groups );
				return;
			}

			const width=Math.min( screen.availWidth, 360 );
			const container=dialog( {
				id: 'classifyPokestop',
				html: div,
				width: width+'px',
				title: missingGyms==1? 'Which one is a Gym?':'Which '+missingGyms+' are Gyms?',
				buttons: {
					// Button to allow skip this cell
					Skip: function() {
						container.dialog( 'close' );
						cellData.stops.forEach( portal => {
							skippedPortals[ portal.guid ]=true;
						} );
						// continue
						promptToClassifyGyms( groups );
					},
					// Button to allow skip this cell
					'There is no Gym': function() {
						ignoredCellsMissingGyms[ cellData.cell.toString() ]=true;

						if ( settings.highlightGymCandidateCells ) {
							updateMapGrid();
						}
						container.dialog( 'close' );

						saveStorage();

						updateCounter( 'gyms', groups );
						// continue
						promptToClassifyGyms( groups );
					}
				}
			} );
			// Remove ok button
			const outer=container.parent();
			outer.find( '.ui-dialog-buttonset button:first' ).remove();

			// mark the selected one as pokestop or gym
			container.on( 'click', 'a', function( e ) {
				const type=this.getAttribute( 'data-type' );
				const row=this.parentNode;
				const guid=row.getAttribute( 'data-guid' );
				const portal=pokestops[ guid ];

				removePogoObject( 'pokestops', guid );

				thisPlugin.addPortalpogo( guid, portal.lat, portal.lng, portal.name, type );
				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}
				missingGyms--;
				if ( missingGyms==0 ) {
					container.dialog( 'close' );
					// continue
					promptToClassifyGyms( groups );
				} else {
					$( row ).fadeOut( 200 );
					document.querySelector( '.ui-dialog-title-active' ).textContent=missingGyms==1? 'Which one is a Gym?':'Which '+missingGyms+' are Gyms?';
				}
			} );

			configureHoverMarker( container );
		}

		/**
		 * In a level 14 cell there are too many Gyms
		 */
		function promptToVerifyGyms( cellIds ) {
			if ( !cellIds )
				cellIds=Object.keys( cellsExtraGyms );

			if ( cellIds.length==0 )
				return;

			const cellId=cellIds[ 0 ];
			const group=findCellItems( cellId, gymCellLevel, gyms );

			const div=document.createElement( 'div' );
			div.className='PogoClassification';
			group.sort( sortByName ).forEach( portal => {
				const wrapper=document.createElement( 'div' );
				wrapper.setAttribute( 'data-guid', portal.guid );
				const img=getPortalImage( portal );
				wrapper.innerHTML='<span class="PogoName">'+getPortalName( portal )+
					img+'</span>'+
					'<a data-type="pokestops">'+'STOP'+'</a>';
				div.appendChild( wrapper );
			} );
			const width=Math.min( screen.availWidth, 360 );
			const container=dialog( {
				id: 'classifyPokestop',
				html: div,
				width: width+'px',
				title: 'This cell has too many Gyms.',
				buttons: {
					// Button to allow skip this cell
					'All are OK': function() {
						ignoredCellsExtraGyms[ cellId ]=true;

						if ( settings.highlightGymCandidateCells ) {
							updateMapGrid();
						}
						container.dialog( 'close' );
						delete cellsExtraGyms[ cellId ];

						saveStorage();

						updateCounter( 'extraGyms', Object.keys( cellsExtraGyms ) );
						// continue
						promptToVerifyGyms();
					}
				}
			} );
			// Remove ok button
			const outer=container.parent();
			outer.find( '.ui-dialog-buttonset button:first' ).remove();

			// mark the selected one as pokestop or gym
			container.on( 'click', 'a', function( e ) {
				const type=this.getAttribute( 'data-type' );
				const guid=this.parentNode.getAttribute( 'data-guid' );
				const portal=gyms[ guid ];
				thisPlugin.addPortalpogo( guid, portal.lat, portal.lng, portal.name, type );
				if ( settings.highlightGymCandidateCells ) {
					updateMapGrid();
				}

				container.dialog( 'close' );
				delete cellsExtraGyms[ cellId ];
				updateCounter( 'extraGyms', Object.keys( cellsExtraGyms ) );
				// continue
				promptToVerifyGyms();
			} );

			configureHoverMarker( container );
		}


		function removeLayer( name ) {
			const layers=window.layerChooser._layers;
			const layersIds=Object.keys( layers );

			let layerId=null;
			let leafletLayer;
			let isBase;
			let arrayIdx;
			layersIds.forEach( id => {
				const layer=layers[ id ];
				if ( layer.name==name ) {
					leafletLayer=layer.layer;
					layerId=leafletLayer._leaflet_id;
					isBase=!layer.overlay;
					arrayIdx=id;
				}
			} );

			// The Beacons and Frackers are not there in Firefox, why????
			if ( !leafletLayer ) {
				return;
			}

			const enabled=map._layers[ layerId ]!=null;
			if ( enabled ) {
				// Don't remove base layer if it's used
				if ( isBase )
					return;

				map.removeLayer( leafletLayer );
			}
			if ( typeof leafletLayer.off!='undefined' )
				leafletLayer.off();

			// new Leaflet
			if ( Array.isArray( layers ) ) {
				// remove from array
				layers.splice( parseInt( arrayIdx, 10 ), 1 );
			} else {
				// classic IITC, leaflet 0.7.7
				// delete from object
				delete layers[ layerId ];
			}
			window.layerChooser._update();
			removedLayers[ name ]={
				layer: leafletLayer,
				enabled: enabled,
				isBase: isBase
			};
			// window.updateDisplayedLayerGroup( name, enabled );
		}
		const removedLayers={};
		let portalsLayerGroup;

		function removeIngressLayers() {
			removeLayer( 'CartoDB Dark Matter' );
			removeLayer( 'CartoDB Positron' );
			removeLayer( 'Google Default Ingress Map' );

			removeLayer( 'Fields' );
			removeLayer( 'Links' );
			removeLayer( 'DEBUG Data Tiles' );
			removeLayer( 'Artifacts' );
			//removeLayer('Ornaments');
			removeLayer( 'Beacons' );
			removeLayer( 'Frackers' );

			removeLayer( 'Unclaimed/Placeholder Portals' );
			for ( let i=1;i<=8;i++ ) {
				removeLayer( 'Level '+i+' Portals' );
			}
			//removeLayer('Resistance');
			//removeLayer('Enlightened');
			mergePortalLayers();
		}

		/**
		 * Put all the layers for Ingress portals under a single one
		 */
		function mergePortalLayers() {
			portalsLayerGroup=new L.LayerGroup();
			window.addLayerGroup( 'Ingress Portals', portalsLayerGroup, true );
			portalsLayerGroup.addLayer( removedLayers[ 'Unclaimed/Placeholder Portals' ].layer );
			for ( let i=1;i<=8;i++ ) {
				portalsLayerGroup.addLayer( removedLayers[ 'Level '+i+' Portals' ].layer );
			}
			//portalsLayerGroup.addLayer(removedLayers['Resistance'].layer);
			//portalsLayerGroup.addLayer(removedLayers['Enlightened'].layer);
		}

		/**
		 * Remove the single layer for all the portals
		 */
		function revertPortalLayers() {
			if ( !portalsLayerGroup ) {
				return;
			}
			const name='Ingress Portals';
			const layerId=portalsLayerGroup._leaflet_id;
			const enabled=map._layers[ layerId ]!=null;

			const layers=window.layerChooser._layers;
			if ( Array.isArray( layers ) ) {
				// remove from array
				const idx=layers.findIndex( o => o.layer._leaflet_id==layerId );
				layers.splice( idx, 1 );
			} else {
				// classic IITC, leaflet 0.7.7
				// delete from object
				delete layers[ layerId ];
			}
			window.layerChooser._update();
			// window.updateDisplayedLayerGroup( name, enabled );

			if ( typeof portalsLayerGroup.off!='undefined' )
				portalsLayerGroup.off();
			if ( enabled ) {
				map.removeLayer( portalsLayerGroup );
			}
			portalsLayerGroup=null;
		}

		function restoreIngressLayers() {
			revertPortalLayers()

			Object.keys( removedLayers ).forEach( ( name ) => {
				const info=removedLayers[ name ]
				if ( info.isBase ) {
					window.layerChooser.addBaseLayer( info.layer, name )
				} else {
					if ( window.layerChooser.addOverlay ) {
						window.layerChooser.addOverlay( info.layer, name, {
							enabled: info.enabled,
							default: info.enabled
						} )
						window.layerChooser.showLayer( info.layer, info.enabled )
					} else {
						window.addLayerGroup( name, info.layer, info.enabled )
					}
				}
			} )
		}

		function zoomListener() {
			const zoom=map.getZoom();
			document.body.classList.toggle( 'smallpokestops', zoom<16 );
		}

		const setup=function() {
			thisPlugin.isSmart=window.isSmartphone();

			initSvgIcon();
			window.addPortalHighlighter( highlighterTitle, markPortalsAsNeutral );

			loadSettings();

			// Load data from localStorage
			thisPlugin.loadStorage();

			thisPlugin.htmlStar=`<a class="pogoStop" accesskey="p" onclick="window.plugin.pogo.switchStarPortal('pokestops');return false;" title="Mark this portal as a pokestop [p]"><span></span></a>
				<a class="pogoGym" accesskey="g" onclick="window.plugin.pogo.switchStarPortal('gyms');return false;" title="Mark this portal as a PokeGym [g]"><span></span></a>
				<a class="notPogo" onclick="window.plugin.pogo.switchStarPortal('notpogo');return false;" title="Mark this portal as a removed/Not Available in Pokemon Go"><span></span></a>
				`;

			thisPlugin.setupCSS();

			const sidebarPogo=document.createElement( 'div' );
			sidebarPogo.id='sidebarPogo';
			sidebarPogo.style.display='none';
			if ( thisPlugin.isSmart ) {
				const status=document.getElementById( 'updatestatus' );
				sidebarPogo.classList.add( 'mobile' );
				status.insertBefore( sidebarPogo, status.firstElementChild );

				const dStatus=document.createElement( 'div' );
				dStatus.className='PogoStatus';
				status.insertBefore( dStatus, status.firstElementChild );
			} else {
				document.getElementById( 'sidebar' ).appendChild( sidebarPogo );
			}

			sidebarPogo.appendChild( createCounter( 'New pokestops', 'pokestops', promptForNewPokestops ) );
			sidebarPogo.appendChild( createCounter( 'Review required', 'classification', promptToClassifyPokestops ) );
			sidebarPogo.appendChild( createCounter( 'Moved portals', 'moved', promptToMovePokestops ) );
			sidebarPogo.appendChild( createCounter( 'Missing portals', 'missing', promptToRemovePokestops ) );
			sidebarPogo.appendChild( createCounter( 'New Gyms', 'gyms', promptToClassifyGyms ) );
			sidebarPogo.appendChild( createCounter( 'Cells with extra Gyms', 'extraGyms', promptToVerifyGyms ) );

			window.addHook( 'portalSelected', thisPlugin.onPortalSelected );

			window.addHook( 'portalAdded', onPortalAdded );
			window.addHook( 'mapDataRefreshStart', function() {
				sidebarPogo.classList.add( 'refreshingData' );
			} );
			window.addHook( 'mapDataRefreshEnd', function() {
				sidebarPogo.classList.remove( 'refreshingData' );
				refreshNewPortalsCounter();
			} );
			map.on( 'moveend', function() {
				refreshNewPortalsCounter();
			} );
			sidebarPogo.classList.add( 'refreshingData' );

			// Layer - pokemon go portals
			stopLayerGroup=L.layerGroup();
			window.addLayerGroup( 'PokeStops', stopLayerGroup, true );
			gymLayerGroup=L.layerGroup();
			window.addLayerGroup( 'Gyms', gymLayerGroup, true );
			regionLayer=L.layerGroup();
			window.addLayerGroup( 'S2 Grid', regionLayer, true );

			// this layer will group all the nearby circles that are added or removed from it when the portals are added or removed
			nearbyLayerGroup=L.featureGroup();
			// this layer will group all the shaded cells and cell borders
			cellLayerGroup=L.featureGroup();
			// this layer will contain the s2 grid
			gridLayerGroup=L.layerGroup();
			// this layer will contain the gym centers for checking ex eligibility
			gymCenterLayerGroup=L.featureGroup();

			countLayer=L.layerGroup();
			window.addLayerGroup( 'PoI in cell counter', countLayer, false );

			thisPlugin.addAllMarkers();

			const toolbox=document.getElementById( 'toolbox' );

			const buttonPoGo=document.createElement( 'a' );
			buttonPoGo.textContent='PoGo Actions';
			buttonPoGo.title='Actions on Pokemon Go data';
			buttonPoGo.addEventListener( 'click', thisPlugin.pogoActionsDialog );
			toolbox.appendChild( buttonPoGo );

			const buttonGrid=document.createElement( 'a' );
			buttonGrid.textContent='PoGo Settings';
			buttonGrid.title='Settings for S2 & PokemonGo';
			buttonGrid.addEventListener( 'click', e => {
				if ( thisPlugin.isSmart )
					window.show( 'map' );
				showS2Dialog();
			} );
			toolbox.appendChild( buttonGrid );

			map.on( 'zoomend', zoomListener );
			zoomListener();
			map.on( 'moveend', updateMapGrid );
			updateMapGrid();
			map.on( 'overlayadd', function( event ) {
				if ( event&&event.name==='S2 Grid' ) {
					updateMapGrid();
				}
			} );

			// add ids to the links that we want to be able to hide
			const links=document.querySelectorAll( '#toolbox > a' );
			links.forEach( a => {
				const text=a.textContent;
				if ( text=='Region scores' ) {
					a.id='scoresLink';
				}
				if ( text=='Artifacts' ) {
					a.id='artifactLink';
				}
			} );

		};

		function createCounter( title, type, callback ) {
			const div=document.createElement( 'div' );
			div.style.display='none';
			const sTitle=document.createElement( 'span' );
			sTitle.textContent=title;
			const counter=document.createElement( 'a' );
			counter.id='PogoCounter-'+type;
			counter.addEventListener( 'click', function( e ) {
				callback( counter.PogoData );
				return false;
			} );
			div.appendChild( sTitle );
			div.appendChild( counter );
			return div;
		}

		function updateCounter( type, data ) {
			const counter=document.querySelector( '#PogoCounter-'+type );
			counter.PogoData=data;
			counter.textContent=data.length;
			counter.parentNode.style.display=data.length>0? '':'none';

			// Adjust visibility of the pane to avoid the small gap due to padding
			const pane=counter.parentNode.parentNode;
			if ( data.length>0 ) {
				pane.style.display='';
				return;
			}
			let node=pane.firstElementChild;
			while ( node ) {
				const rowData=node.lastElementChild.PogoData;
				if ( rowData&&rowData.length>0 ) {
					pane.style.display='';
					return;
				}
				node=node.nextElementSibling;
			}
			pane.style.display='none';
		}

		// PLUGIN END //////////////////////////////////////////////////////////

		setup.info=plugin_info; //add the script info data to the function as a property
		// if IITC has already booted, immediately run the 'setup' function
		if ( window.iitcLoaded ) {
			setup();
		} else {
			if ( !window.bootPlugins ) {
				window.bootPlugins=[];
			}
			window.bootPlugins.push( setup );
		}
	}

	const plugin_info={};
	if ( typeof GM_info!=='undefined'&&GM_info&&GM_info.script ) {
		plugin_info.script={
			version: GM_info.script.version,
			name: GM_info.script.name,
			description: GM_info.script.description
		};
	}

	// Greasemonkey. It will be quite hard to debug
	if ( typeof unsafeWindow!='undefined'||typeof GM_info=='undefined'||GM_info.scriptHandler!='Tampermonkey' ) {
		// inject code into site context
		const script=document.createElement( 'script' );
		script.appendChild( document.createTextNode( '('+wrapper+')('+JSON.stringify( plugin_info )+');' ) );
		( document.body||document.head||document.documentElement ).appendChild( script );
	} else {
		// Tampermonkey, run code directly
		wrapper( plugin_info );
	}
} )();